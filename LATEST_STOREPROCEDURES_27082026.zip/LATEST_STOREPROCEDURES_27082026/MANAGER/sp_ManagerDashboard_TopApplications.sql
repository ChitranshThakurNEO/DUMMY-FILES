CREATE PROCEDURE [dbo].[sp_ManagerDashboard_TopApplications]
(
@ManagerEmployeeCode VARCHAR(20),
@FromDate DATE,
@ToDate DATE,
@ApplicationType VARCHAR(20),
@WorkMode VARCHAR(20) = NULL
)
AS
BEGIN
SET NOCOUNT ON;
---------------------------------------------------
-- TEAM LEADS
---------------------------------------------------
;WITH TeamLeads AS
(
SELECT
EmployeeCode
FROM vw_MasterEmployee
WHERE MANAGER_1 = @ManagerEmployeeCode
AND
(
@WorkMode IS NULL
OR @WorkMode = ''
OR UPPER(ISNULL(WORK_MODE,'')) = UPPER(@WorkMode)
)
)
---------------------------------------------------
-- ASSOCIATES + TEAM LEADS
---------------------------------------------------
, Associates AS
(
SELECT EmployeeCode
FROM TeamLeads
UNION
SELECT DISTINCT
E.EmployeeCode
FROM vw_MasterEmployee E
INNER JOIN TeamLeads TL
ON TL.EmployeeCode = E.MANAGER_1
OR TL.EmployeeCode = E.MANAGER_2
OR TL.EmployeeCode = E.MANAGER_3
OR TL.EmployeeCode = E.MANAGER_4
OR TL.EmployeeCode = E.MANAGER_5
OR TL.EmployeeCode = E.MANAGER_6
OR TL.EmployeeCode = E.MANAGER_7
WHERE
(
@WorkMode IS NULL
OR @WorkMode = ''
OR UPPER(ISNULL(E.WORK_MODE,'')) = UPPER(@WorkMode)
)
)
---------------------------------------------------
-- APPLICATION DATA
---------------------------------------------------
, ApplicationData AS
(
SELECT
MAC.SubCategoryName AS ApplicationName,
MAL.Status AS ApplicationTypeLabel,
MAX(MAC.ColorHex) AS ColorHex,
SUM(MAL.DurationSeconds) / 3600.0 AS TotalHours
FROM Associates A
INNER JOIN MasterActivityLog MAL
ON MAL.EmployeeCode = A.EmployeeCode
AND MAL.LogDate BETWEEN @FromDate AND @ToDate
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
INNER JOIN MasterActivityCategory MAC
ON MAC.MasterActivityCategoryId = MAL.CategoryId
WHERE UPPER(MAL.Status) = UPPER(@ApplicationType)
GROUP BY
MAC.SubCategoryName,
MAL.Status
)
---------------------------------------------------
-- TOTAL HOURS
---------------------------------------------------
, TotalHoursData AS
(
SELECT
SUM(TotalHours) AS GrandTotalHours
FROM ApplicationData
)
---------------------------------------------------
-- FINAL OUTPUT
---------------------------------------------------
SELECT TOP 5
ad.ApplicationName,
ad.ApplicationTypeLabel,
ad.ColorHex,
CAST
(
ad.TotalHours
/
NULLIF
(
(
(DATEDIFF(DAY, @FromDate, @ToDate) + 1)
*
(
SELECT COUNT(*)
FROM Associates
)
),
0
)
AS DECIMAL(18,2)) AS AvgHoursPerDay,
CAST
(
ad.TotalHours * 100.0
/
NULLIF(thd.GrandTotalHours,0)
AS DECIMAL(18,2)) AS Percentage
FROM ApplicationData ad
CROSS JOIN TotalHoursData thd
ORDER BY
ad.TotalHours DESC;
END
