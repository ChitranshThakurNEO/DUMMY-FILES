﻿CREATE PROCEDURE [dbo].[sp_ManagerDashboard_ProductivityReport_Team]
(
@ManagerEmployeeCode NVARCHAR(100),
@FromDate DATE,
@ToDate DATE,
@TeamLeadEmployeeCode NVARCHAR(100) = NULL,
@SearchText NVARCHAR(100) = NULL,
@ShiftName NVARCHAR(50) = NULL,
@Geo NVARCHAR(50) = NULL
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
-------------------------------------------------------
-- RANGE HANDLING (FINAL FIX APPLIED HERE)
-------------------------------------------------------
DECLARE @CurrFromDate DATE;
DECLARE @CurrToDate DATE;
DECLARE @PrevFromDate DATE;
DECLARE @PrevToDate DATE;
IF @FromDate = @ToDate
BEGIN
-- SAME DATE (NO CHANGE)
SET @CurrFromDate = DATEADD(DAY, -(DATEPART(WEEKDAY, @FromDate) - 1), @FromDate);
SET @CurrToDate = DATEADD(DAY, 6, @CurrFromDate);
-- Previous working day (NO CHANGE)
SELECT TOP 1 @PrevFromDate = LoggedDate
FROM EmployeeActivityLogSummary
WHERE LoggedDate < @FromDate
AND TOT_LOGGEDHOURS > 0
ORDER BY LoggedDate DESC;
SET @PrevToDate = @PrevFromDate;
END
ELSE
BEGIN
-- RANGE → EXPAND TO FULL WEEKS (NEW FIX)
SET @CurrFromDate = DATEADD(DAY, -(DATEPART(WEEKDAY, @FromDate) - 1), @FromDate);
SET @CurrToDate = DATEADD(DAY,
7 - DATEPART(WEEKDAY, @ToDate),
@ToDate
);
DECLARE @Diff INT = DATEDIFF(DAY, @CurrFromDate, @CurrToDate) + 1;
-- PREVIOUS FULL WEEKS
SET @PrevFromDate = DATEADD(DAY, -@Diff, @CurrFromDate);
SET @PrevToDate = DATEADD(DAY, -@Diff, @CurrToDate);
END;
-------------------------------------------------------
-- TEAM LEADS
-------------------------------------------------------
;WITH TeamLeads AS
(
SELECT DISTINCT E.EmployeeCode
FROM vw_MasterEmployee E
INNER JOIN EmployeeActivityLogSummary S
ON S.EmployeeCode = E.EmployeeCode
AND S.IsActive = 1
AND S.IsDelete = 0
AND S.LoggedDate BETWEEN @CurrFromDate AND @CurrToDate
WHERE E.MANAGER_1 = @ManagerEmployeeCode
AND (
@TeamLeadEmployeeCode IS NULL
OR E.EmployeeCode = @TeamLeadEmployeeCode
)
),
-------------------------------------------------------
-- EMPLOYEES
-------------------------------------------------------
Employees AS
(
SELECT EmployeeCode FROM TeamLeads
WHERE EmployeeCode <> @ManagerEmployeeCode
UNION
SELECT DISTINCT E.EmployeeCode
FROM vw_MasterEmployee E
WHERE E.EmployeeCode <> @ManagerEmployeeCode
AND EXISTS
(
SELECT 1
FROM TeamLeads TL
WHERE TL.EmployeeCode IN
(
E.MANAGER_1, E.MANAGER_2, E.MANAGER_3,
E.MANAGER_4, E.MANAGER_5, E.MANAGER_6, E.MANAGER_7
)
)
),
-------------------------------------------------------
-- DATE RANGES
-------------------------------------------------------
DateRanges AS
(
SELECT 'CURRENT' AS RangeType, @CurrFromDate AS FromDate, @CurrToDate AS ToDate
UNION ALL
SELECT 'PREVIOUS', @PrevFromDate, @PrevToDate
),
-------------------------------------------------------
-- BASE DATA
-------------------------------------------------------
BaseData AS
(
SELECT
DR.RangeType,
S.EmployeeCode,
CAST(S.LoggedDate AS DATE) AS WorkDate,
S.TOT_PRODHOURS,
S.TOT_LOGGEDHOURS,
ME.MANAGER_1,
MS.Name AS ShiftName,
ME.City
FROM EmployeeActivityLogSummary S
INNER JOIN DateRanges DR
ON S.LoggedDate BETWEEN DR.FromDate AND DR.ToDate
INNER JOIN Employees E
ON E.EmployeeCode = S.EmployeeCode
INNER JOIN vw_MasterEmployee ME
ON ME.EmployeeCode = S.EmployeeCode
LEFT JOIN EmployeeShift ES
ON ES.EmployeeCode = S.EmployeeCode
AND ES.EffectiveFrom <= S.LoggedDate
AND (ES.EffectiveTo IS NULL OR ES.EffectiveTo >= S.LoggedDate)
LEFT JOIN MasterShift MS
ON MS.MasterShiftId = ES.ShiftId
WHERE S.IsActive = 1
AND S.IsDelete = 0
AND (
@SearchText IS NULL OR @SearchText = ''
OR ME.FullName LIKE '%' + @SearchText + '%'
OR ME.EmployeeCode LIKE '%' + @SearchText + '%'
)
AND (
@ShiftName IS NULL OR @ShiftName = ''
OR UPPER(MS.Name) = UPPER(@ShiftName)
)
AND (
@Geo IS NULL OR @Geo = ''
OR UPPER(ME.City) = UPPER(@Geo)
)
),
-------------------------------------------------------
-- FILTER
-------------------------------------------------------
FilteredData AS
(
SELECT *
FROM BaseData
WHERE
DATENAME(WEEKDAY, WorkDate) NOT IN ('Saturday','Sunday')
AND TOT_LOGGEDHOURS > 0
),
-------------------------------------------------------
-- EMPLOYEE PRODUCTIVITY
-------------------------------------------------------
EmployeeProductivity AS
(
SELECT
RangeType,
EmployeeCode,
MANAGER_1,
CASE
WHEN @FromDate = @ToDate THEN
SUM(TOT_PRODHOURS) * 100.0
/ NULLIF(SUM(TOT_LOGGEDHOURS), 0)
ELSE
AVG(
TOT_PRODHOURS * 100.0
/ NULLIF(TOT_LOGGEDHOURS, 0)
)
END AS ProductivityPercent
FROM FilteredData
GROUP BY RangeType, EmployeeCode, MANAGER_1
),
-------------------------------------------------------
-- TEAM PRODUCTIVITY (FIXED SELF LOGIC)
-------------------------------------------------------
TeamProductivity AS
(
SELECT
EP.RangeType,
CASE
WHEN TLSet.EmployeeCode IS NOT NULL
THEN EP.EmployeeCode
ELSE EP.MANAGER_1
END AS TeamLeadCode,
AVG(EP.ProductivityPercent) AS TeamProductivity
FROM EmployeeProductivity EP
LEFT JOIN TeamLeads TLSet
ON TLSet.EmployeeCode = EP.EmployeeCode
WHERE EP.EmployeeCode <> @ManagerEmployeeCode
GROUP BY
EP.RangeType,
CASE
WHEN TLSet.EmployeeCode IS NOT NULL
THEN EP.EmployeeCode
ELSE EP.MANAGER_1
END
)
-------------------------------------------------------
-- FINAL OUTPUT
-------------------------------------------------------
SELECT
TL.EmployeeCode AS TeamLeadCode,
TLME.FullName AS TeamLeadName,
CAST(ISNULL(C.TeamProductivity,0) AS DECIMAL(10,2)) AS CurrentProductivity,
CAST(ISNULL(P.TeamProductivity,0) AS DECIMAL(10,2)) AS PreviousProductivity,
CAST(
ISNULL(C.TeamProductivity,0) - ISNULL(P.TeamProductivity,0)
AS DECIMAL(10,2)) AS ChangePercent,
CASE
WHEN ISNULL(C.TeamProductivity,0) > ISNULL(P.TeamProductivity,0) THEN 'RAISE'
WHEN ISNULL(C.TeamProductivity,0) < ISNULL(P.TeamProductivity,0) THEN 'DIP'
ELSE 'NO CHANGE'
END AS Trend
FROM TeamLeads TL
LEFT JOIN vw_MasterEmployee TLME
ON TLME.EmployeeCode = TL.EmployeeCode
LEFT JOIN TeamProductivity C
ON C.TeamLeadCode = TL.EmployeeCode
AND C.RangeType = 'CURRENT'
LEFT JOIN TeamProductivity P
ON P.TeamLeadCode = TL.EmployeeCode
AND P.RangeType = 'PREVIOUS'
WHERE TL.EmployeeCode <> @ManagerEmployeeCode
ORDER BY ISNULL(C.TeamProductivity,0) DESC;
END
