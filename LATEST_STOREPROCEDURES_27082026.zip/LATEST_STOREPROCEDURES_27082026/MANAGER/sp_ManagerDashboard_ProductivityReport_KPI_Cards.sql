CREATE PROCEDURE [dbo].[sp_ManagerDashboard_ProductivityReport_KPI_Cards]
(
@ManagerEmployeeCode NVARCHAR(100),
@FromDate DATE,
@ToDate DATE
)
AS
BEGIN
SET NOCOUNT ON;
-------------------------------------------------------
-- Previous Date Range Calculation
-------------------------------------------------------
DECLARE @PrevFromDate DATE;
DECLARE @PrevToDate DATE;
IF @FromDate = @ToDate
BEGIN
SET @PrevFromDate = DATEADD(DAY, -1, @FromDate);
SET @PrevToDate = DATEADD(DAY, -1, @ToDate);
END
ELSE
BEGIN
DECLARE @Diff INT = DATEDIFF(DAY, @FromDate, @ToDate) + 1;
SET @PrevFromDate = DATEADD(DAY, -@Diff, @FromDate);
SET @PrevToDate = DATEADD(DAY, -@Diff, @ToDate);
END;
-------------------------------------------------------
-- Team Hierarchy
-------------------------------------------------------
;WITH TeamLeads AS
(
SELECT DISTINCT E.EmployeeCode
FROM vw_MasterEmployee E
INNER JOIN EmployeeActivityLogSummary S
ON E.EmployeeCode = S.EmployeeCode
WHERE E.MANAGER_1 = @ManagerEmployeeCode
),
Employees AS
(
SELECT EmployeeCode FROM TeamLeads
UNION
SELECT DISTINCT E.EmployeeCode
FROM vw_MasterEmployee E
INNER JOIN EmployeeActivityLogSummary S
ON E.EmployeeCode = S.EmployeeCode
WHERE EXISTS
(
SELECT 1
FROM TeamLeads TL
WHERE TL.EmployeeCode IN
(
E.MANAGER_1, E.MANAGER_2, E.MANAGER_3,
E.MANAGER_4, E.MANAGER_5, E.MANAGER_6, E.MANAGER_7
)
)
),
-------------------------------------------------------
-- Manager Info
-------------------------------------------------------
ManagerInfo AS
(
SELECT TOP 1
EmployeeCode AS ManagerCode,
FullName AS ManagerName
FROM vw_MasterEmployee
WHERE EmployeeCode = @ManagerEmployeeCode
),
TeamLeadCount AS
(
SELECT COUNT(DISTINCT EmployeeCode) AS TotalTeamLeads
FROM TeamLeads
),
AssociateCount AS
(
SELECT COUNT(DISTINCT EmployeeCode) AS TotalAssociates
FROM Employees
),
-------------------------------------------------------
-- Current + Previous Range
-------------------------------------------------------
DateRanges AS
(
SELECT 'CURRENT' AS RangeType, @FromDate AS FromDate, @ToDate AS ToDate
UNION ALL
SELECT 'PREVIOUS', @PrevFromDate, @PrevToDate
),
BaseData AS
(
SELECT
DR.RangeType,
S.EmployeeCode,
CAST(S.LoggedDate AS DATE) AS WorkDate,
S.TOT_PRODHOURS,
S.TOT_LOGGEDHOURS
FROM EmployeeActivityLogSummary S
INNER JOIN DateRanges DR
ON S.LoggedDate BETWEEN DR.FromDate AND DR.ToDate
INNER JOIN Employees E
ON E.EmployeeCode = S.EmployeeCode
INNER JOIN vw_MasterEmployee ME
ON ME.EmployeeCode = S.EmployeeCode
WHERE S.IsActive = 1
AND S.IsDelete = 0
),
-------------------------------------------------------
-- Apply Filters
-------------------------------------------------------
FilteredData AS
(
SELECT *
FROM BaseData
WHERE
DATEPART(WEEKDAY, WorkDate) NOT IN (1,7)
AND TOT_LOGGEDHOURS > 0
),
-------------------------------------------------------
-- Employee Productivity
-------------------------------------------------------
EmployeeProductivity AS
(
SELECT
RangeType,
EmployeeCode,
CASE
WHEN @FromDate = @ToDate THEN
SUM(TOT_PRODHOURS) * 100.0
/ NULLIF(SUM(TOT_LOGGEDHOURS), 0)
ELSE
AVG(
TOT_PRODHOURS * 100.0
/ NULLIF(TOT_LOGGEDHOURS, 0)
)
END AS ProductivityPercent
FROM FilteredData
GROUP BY RangeType, EmployeeCode
),
-------------------------------------------------------
-- Map Employees to Team Leads
-------------------------------------------------------
EmployeeWithTL AS
(
SELECT
EP.RangeType,
EP.EmployeeCode,
EP.ProductivityPercent,
ME.MANAGER_1 AS TeamLeadCode,
ME.FullName AS TeamLeadName
FROM EmployeeProductivity EP
INNER JOIN vw_MasterEmployee ME
ON ME.EmployeeCode = EP.EmployeeCode
),
-------------------------------------------------------
-- Team Productivity
-------------------------------------------------------
TeamProductivity AS
(
SELECT
RangeType,
TeamLeadCode,
TeamLeadName,
AVG(ProductivityPercent) AS TeamProductivity
FROM EmployeeWithTL
GROUP BY RangeType, TeamLeadCode, TeamLeadName
),
-------------------------------------------------------
-- Final Aggregates
-------------------------------------------------------
FinalAgg AS
(
SELECT
RangeType,
AVG(ProductivityPercent) AS AvgProductivity,
SUM(CASE WHEN ProductivityPercent >= 75 THEN 1 ELSE 0 END) AS AboveTarget,
SUM(CASE WHEN ProductivityPercent < 75 THEN 1 ELSE 0 END) AS BelowTarget
FROM EmployeeProductivity
GROUP BY RangeType
)
-------------------------------------------------------
-- FINAL OUTPUT
-------------------------------------------------------
SELECT
MI.ManagerCode,
MI.ManagerName,
TLC.TotalTeamLeads,
AC.TotalAssociates,
CAST(C.AvgProductivity AS DECIMAL(10,2)) AS CurrentAvgProductivity,
C.AboveTarget AS AboveTargetCount,
C.BelowTarget AS BelowTargetCount,
CAST(P.AvgProductivity AS DECIMAL(10,2)) AS PreviousAvgProductivity,
CAST(
C.AvgProductivity - P.AvgProductivity
AS DECIMAL(10,2)) AS ProductivityChange,
CASE
WHEN C.AvgProductivity > P.AvgProductivity THEN 'RAISE'
WHEN C.AvgProductivity < P.AvgProductivity THEN 'DIP'
ELSE 'NO CHANGE'
END AS Trend,
(SELECT TOP 1 TeamLeadName
FROM TeamProductivity
WHERE RangeType = 'CURRENT'
ORDER BY TeamProductivity DESC) AS TopTeam,
(SELECT TOP 1 CAST(TeamProductivity AS DECIMAL(10,2))
FROM TeamProductivity
WHERE RangeType = 'CURRENT'
ORDER BY TeamProductivity DESC) AS TopTeamProductivity,
(SELECT TOP 1 TeamLeadName
FROM TeamProductivity
WHERE RangeType = 'CURRENT'
ORDER BY TeamProductivity ASC) AS LowestTeam,
(SELECT TOP 1 CAST(TeamProductivity AS DECIMAL(10,2))
FROM TeamProductivity
WHERE RangeType = 'CURRENT'
ORDER BY TeamProductivity ASC) AS LowestTeamProductivity
FROM FinalAgg C
LEFT JOIN FinalAgg P
ON P.RangeType = 'PREVIOUS'
CROSS JOIN ManagerInfo MI
CROSS JOIN TeamLeadCount TLC
CROSS JOIN AssociateCount AC
WHERE C.RangeType = 'CURRENT';
END
