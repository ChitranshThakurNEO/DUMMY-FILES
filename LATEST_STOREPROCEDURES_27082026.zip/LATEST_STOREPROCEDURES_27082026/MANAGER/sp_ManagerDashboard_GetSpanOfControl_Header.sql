CREATE PROCEDURE [dbo].[sp_ManagerDashboard_GetSpanOfControl_Header]
(
@ManagerEmployeeCode VARCHAR(20)
)
AS
BEGIN
SET NOCOUNT ON;
;WITH TeamLeads AS
(
SELECT DISTINCT
EmployeeCode,
FullName
FROM vw_MasterEmployee
WHERE LTRIM(RTRIM(MANAGER_1))
= LTRIM(RTRIM(@ManagerEmployeeCode))
),
TeamMembers AS
(
SELECT DISTINCT
E.EmployeeCode
FROM vw_MasterEmployee E
INNER JOIN TeamLeads TL
ON TL.EmployeeCode = E.MANAGER_1
OR TL.EmployeeCode = E.MANAGER_2
OR TL.EmployeeCode = E.MANAGER_3
OR TL.EmployeeCode = E.MANAGER_4
OR TL.EmployeeCode = E.MANAGER_5
OR TL.EmployeeCode = E.MANAGER_6
OR TL.EmployeeCode = E.MANAGER_7
UNION
SELECT EmployeeCode
FROM TeamLeads
)
SELECT
@ManagerEmployeeCode AS ManagerEmployeeCode,
(
SELECT TOP 1 FullName
FROM vw_MasterEmployee
WHERE EmployeeCode = @ManagerEmployeeCode
) AS OperationalManagerName,
(
SELECT COUNT(*)
FROM TeamLeads
) AS TotalTeamLeads,
(
SELECT COUNT(*)
FROM TeamMembers
) AS TotalTeamMembers,
(
SELECT TOP 1 CITY
FROM vw_MasterEmployee
WHERE EmployeeCode = @ManagerEmployeeCode
) AS City,
(
SELECT TOP 1 COUNTRY
FROM vw_MasterEmployee
WHERE EmployeeCode = @ManagerEmployeeCode
) AS GeoLocation;
END
