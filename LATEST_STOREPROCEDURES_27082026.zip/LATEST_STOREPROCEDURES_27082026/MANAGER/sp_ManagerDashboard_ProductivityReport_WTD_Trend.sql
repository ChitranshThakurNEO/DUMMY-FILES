﻿CREATE PROCEDURE [dbo].[sp_ManagerDashboard_ProductivityReport_WTD_Trend]
(
@ManagerEmployeeCode NVARCHAR(100),
@FromDate DATE,
@ToDate DATE,
@TeamLeadEmployeeCode NVARCHAR(100) = NULL,
@SearchText NVARCHAR(100) = NULL,
@ShiftName NVARCHAR(50) = NULL,
@Geo NVARCHAR(50) = NULL
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7; -- Sunday start
-------------------------------------------------------
-- RANGE CALCULATION
-------------------------------------------------------
DECLARE @CurrFromDate DATE;
DECLARE @CurrToDate DATE;
DECLARE @PrevFromDate DATE;
DECLARE @PrevToDate DATE;
DECLARE @Diff INT;
IF @FromDate = @ToDate
BEGIN
-- WEEK MODE
SET @CurrFromDate = DATEADD(DAY, -(DATEPART(WEEKDAY, @FromDate) - 1), @FromDate);
SET @CurrToDate = DATEADD(DAY, 6, @CurrFromDate);
-- PREVIOUS WEEK
SET @PrevFromDate = DATEADD(DAY, -7, @CurrFromDate);
SET @PrevToDate = DATEADD(DAY, -7, @CurrToDate);
SET @Diff = 7;
END
ELSE
BEGIN
-- EXPAND TO FULL WEEKS
SET @CurrFromDate = DATEADD(DAY, -(DATEPART(WEEKDAY, @FromDate) - 1), @FromDate);
SET @CurrToDate = DATEADD(DAY,
7 - DATEPART(WEEKDAY, @ToDate),
@ToDate
);
SET @Diff = DATEDIFF(DAY, @CurrFromDate, @CurrToDate) + 1;
SET @PrevFromDate = DATEADD(DAY, -@Diff, @CurrFromDate);
SET @PrevToDate = DATEADD(DAY, -@Diff, @CurrToDate);
END;
-------------------------------------------------------
-- TEAM LEADS (ONLY WITH DATA)
-------------------------------------------------------
;WITH TeamLeads AS
(
SELECT DISTINCT E.EmployeeCode
FROM vw_MasterEmployee E
INNER JOIN EmployeeActivityLogSummary S
ON S.EmployeeCode = E.EmployeeCode
AND S.IsActive = 1
AND S.IsDelete = 0
AND S.LoggedDate BETWEEN @CurrFromDate AND @CurrToDate
WHERE E.MANAGER_1 = @ManagerEmployeeCode
AND (
@TeamLeadEmployeeCode IS NULL
OR E.EmployeeCode = @TeamLeadEmployeeCode
)
),
-------------------------------------------------------
-- EMPLOYEES
-------------------------------------------------------
Employees AS
(
SELECT EmployeeCode FROM TeamLeads
UNION
SELECT DISTINCT E.EmployeeCode
FROM vw_MasterEmployee E
WHERE EXISTS
(
SELECT 1
FROM TeamLeads TL
WHERE TL.EmployeeCode IN
(
E.MANAGER_1, E.MANAGER_2, E.MANAGER_3,
E.MANAGER_4, E.MANAGER_5, E.MANAGER_6, E.MANAGER_7
)
)
),
-------------------------------------------------------
-- DATE RANGES
-------------------------------------------------------
DateRanges AS
(
SELECT 'CURRENT' AS RangeType, @CurrFromDate AS FromDate, @CurrToDate AS ToDate
UNION ALL
SELECT 'PREVIOUS', @PrevFromDate, @PrevToDate
),
-------------------------------------------------------
-- BASE DATA
-------------------------------------------------------
BaseData AS
(
SELECT
DR.RangeType,
CAST(S.LoggedDate AS DATE) AS WorkDate,
S.EmployeeCode,
S.TOT_PRODHOURS,
S.TOT_LOGGEDHOURS
FROM EmployeeActivityLogSummary S
INNER JOIN DateRanges DR
ON S.LoggedDate BETWEEN DR.FromDate AND DR.ToDate
INNER JOIN Employees E
ON E.EmployeeCode = S.EmployeeCode
INNER JOIN vw_MasterEmployee ME
ON ME.EmployeeCode = S.EmployeeCode
LEFT JOIN EmployeeShift ES
ON ES.EmployeeCode = S.EmployeeCode
AND ES.EffectiveFrom <= S.LoggedDate
AND (ES.EffectiveTo IS NULL OR ES.EffectiveTo >= S.LoggedDate)
LEFT JOIN MasterShift MS
ON MS.MasterShiftId = ES.ShiftId
WHERE S.IsActive = 1
AND S.IsDelete = 0
AND (
@SearchText IS NULL OR @SearchText = ''
OR ME.FullName LIKE '%' + @SearchText + '%'
)
AND (
@ShiftName IS NULL OR @ShiftName = ''
OR UPPER(MS.Name) = UPPER(@ShiftName)
)
AND (
@Geo IS NULL OR @Geo = ''
OR UPPER(ME.City) = UPPER(@Geo)
)
),
-------------------------------------------------------
-- FILTERED DATA
-------------------------------------------------------
FilteredData AS
(
SELECT *
FROM BaseData
WHERE
DATENAME(WEEKDAY, WorkDate) NOT IN ('Saturday','Sunday')
AND TOT_LOGGEDHOURS > 0
),
-------------------------------------------------------
-- DAILY PRODUCTIVITY
-------------------------------------------------------
DailyProductivity AS
(
SELECT
RangeType,
WorkDate,
SUM(TOT_PRODHOURS) * 100.0
/ NULLIF(SUM(TOT_LOGGEDHOURS), 0) AS ProductivityPercent
FROM FilteredData
GROUP BY RangeType, WorkDate
)
-------------------------------------------------------
-- FINAL OUTPUT
-------------------------------------------------------
SELECT
C.WorkDate,
DATENAME(WEEKDAY, C.WorkDate) AS DayName,
CAST(C.ProductivityPercent AS DECIMAL(10,2)) AS CurrentProductivity,
CAST(
CASE
-- SAME DATE → STRICT WEEK
WHEN @FromDate = @ToDate
THEN PStrict.ProductivityPercent
-- RANGE → FALLBACK LOGIC
ELSE PFallback.ProductivityPercent
END
AS DECIMAL(10,2)) AS PreviousProductivity
FROM DailyProductivity C
-------------------------------------------------------
-- STRICT WEEK COMPARISON
-------------------------------------------------------
LEFT JOIN DailyProductivity PStrict
ON PStrict.WorkDate = DATEADD(DAY, -7, C.WorkDate)
AND PStrict.RangeType = 'PREVIOUS'
-------------------------------------------------------
-- RANGE FALLBACK LOGIC
-------------------------------------------------------
OUTER APPLY
(
SELECT TOP 1 P.ProductivityPercent
FROM DailyProductivity P
WHERE P.RangeType = 'PREVIOUS'
AND P.WorkDate <= DATEADD(DAY, -@Diff, C.WorkDate)
ORDER BY P.WorkDate DESC
) PFallback
WHERE C.RangeType = 'CURRENT'
ORDER BY C.WorkDate;
END
