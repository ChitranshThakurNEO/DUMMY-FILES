CREATE PROCEDURE [dbo].[sp_ManagerDashboard_SpanTimeAllocation]
(
@ManagerEmployeeCode VARCHAR(20),
@FromDate DATE,
@ToDate DATE,
@WorkMode VARCHAR(20) = NULL
)
AS
BEGIN
SET NOCOUNT ON;
---------------------------------------------------
-- TEAM LEADS
---------------------------------------------------
;WITH TeamLeads AS
(
SELECT DISTINCT
EmployeeCode,
WORK_MODE
FROM vw_MasterEmployee
WHERE LTRIM(RTRIM(MANAGER_1))
= LTRIM(RTRIM(@ManagerEmployeeCode))
AND
(
@WorkMode IS NULL
OR @WorkMode = ''
OR UPPER(ISNULL(WORK_MODE,'')) = UPPER(@WorkMode)
)
)
---------------------------------------------------
-- ASSOCIATES + TEAM LEADS
---------------------------------------------------
, Associates AS
(
SELECT EmployeeCode
FROM TeamLeads
UNION
SELECT DISTINCT
E.EmployeeCode
FROM vw_MasterEmployee E
INNER JOIN TeamLeads TL
ON TL.EmployeeCode = E.MANAGER_1
OR TL.EmployeeCode = E.MANAGER_2
OR TL.EmployeeCode = E.MANAGER_3
OR TL.EmployeeCode = E.MANAGER_4
OR TL.EmployeeCode = E.MANAGER_5
OR TL.EmployeeCode = E.MANAGER_6
OR TL.EmployeeCode = E.MANAGER_7
WHERE
(
@WorkMode IS NULL
OR @WorkMode = ''
OR UPPER(ISNULL(E.WORK_MODE,'')) = UPPER(@WorkMode)
)
)
---------------------------------------------------
-- PRODUCTIVE
---------------------------------------------------
, ProductiveData AS
(
SELECT
'Productive Apps' AS CategoryName,
'#22C55E' AS ColorHex,
CAST(
SUM(mal.DurationSeconds) / 3600.0
AS DECIMAL(18,2)
) AS TotalHours
FROM Associates A
INNER JOIN MasterActivityLog MAL
ON MAL.EmployeeCode = A.EmployeeCode
WHERE MAL.LogDate BETWEEN @FromDate AND @ToDate
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
AND MAL.Status = 'Productive'
)
---------------------------------------------------
-- NO IMPACT
---------------------------------------------------
, NoImpactData AS
(
SELECT
'No Impact' AS CategoryName,
'#3B82F6' AS ColorHex,
CAST(
SUM(mal.DurationSeconds) / 3600.0
AS DECIMAL(18,2)
) AS TotalHours
FROM Associates A
INNER JOIN MasterActivityLog MAL
ON MAL.EmployeeCode = A.EmployeeCode
WHERE MAL.LogDate BETWEEN @FromDate AND @ToDate
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
AND MAL.Status = 'No-Impact'
)
---------------------------------------------------
-- NON PRODUCTIVE
---------------------------------------------------
, NonProductiveData AS
(
SELECT
'Non Productive' AS CategoryName,
'#EF4444' AS ColorHex,
CAST(
SUM(mal.DurationSeconds) / 3600.0
AS DECIMAL(18,2)
) AS TotalHours
FROM Associates A
INNER JOIN MasterActivityLog MAL
ON MAL.EmployeeCode = A.EmployeeCode
WHERE MAL.LogDate BETWEEN @FromDate AND @ToDate
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
AND MAL.Status = 'Non-Productive'
)
---------------------------------------------------
-- IDLE
---------------------------------------------------
, IdleData AS
(
SELECT
'Idle' AS CategoryName,
'#9333EA' AS ColorHex,
CAST(
SUM(mal.DurationSeconds) / 3600.0
AS DECIMAL(18,2)
) AS TotalHours
FROM Associates A
INNER JOIN MasterActivityLog MAL
ON MAL.EmployeeCode = A.EmployeeCode
WHERE MAL.LogDate BETWEEN @FromDate AND @ToDate
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
AND MAL.Status = 'Idle'
)
---------------------------------------------------
-- COMBINED
---------------------------------------------------
, CombinedData AS
(
SELECT * FROM ProductiveData
UNION ALL
SELECT * FROM NoImpactData
UNION ALL
SELECT * FROM NonProductiveData
UNION ALL
SELECT * FROM IdleData
)
---------------------------------------------------
-- TOTAL
---------------------------------------------------
, TotalData AS
(
SELECT
SUM(TotalHours) AS GrandTotalHours
FROM CombinedData
)
---------------------------------------------------
-- FINAL
---------------------------------------------------
SELECT
cd.CategoryName,
ROUND(
cd.TotalHours * 100.0
/ NULLIF(td.GrandTotalHours,0),
2
) AS Percentage,
cd.ColorHex,
cd.TotalHours,
(
SELECT COUNT(*)
FROM Associates
) AS TotalAssociates
FROM CombinedData cd
CROSS JOIN TotalData td
WHERE ISNULL(cd.TotalHours,0) > 0
ORDER BY Percentage DESC;
END
