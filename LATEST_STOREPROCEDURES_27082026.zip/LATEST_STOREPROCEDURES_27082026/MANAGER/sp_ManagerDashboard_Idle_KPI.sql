CREATE OR ALTER PROCEDURE [dbo].[sp_ManagerDashboard_Idle_KPI]
(
@EmployeeCode NVARCHAR(100),
@FromDate DATE,
@ToDate DATE,
@IdleThreshold DECIMAL(18,2) = 14
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
-------------------------------------------------------
-- 1. RANGE HANDLING
--
-- IMPORTANT:
-- When FromDate = ToDate:
--
-- CURRENT = requested date
-- PREVIOUS = previous equivalent date
--
-- This matches sp_ManagerDashboard_KPI_Trend
-------------------------------------------------------
DECLARE @CurrFromDate DATE;
DECLARE @CurrToDate DATE;
DECLARE @PrevFromDate DATE;
DECLARE @PrevToDate DATE;
DECLARE @Days INT;
SET @Days =
DATEDIFF
(
DAY,
@FromDate,
@ToDate
) + 1;
IF @FromDate = @ToDate
BEGIN
---------------------------------------------------
-- EXACT CURRENT DATE
---------------------------------------------------
SET @CurrFromDate = @FromDate;
SET @CurrToDate = @ToDate;
---------------------------------------------------
-- EXACT PREVIOUS DATE
--
-- Example:
-- Current = 2026-06-02
-- Previous = 2026-06-01
---------------------------------------------------
SET @PrevFromDate = DATEADD(DAY, -1, @FromDate);
SET @PrevToDate = DATEADD(DAY, -1, @ToDate);
END
ELSE
BEGIN
---------------------------------------------------
-- MULTI-DATE RANGE
--
-- Keep the existing Sunday-Saturday behaviour
---------------------------------------------------
SET @CurrFromDate =
DATEADD
(
DAY,
-(DATEPART(WEEKDAY, @FromDate) - 1),
@FromDate
);
SET @CurrToDate =
DATEADD
(
DAY,
7 - DATEPART(WEEKDAY, @ToDate),
@ToDate
);
SET @Days =
DATEDIFF
(
DAY,
@CurrFromDate,
@CurrToDate
) + 1;
SET @PrevFromDate =
DATEADD
(
DAY,
-@Days,
@CurrFromDate
);
SET @PrevToDate =
DATEADD
(
DAY,
-@Days,
@CurrToDate
);
END;
-------------------------------------------------------
-- 2. CLEANUP
-------------------------------------------------------
IF OBJECT_ID('tempdb..#TeamLeads') IS NOT NULL
DROP TABLE #TeamLeads;
IF OBJECT_ID('tempdb..#Employees') IS NOT NULL
DROP TABLE #Employees;
IF OBJECT_ID('tempdb..#BaseData') IS NOT NULL
DROP TABLE #BaseData;
IF OBJECT_ID('tempdb..#CurrentData') IS NOT NULL
DROP TABLE #CurrentData;
IF OBJECT_ID('tempdb..#PreviousData') IS NOT NULL
DROP TABLE #PreviousData;
IF OBJECT_ID('tempdb..#EmployeeIdle') IS NOT NULL
DROP TABLE #EmployeeIdle;
IF OBJECT_ID('tempdb..#TeamSummary') IS NOT NULL
DROP TABLE #TeamSummary;
-------------------------------------------------------
-- 3. TEAM LEADS
-------------------------------------------------------
SELECT
EmployeeCode,
FullName
INTO #TeamLeads
FROM vw_MasterEmployee
WHERE
MANAGER_1 = @EmployeeCode
AND ACTIVE_SEPARATED = 'ACTIVE';
-------------------------------------------------------
-- 4. EMPLOYEES
-------------------------------------------------------
SELECT DISTINCT
EmployeeCode
INTO #Employees
FROM
(
---------------------------------------------------
-- TEAM LEADS
---------------------------------------------------
SELECT
EmployeeCode
FROM #TeamLeads
UNION ALL
---------------------------------------------------
-- ASSOCIATES
---------------------------------------------------
SELECT
EMP.EmployeeCode
FROM vw_MasterEmployee EMP
WHERE EXISTS
(
SELECT 1
FROM #TeamLeads TL
WHERE TL.EmployeeCode IN
(
EMP.MANAGER_1,
EMP.MANAGER_2,
EMP.MANAGER_3,
EMP.MANAGER_4,
EMP.MANAGER_5,
EMP.MANAGER_6,
EMP.MANAGER_7
)
)
) A;
CREATE CLUSTERED INDEX IX_Employees
ON #Employees(EmployeeCode);
-------------------------------------------------------
-- 5. BASE DATA
-------------------------------------------------------
SELECT
S.EmployeeCode,
CAST(S.LoggedDate AS DATE) AS WorkDate,
S.TOT_LOGGEDHOURS,
S.TOT_ACTIVEHOURS,
S.TOT_IDLETIME,
S.TOT_PRODHOURS,
ME.MANAGER_1 AS TeamLeadCode,
TL.FullName AS TeamLeadName
INTO #BaseData
FROM EmployeeActivityLogSummary S
INNER JOIN #Employees E
ON E.EmployeeCode = S.EmployeeCode
INNER JOIN vw_MasterEmployee ME
ON ME.EmployeeCode = S.EmployeeCode
LEFT JOIN vw_MasterEmployee TL
ON TL.EmployeeCode = ME.MANAGER_1
WHERE
S.IsActive = 1
AND S.IsDelete = 0
AND S.TOT_LOGGEDHOURS > 0
AND S.LoggedDate
BETWEEN @PrevFromDate
AND @CurrToDate
---------------------------------------------------
-- Keep Monday-Friday only
---------------------------------------------------
AND DATEPART(WEEKDAY, S.LoggedDate)
NOT IN (1, 7);
CREATE CLUSTERED INDEX IX_BaseData
ON #BaseData(EmployeeCode, WorkDate);
-------------------------------------------------------
-- 6. CURRENT DATA
-------------------------------------------------------
SELECT
EmployeeCode,
TeamLeadCode,
TeamLeadName,
TOT_LOGGEDHOURS,
TOT_ACTIVEHOURS,
TOT_IDLETIME,
TOT_PRODHOURS,
CAST
(
TOT_IDLETIME * 100.0
/
NULLIF(TOT_LOGGEDHOURS, 0)
AS DECIMAL(18,2)
) AS IdlePercentage
INTO #CurrentData
FROM #BaseData
WHERE
WorkDate BETWEEN @CurrFromDate AND @CurrToDate;
CREATE CLUSTERED INDEX IX_CurrentData
ON #CurrentData(EmployeeCode);
-------------------------------------------------------
-- 7. PREVIOUS DATA
-------------------------------------------------------
SELECT
EmployeeCode,
TeamLeadCode,
TeamLeadName,
TOT_LOGGEDHOURS,
TOT_ACTIVEHOURS,
TOT_IDLETIME,
TOT_PRODHOURS,
CAST
(
TOT_IDLETIME * 100.0
/
NULLIF(TOT_LOGGEDHOURS, 0)
AS DECIMAL(18,2)
) AS IdlePercentage
INTO #PreviousData
FROM #BaseData
WHERE
WorkDate BETWEEN @PrevFromDate AND @PrevToDate;
CREATE CLUSTERED INDEX IX_PreviousData
ON #PreviousData(EmployeeCode);
-------------------------------------------------------
-- 8. VARIABLES
-------------------------------------------------------
DECLARE
@SpanIdlePercentage DECIMAL(18,2),
@PreviousSpanIdlePercentage DECIMAL(18,2),
@AverageIdleSeconds BIGINT,
@WithinTarget INT,
@ExceedingTarget INT,
@TotalAssociates INT;
-------------------------------------------------------
-- 9. CURRENT SUMMARY
-------------------------------------------------------
DECLARE
@CurrentIdle DECIMAL(38,10),
@CurrentLogged DECIMAL(38,10),
@PreviousIdle DECIMAL(38,10),
@PreviousLogged DECIMAL(38,10);
-------------------------------------------------------
-- CURRENT TOTALS
-------------------------------------------------------
SELECT
@CurrentIdle =
ISNULL(SUM(TOT_IDLETIME), 0),
@CurrentLogged =
ISNULL(SUM(TOT_LOGGEDHOURS), 0),
@AverageIdleSeconds =
ISNULL(AVG(TOT_IDLETIME), 0),
@TotalAssociates =
COUNT(DISTINCT EmployeeCode)
FROM #CurrentData;
-------------------------------------------------------
-- PREVIOUS TOTALS
-------------------------------------------------------
SELECT
@PreviousIdle =
ISNULL(SUM(TOT_IDLETIME), 0),
@PreviousLogged =
ISNULL(SUM(TOT_LOGGEDHOURS), 0)
FROM #PreviousData;
-------------------------------------------------------
-- 10. SPAN IDLE %
--
-- IMPORTANT FIX
--
-- SpanIdlePercentage now uses the PREVIOUS period
-- calculation.
--
-- This is the same calculation used by:
--
-- sp_ManagerDashboard_KPI_Trend
--
-- Previous_Idle_Percentage
--
-- Example:
--
-- Previous Idle = 8.71
-- Span Idle = 8.71
-------------------------------------------------------
SET @PreviousSpanIdlePercentage  =
CAST
(
@PreviousIdle * 100.0
/
NULLIF(@PreviousLogged, 0)
AS DECIMAL(18,2)
);
-------------------------------------------------------
-- 11. PREVIOUS SPAN IDLE %
--
-- Current period is retained here for comparison.
-------------------------------------------------------
SET @SpanIdlePercentage =
CAST
(
@CurrentIdle * 100.0
/
NULLIF(@CurrentLogged, 0)
AS DECIMAL(18,2)
);
-------------------------------------------------------
-- 12. EMPLOYEE IDLE
--
-- Current-period employee calculations remain based
-- on CURRENT data.
-------------------------------------------------------
SELECT
EmployeeCode,
TeamLeadCode,
TeamLeadName,
CAST
(
SUM(TOT_IDLETIME) * 100.0
/
NULLIF(SUM(TOT_LOGGEDHOURS), 0)
AS DECIMAL(18,2)
) AS IdlePercentage
INTO #EmployeeIdle
FROM #CurrentData
GROUP BY
EmployeeCode,
TeamLeadCode,
TeamLeadName;
CREATE CLUSTERED INDEX IX_EmployeeIdle
ON #EmployeeIdle(EmployeeCode);
-------------------------------------------------------
-- 13. TARGET COUNTS
-------------------------------------------------------
SELECT
@WithinTarget =
COUNT
(
CASE
WHEN IdlePercentage <= @IdleThreshold
THEN 1
END
),
@ExceedingTarget =
COUNT
(
CASE
WHEN IdlePercentage > @IdleThreshold
THEN 1
END
)
FROM #EmployeeIdle;
-------------------------------------------------------
-- 14. TEAM SUMMARY
-------------------------------------------------------
SELECT
TeamLeadCode,
TeamLeadName,
COUNT(*) AS Associates,
CAST
(
AVG(IdlePercentage)
AS DECIMAL(18,2)
) AS TeamIdlePercentage
INTO #TeamSummary
FROM #EmployeeIdle
GROUP BY
TeamLeadCode,
TeamLeadName;
CREATE CLUSTERED INDEX IX_TeamSummary
ON #TeamSummary(TeamLeadCode);
-------------------------------------------------------
-- 15. BEST TEAM
-------------------------------------------------------
DECLARE
@BestTeamCode NVARCHAR(100),
@BestTeamName NVARCHAR(200),
@BestTeamAssociates INT,
@BestTeamIdlePercentage DECIMAL(18,2);
SELECT TOP (1)
@BestTeamCode = TeamLeadCode,
@BestTeamName = TeamLeadName,
@BestTeamAssociates = Associates,
@BestTeamIdlePercentage = TeamIdlePercentage
FROM #TeamSummary
ORDER BY
TeamIdlePercentage ASC,
Associates DESC;
-------------------------------------------------------
-- 16. TREND
-------------------------------------------------------
DECLARE @SpanIdleTrend DECIMAL(18,2);
SET @SpanIdleTrend =
CASE
WHEN ISNULL(@PreviousSpanIdlePercentage, 0) = 0
THEN 0
ELSE
@SpanIdlePercentage
-
@PreviousSpanIdlePercentage
END;
-------------------------------------------------------
-- 17. FINAL RESULT
-------------------------------------------------------
SELECT
---------------------------------------------------
-- SPAN IDLE %
---------------------------------------------------
CAST
(
ISNULL(@SpanIdlePercentage, 0)
AS DECIMAL(18,2)
) AS SpanIdlePercentage,
---------------------------------------------------
-- PREVIOUS SPAN IDLE %
---------------------------------------------------
CAST
(
ISNULL(@PreviousSpanIdlePercentage, 0)
AS DECIMAL(18,2)
) AS PreviousSpanIdlePercentage,
---------------------------------------------------
-- SPAN TREND
---------------------------------------------------
CAST
(
ISNULL(@SpanIdleTrend, 0)
AS DECIMAL(18,2)
) AS SpanIdleTrend,
---------------------------------------------------
-- AVERAGE IDLE TIME / DAY
---------------------------------------------------
CONVERT
(
VARCHAR(8),
DATEADD
(
SECOND,
ISNULL(@AverageIdleSeconds, 0),
0
),
108
) AS AverageIdleTime,
---------------------------------------------------
-- WITHIN TARGET
---------------------------------------------------
ISNULL(@WithinTarget, 0)
AS WithinTarget,
---------------------------------------------------
-- EXCEEDING TARGET
---------------------------------------------------
ISNULL(@ExceedingTarget, 0)
AS ExceedingTarget,
---------------------------------------------------
-- BEST TEAM CODE
---------------------------------------------------
ISNULL(@BestTeamCode, '')
AS TeamLeadCode,
---------------------------------------------------
-- BEST TEAM NAME
---------------------------------------------------
ISNULL(@BestTeamName, '')
AS TeamLeadName,
---------------------------------------------------
-- BEST TEAM ASSOCIATES
---------------------------------------------------
ISNULL(@BestTeamAssociates, 0)
AS Associates,
---------------------------------------------------
-- BEST TEAM IDLE %
---------------------------------------------------
CAST
(
ISNULL(@BestTeamIdlePercentage, 0)
AS DECIMAL(18,2)
) AS BestTeamIdlePercentage,
---------------------------------------------------
-- TARGET %
---------------------------------------------------
CAST
(
@IdleThreshold
AS DECIMAL(18,2)
) AS TargetPercentage,
---------------------------------------------------
-- TOTAL ASSOCIATES
---------------------------------------------------
ISNULL(@TotalAssociates, 0)
AS TotalAssociates,
---------------------------------------------------
-- TREND DIRECTION
---------------------------------------------------
CASE
WHEN ISNULL(@SpanIdleTrend, 0) > 0
THEN 'Increase'
WHEN ISNULL(@SpanIdleTrend, 0) < 0
THEN 'Decrease'
ELSE 'Same'
END AS TrendDirection,
---------------------------------------------------
-- BEST TEAM STATUS
---------------------------------------------------
CASE
WHEN ISNULL(@BestTeamIdlePercentage, 0)
<= @IdleThreshold
THEN 'Within Target'
ELSE 'Above Target'
END AS BestTeamStatus;
-------------------------------------------------------
-- 18. CLEANUP
-------------------------------------------------------
DROP TABLE #TeamSummary;
DROP TABLE #EmployeeIdle;
DROP TABLE #CurrentData;
DROP TABLE #PreviousData;
DROP TABLE #BaseData;
DROP TABLE #Employees;
DROP TABLE #TeamLeads;
END
