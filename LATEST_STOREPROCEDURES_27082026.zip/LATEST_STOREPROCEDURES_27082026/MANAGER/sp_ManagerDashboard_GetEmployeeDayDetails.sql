CREATE OR ALTER PROCEDURE [dbo].[sp_ManagerDashboard_GetEmployeeDayDetails]
(
    @ManagerEmployeeCode VARCHAR(50),
    @LoggedDate DATE
)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @TotalActiveSeconds BIGINT = 0;
    DECLARE @TotalLoggedSeconds BIGINT = 0;

    ---------------------------------------------------
    -- ACTIVE SECONDS
    -- (EXCLUDE IDLE FOR APPLICATION USAGE)
    ---------------------------------------------------
    SELECT
        @TotalActiveSeconds =
        ISNULL(SUM(DurationSeconds), 0)
    FROM MasterActivityLog
    WHERE EmployeeCode = @ManagerEmployeeCode
    AND LogDate = @LoggedDate
    AND IsDelete = 0
    AND Status IN
    (
        'Productive',
        'Non-Productive',
        'No-Impact'
    );

    ---------------------------------------------------
    -- LOGGED SECONDS
    -- (INCLUDE IDLE FOR TIME DISTRIBUTION)
    ---------------------------------------------------
    SELECT
        @TotalLoggedSeconds =
        ISNULL(SUM(DurationSeconds), 0)
    FROM MasterActivityLog
    WHERE EmployeeCode = @ManagerEmployeeCode
    AND LogDate = @LoggedDate
    AND IsDelete = 0;

    ---------------------------------------------------
    -- RESULT SET 1 : SUMMARY
    ---------------------------------------------------
    SELECT
        EAS.EmployeeCode,
        VE.FullName,
        EAS.LoggedDate,
        EAS.TOT_LOGGEDHOURS,
        EAS.TOT_ACTIVEHOURS,
        EAS.TOT_PRODHOURS,
        EAS.TOT_TIMEONSYSTEM,
        EAS.TOT_TIMEAWAYFROMSYSTEM,
        EAS.TOT_IDLETIME,
        EAS.FIRSTLOGIN,
        EAS.LASTLOGOUT,
        EAS.AttendanceStatus,
        ROUND
        (
            CASE
                WHEN EAS.TOT_LOGGEDHOURS = 0
                THEN 0
                ELSE
                (
                    EAS.TOT_PRODHOURS * 100.0
                ) / EAS.TOT_LOGGEDHOURS
            END,
            2
        ) AS ProductivityPercentage
    FROM EmployeeActivityLogSummary EAS
    INNER JOIN vw_MasterEmployee VE
        ON VE.EmployeeCode = EAS.EmployeeCode
    WHERE EAS.EmployeeCode = @ManagerEmployeeCode
    AND EAS.LoggedDate = @LoggedDate
    AND EAS.IsDelete = 0;

    ---------------------------------------------------
    -- RESULT SET 2 : APPLICATION BREAKDOWN
    -- PERCENTAGE BASED ON ACTIVE TIME ONLY
    ---------------------------------------------------
    SELECT
        MAC.SubCategoryName AS ApplicationName,
        MAC.CategoryName,

        SUM(MAL.DurationSeconds) AS DurationSeconds,

        ROUND
        (
            SUM(MAL.DurationSeconds) / 60.0,
            2
        ) AS DurationMinutes,

        ROUND
        (
            SUM(MAL.DurationSeconds) / 3600.0,
            2
        ) AS DurationHours,

        ROUND
        (
            SUM(MAL.DurationSeconds) * 100.0
            /
            NULLIF(@TotalActiveSeconds, 0),
            2
        ) AS Percentage,

        MAL.Status AS ProductivityType,
        MAC.ColorHex

    FROM MasterActivityLog MAL
    INNER JOIN MasterActivityCategory MAC
        ON MAL.CategoryId = MAC.MasterActivityCategoryId

    WHERE MAL.EmployeeCode = @ManagerEmployeeCode
    AND MAL.LogDate = @LoggedDate
    AND MAL.IsDelete = 0
    AND MAL.Status IN
    (
        'Productive',
        'Non-Productive',
        'No-Impact'
    )

    GROUP BY
        MAC.CategoryName,
        MAC.SubCategoryName,
        MAL.Status,
        MAC.ColorHex

    ORDER BY
        SUM(MAL.DurationSeconds) DESC;

    ---------------------------------------------------
    -- RESULT SET 3 : TIME DISTRIBUTION
    -- PERCENTAGE BASED ON LOGGED TIME
    -- INCLUDES IDLE
    ---------------------------------------------------
    SELECT

        ROUND
        (
            SUM
            (
                CASE
                    WHEN MAL.Status = 'Productive'
                    THEN MAL.DurationSeconds
                    ELSE 0
                END
            ) * 100.0
            /
            NULLIF(@TotalLoggedSeconds, 0),
            2
        ) AS ProductivePercentage,

        ROUND
        (
            SUM
            (
                CASE
                    WHEN MAL.Status = 'Non-Productive'
                    THEN MAL.DurationSeconds
                    ELSE 0
                END
            ) * 100.0
            /
            NULLIF(@TotalLoggedSeconds, 0),
            2
        ) AS NonProductivePercentage,

        ROUND
        (
            SUM
            (
                CASE
                    WHEN MAL.Status = 'No-Impact'
                    THEN MAL.DurationSeconds
                    ELSE 0
                END
            ) * 100.0
            /
            NULLIF(@TotalLoggedSeconds, 0),
            2
        ) AS NeutralPercentage,

        ROUND
        (
            SUM
            (
                CASE
                    WHEN MAL.Status = 'Idle'
                    THEN MAL.DurationSeconds
                    ELSE 0
                END
            ) * 100.0
            /
            NULLIF(@TotalLoggedSeconds, 0),
            2
        ) AS IdlePercentage

    FROM MasterActivityLog MAL
    WHERE MAL.EmployeeCode = @ManagerEmployeeCode
    AND MAL.LogDate = @LoggedDate
    AND MAL.IsDelete = 0;
END
GO