CREATE PROCEDURE [dbo].[sp_ManagerDashboard_ProductivityReport_Distribution]
(
@ManagerEmployeeCode NVARCHAR(100),
@FromDate DATE,
@ToDate DATE,
@TeamLeadEmployeeCode NVARCHAR(100) = NULL
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
-------------------------------------------------------
-- RANGE LOGIC
-------------------------------------------------------
DECLARE @CurrFromDate DATE;
DECLARE @CurrToDate DATE;
IF @FromDate = @ToDate
BEGIN
SET @CurrFromDate = @FromDate;
SET @CurrToDate = @ToDate;
END
ELSE
BEGIN
SET @CurrFromDate = DATEADD(DAY, -(DATEPART(WEEKDAY,@FromDate)-1), @FromDate);
SET @CurrToDate = DATEADD(DAY, 7 - DATEPART(WEEKDAY,@ToDate), @ToDate);
END;
-------------------------------------------------------
-- TEAM STRUCTURE
-------------------------------------------------------
;WITH TeamLeads AS
(
SELECT EmployeeCode
FROM vw_MasterEmployee
WHERE MANAGER_1 = @ManagerEmployeeCode
AND (
@TeamLeadEmployeeCode IS NULL
OR EmployeeCode = @TeamLeadEmployeeCode
)
),
Employees AS
(
SELECT EmployeeCode FROM TeamLeads
UNION
SELECT E.EmployeeCode
FROM vw_MasterEmployee E
WHERE EXISTS
(
SELECT 1 FROM TeamLeads TL
WHERE TL.EmployeeCode IN
(
E.MANAGER_1, E.MANAGER_2, E.MANAGER_3,
E.MANAGER_4, E.MANAGER_5, E.MANAGER_6, E.MANAGER_7
)
)
),
-------------------------------------------------------
-- BASE ACTIVITY DATA (IMPORTANT)
-------------------------------------------------------
BaseData AS
(
SELECT
S.EmployeeCode,
S.TOT_PRODHOURS,
S.TOT_LOGGEDHOURS,
S.LoggedDate
FROM EmployeeActivityLogSummary S
INNER JOIN Employees E
ON E.EmployeeCode = S.EmployeeCode
WHERE S.IsActive = 1
AND S.IsDelete = 0
AND S.LoggedDate BETWEEN @CurrFromDate AND @CurrToDate
AND S.TOT_LOGGEDHOURS > 0
AND DATENAME(WEEKDAY, S.LoggedDate) NOT IN ('Saturday','Sunday')
),
-------------------------------------------------------
-- EMPLOYEE PRODUCTIVITY
-------------------------------------------------------
EmployeeProductivity AS
(
SELECT
EmployeeCode,
SUM(TOT_PRODHOURS) * 100.0
/ NULLIF(SUM(TOT_LOGGEDHOURS),0) AS Productivity
FROM BaseData
GROUP BY EmployeeCode
),
-------------------------------------------------------
-- BUCKET CLASSIFICATION
-------------------------------------------------------
Bucketed AS
(
SELECT
CASE
WHEN Productivity < 40 THEN '0-40%'
WHEN Productivity >= 40 AND Productivity < 60 THEN '40-60%'
WHEN Productivity >= 60 AND Productivity < 70 THEN '60-70%'
WHEN Productivity >= 70 AND Productivity < 80 THEN '70-80%'
ELSE '80%+'
END AS ProductivityRange
FROM EmployeeProductivity
)
-------------------------------------------------------
-- FINAL OUTPUT
-------------------------------------------------------
SELECT
ProductivityRange,
COUNT(*) AS EmployeeCount
FROM Bucketed
GROUP BY ProductivityRange
ORDER BY
CASE ProductivityRange
WHEN '0-40%' THEN 1
WHEN '40-60%' THEN 2
WHEN '60-70%' THEN 3
WHEN '70-80%' THEN 4
WHEN '80%+' THEN 5
END;
END
