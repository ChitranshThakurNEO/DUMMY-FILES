CREATE PROCEDURE [dbo].[sp_ManagerDashboard_ProductivityReport_ProductiveAppMix]
(
@ManagerEmployeeCode NVARCHAR(100),
@FromDate DATE,
@ToDate DATE,
@TeamLeadEmployeeCode NVARCHAR(100) = NULL
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
-------------------------------------------------------
-- RANGE LOGIC
-------------------------------------------------------
DECLARE @CurrFromDate DATE;
DECLARE @CurrToDate DATE;
IF @FromDate = @ToDate
BEGIN
SET @CurrFromDate = @FromDate;
SET @CurrToDate = @ToDate;
END
ELSE
BEGIN
SET @CurrFromDate = DATEADD(DAY, -(DATEPART(WEEKDAY,@FromDate)-1), @FromDate);
SET @CurrToDate = DATEADD(DAY, 7 - DATEPART(WEEKDAY,@ToDate), @ToDate);
END;
-------------------------------------------------------
-- TEAM STRUCTURE
-------------------------------------------------------
;WITH TeamLeads AS
(
SELECT EmployeeCode
FROM vw_MasterEmployee
WHERE MANAGER_1 = @ManagerEmployeeCode
AND (
@TeamLeadEmployeeCode IS NULL
OR EmployeeCode = @TeamLeadEmployeeCode
)
),
Employees AS
(
SELECT EmployeeCode FROM TeamLeads
UNION
SELECT E.EmployeeCode
FROM vw_MasterEmployee E
WHERE EXISTS
(
SELECT 1 FROM TeamLeads TL
WHERE TL.EmployeeCode IN
(
E.MANAGER_1, E.MANAGER_2, E.MANAGER_3,
E.MANAGER_4, E.MANAGER_5, E.MANAGER_6, E.MANAGER_7
)
)
),
-------------------------------------------------------
-- BASE DATA (ACTUAL ACTIVITY LOG )
-------------------------------------------------------
ActivityData AS
(
SELECT
MAL.EmployeeCode,
MAL.CategoryId,
MAL.LogDate,
MAL.DurationSeconds
FROM MasterActivityLog MAL
INNER JOIN Employees E
ON E.EmployeeCode = MAL.EmployeeCode
WHERE MAL.LogDate BETWEEN @CurrFromDate AND @CurrToDate
AND MAL.DurationSeconds > 0
),
-------------------------------------------------------
-- JOIN CATEGORY (KEY FIX )
-------------------------------------------------------
ProductiveData AS
(
SELECT
MAC.CategoryName,
MAC.SubCategoryName,
AD.DurationSeconds
FROM ActivityData AD
INNER JOIN MasterActivityCategory MAC
ON MAC.MasterActivityCategoryId = AD.CategoryId
WHERE MAC.IsProductive = 1
),
-------------------------------------------------------
-- AGGREGATION
-------------------------------------------------------
AppAgg AS
(
SELECT
CategoryName,
SubCategoryName,
SUM(DurationSeconds) / 3600.0 AS TotalHours
FROM ProductiveData
GROUP BY CategoryName, SubCategoryName
),
-------------------------------------------------------
-- TOTAL
-------------------------------------------------------
TotalAgg AS
(
SELECT SUM(TotalHours) AS GrandTotal
FROM AppAgg
)
-------------------------------------------------------
-- FINAL OUTPUT
-------------------------------------------------------
SELECT
CategoryName,
SubCategoryName,
CAST(TotalHours AS DECIMAL(10,2)) AS ProductiveHours,
CAST(
(TotalHours * 100.0) / NULLIF(T.GrandTotal,0)
AS DECIMAL(10,2)) AS ContributionPercent
FROM AppAgg A
CROSS JOIN TotalAgg T
ORDER BY ContributionPercent DESC;
END
