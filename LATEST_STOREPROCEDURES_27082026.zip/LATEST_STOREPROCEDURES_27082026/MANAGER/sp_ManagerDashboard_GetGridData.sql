CREATE PROCEDURE [dbo].[sp_ManagerDashboard_GetGridData]
(
@ManagerEmployeeCode NVARCHAR(100),
@FromDate DATE,
@ToDate DATE,
@TeamLeadEmployeeCode NVARCHAR(100) = NULL,
@Geo NVARCHAR(50) = NULL,
@SearchText NVARCHAR(100) = NULL
)
AS
BEGIN
SET NOCOUNT ON;
IF OBJECT_ID('tempdb..#EmployeeGridData') IS NOT NULL
DROP TABLE #EmployeeGridData;
;WITH TeamLeads AS
(
SELECT DISTINCT
EmployeeCode
FROM vw_MasterEmployee
WHERE MANAGER_1 = @ManagerEmployeeCode
),
EmployeesUnderManager AS
(
SELECT EmployeeCode
FROM TeamLeads
UNION
SELECT DISTINCT
E.EmployeeCode
FROM vw_MasterEmployee E
INNER JOIN TeamLeads TL
ON TL.EmployeeCode = E.MANAGER_1
OR TL.EmployeeCode = E.MANAGER_2
OR TL.EmployeeCode = E.MANAGER_3
OR TL.EmployeeCode = E.MANAGER_4
OR TL.EmployeeCode = E.MANAGER_5
OR TL.EmployeeCode = E.MANAGER_6
OR TL.EmployeeCode = E.MANAGER_7
)
SELECT
ME.EmployeeCode,
ME.FullName AS EmployeeName,
ME.JOB_TITLE AS DESIGNATION,
ME.CITY AS GEO,
EAS.LoggedDate,
EAS.TOT_ACTIVEHOURS,
EAS.TOT_LOGGEDHOURS,
EAS.AttendanceStatus,
EAS.DayType,
CASE
WHEN EAS.AttendanceStatus = 'Leave'
AND ISNULL(EAS.TOT_LOGGEDHOURS, 0) = 0
THEN 'LV'
WHEN (
EAS.DayType = 'Weekend'
OR EAS.AttendanceStatus = 'Holiday'
)
AND ISNULL(EAS.TOT_LOGGEDHOURS, 0) = 0
THEN '-'
ELSE
RIGHT(
'0' + CAST(
FLOOR(ISNULL(EAS.TOT_ACTIVEHOURS, 0))
AS VARCHAR
),
2
)
+ ':'
+ RIGHT(
'0' + CAST(
CAST(
(ISNULL(EAS.TOT_ACTIVEHOURS, 0) * 60) % 60
AS INT
) AS VARCHAR
),
2
)
END AS DisplayValue,
CASE
WHEN EAS.AttendanceStatus = 'Present'
THEN CAST(ISNULL(EAS.TOT_ACTIVEHOURS, 0) * 60 AS INT)
ELSE 0
END AS ActiveMinutes
INTO #EmployeeGridData
FROM EmployeeActivityLogSummary EAS
INNER JOIN vw_MasterEmployee ME
ON EAS.EmployeeCode = ME.EmployeeCode
INNER JOIN EmployeesUnderManager EM
ON EM.EmployeeCode = ME.EmployeeCode
WHERE EAS.IsDelete = 0
AND EAS.LoggedDate BETWEEN @FromDate AND @ToDate
AND
(
@TeamLeadEmployeeCode IS NULL
OR ME.EmployeeCode = @TeamLeadEmployeeCode
OR ME.MANAGER_1 = @TeamLeadEmployeeCode
)
AND
(
@Geo IS NULL
OR ME.CITY = @Geo
)
AND
(
@SearchText IS NULL
OR ME.FullName LIKE '%' + @SearchText + '%'
OR ME.EmployeeCode LIKE '%' + @SearchText + '%'
);
---------------------------------------------------
-- RESULT SET 1 : EMPLOYEE GRID
---------------------------------------------------
SELECT
EmployeeCode,
EmployeeName,
DESIGNATION,
GEO,
LoggedDate,
DisplayValue,
SUM(ActiveMinutes)
OVER (PARTITION BY EmployeeCode)
AS TotalMinutes,
CASE
WHEN COUNT(
CASE
WHEN AttendanceStatus = 'Present'
THEN 1
END
) OVER (PARTITION BY EmployeeCode) = 0
THEN 0
ELSE
SUM(ActiveMinutes)
OVER (PARTITION BY EmployeeCode)
/
COUNT(
CASE
WHEN AttendanceStatus = 'Present'
THEN 1
END
) OVER (PARTITION BY EmployeeCode)
END AS AvgMinutesPerDay
FROM #EmployeeGridData
ORDER BY EmployeeName, LoggedDate;
---------------------------------------------------
-- RESULT SET 2 : TEAM AVERAGE
---------------------------------------------------
SELECT
LoggedDate,
CASE
WHEN COUNT(
CASE
WHEN AttendanceStatus = 'Present'
THEN 1
END
) = 0
THEN '-'
ELSE
RIGHT(
'0' + CAST(
FLOOR(
AVG(
CASE
WHEN AttendanceStatus = 'Present'
THEN TOT_ACTIVEHOURS
END
)
) AS VARCHAR
),
2
)
+ ':'
+ RIGHT(
'0' + CAST(
CAST(
(
AVG(
CASE
WHEN AttendanceStatus = 'Present'
THEN TOT_ACTIVEHOURS
END
) * 60
) % 60
AS INT
) AS VARCHAR
),
2
)
END AS TeamAverageDisplay
FROM #EmployeeGridData
GROUP BY LoggedDate
ORDER BY LoggedDate;
END
