CREATE PROCEDURE [dbo].[sp_ManagerDashboard_TeamProductivityComparison]
(
@ManagerEmployeeCode VARCHAR(20),
@FromDate DATE,
@ToDate DATE,
@WorkMode VARCHAR(20) = NULL
)
AS
BEGIN
SET NOCOUNT ON;
---------------------------------------------------
-- TEAM LEADS
---------------------------------------------------
;WITH TeamLeads AS
(
SELECT
EmployeeCode,
FullName,
WORK_MODE
FROM vw_MasterEmployee
WHERE MANAGER_1 = @ManagerEmployeeCode
AND
(
@WorkMode IS NULL
OR @WorkMode = ''
OR UPPER(ISNULL(WORK_MODE,'')) = UPPER(@WorkMode)
)
)
---------------------------------------------------
-- ASSOCIATES + TEAM LEADS
---------------------------------------------------
, Associates AS
(
---------------------------------------------------
-- Employees under Team Leads
---------------------------------------------------
SELECT DISTINCT
E.EmployeeCode,
E.FullName,
TL.FullName AS TeamLeadName
FROM vw_MasterEmployee E
INNER JOIN TeamLeads TL
ON TL.EmployeeCode = E.MANAGER_1
OR TL.EmployeeCode = E.MANAGER_2
OR TL.EmployeeCode = E.MANAGER_3
OR TL.EmployeeCode = E.MANAGER_4
OR TL.EmployeeCode = E.MANAGER_5
OR TL.EmployeeCode = E.MANAGER_6
OR TL.EmployeeCode = E.MANAGER_7
WHERE
(
@WorkMode IS NULL
OR @WorkMode = ''
OR UPPER(ISNULL(E.WORK_MODE,'')) = UPPER(@WorkMode)
)
UNION
---------------------------------------------------
-- INCLUDE TEAM LEADS THEMSELVES
---------------------------------------------------
SELECT
TL.EmployeeCode,
TL.FullName,
TL.FullName AS TeamLeadName
FROM TeamLeads TL
)
---------------------------------------------------
-- ACTIVITY DATA
---------------------------------------------------
, ActivityData AS
(
SELECT
A.TeamLeadName,
CAST(
SUM(CASE
WHEN MAL.Status = 'Productive'
THEN MAL.DurationSeconds
ELSE 0
END) / 3600.0
AS DECIMAL(18,2)) AS ProductiveHours,
MAX(CASE
WHEN MAL.Status = 'Productive'
THEN MAC.ColorHex
END) AS ProductiveColorHex,
CAST(
SUM(CASE
WHEN MAL.Status = 'Non-Productive'
THEN MAL.DurationSeconds
ELSE 0
END) / 3600.0
AS DECIMAL(18,2)) AS NonProductiveHours,
MAX(CASE
WHEN MAL.Status = 'Non-Productive'
THEN MAC.ColorHex
END) AS NonProductiveColorHex,
CAST(
SUM(CASE
WHEN MAL.Status = 'No-Impact'
THEN MAL.DurationSeconds
ELSE 0
END) / 3600.0
AS DECIMAL(18,2)) AS NoImpactHours,
MAX(CASE
WHEN MAL.Status = 'No-Impact'
THEN MAC.ColorHex
END) AS NeutralColorHex,
CAST(
SUM(CASE
WHEN MAL.Status = 'Idle'
THEN MAL.DurationSeconds
ELSE 0
END) / 3600.0
AS DECIMAL(18,2)) AS IdleHours,
MAX(CASE
WHEN MAL.Status = 'Idle'
THEN MAC.ColorHex
END) AS IdleAwayColorHex
FROM Associates A
LEFT JOIN MasterActivityLog MAL
ON MAL.EmployeeCode = A.EmployeeCode
AND MAL.LogDate BETWEEN @FromDate AND @ToDate
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
LEFT JOIN MasterActivityCategory MAC
ON MAC.MasterActivityCategoryId = MAL.MasterActivityCategoryId
GROUP BY
A.TeamLeadName
)
---------------------------------------------------
-- FINAL DATA
---------------------------------------------------
, FinalData AS
(
SELECT
TeamLeadName,
ISNULL(ProductiveHours,0) AS ProductiveHours,
ISNULL(NonProductiveHours,0) AS NonProductiveHours,
ISNULL(NoImpactHours,0) AS NoImpactHours,
ISNULL(IdleHours,0) AS IdleHours,
ISNULL(ProductiveHours,0)
+ ISNULL(NonProductiveHours,0)
+ ISNULL(NoImpactHours,0)
+ ISNULL(IdleHours,0)
AS TotalHours,
ProductiveColorHex,
NonProductiveColorHex,
NeutralColorHex,
IdleAwayColorHex
FROM ActivityData
)
---------------------------------------------------
-- FINAL OUTPUT
---------------------------------------------------
SELECT
TeamLeadName,
ISNULL
(
ROUND
(
ProductiveHours * 100.0
/ NULLIF(TotalHours,0),
0
),
0
) AS ProductivePercent,
ISNULL
(
ROUND
(
NoImpactHours * 100.0
/ NULLIF(TotalHours,0),
0
),
0
) AS NeutralPercent,
ISNULL
(
ROUND
(
NonProductiveHours * 100.0
/ NULLIF(TotalHours,0),
0
),
0
) AS NonProductivePercent,
ISNULL
(
ROUND
(
IdleHours * 100.0
/ NULLIF(TotalHours,0),
0
),
0
) AS IdleAwayPercent,
ProductiveColorHex,
NonProductiveColorHex,
NeutralColorHex,
IdleAwayColorHex
FROM FinalData
WHERE TotalHours > 0
ORDER BY TeamLeadName;
END
