CREATE PROCEDURE sp_EmployeeDashboard_Logged_SessionLog
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
-------------------------------------------------------
-- CATEGORY WISE TOTALS
-------------------------------------------------------
;WITH ActivityData AS
(
SELECT
MAL.DurationSeconds,
CASE
WHEN MAL.Status = 'Idle'
THEN 'Idle'
WHEN MAC.CategoryName = 'Communication'
THEN 'Meeting'
WHEN MAL.Status IN
(
'Productive',
'Non-Productive',
'No-Impact'
)
AND ISNULL(MAC.CategoryName, '') <> 'Communication'
THEN 'Active'
END AS Category
FROM MasterActivityLog MAL
LEFT JOIN MasterActivityCategory MAC
ON MAC.MasterActivityCategoryId = MAL.CategoryId
WHERE MAL.EmployeeCode = @EmployeeCode
AND CAST(MAL.StartTime AS DATE) = @Date
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
)
SELECT
Category AS [Type],
CASE
WHEN SUM(DurationSeconds) >= 3600
THEN CONCAT
(
SUM(DurationSeconds) / 3600,
'h ',
(SUM(DurationSeconds) % 3600) / 60,
'm'
)
ELSE CONCAT
(
SUM(DurationSeconds) / 60,
'm'
)
END AS Duration
FROM ActivityData
WHERE Category IS NOT NULL
GROUP BY Category
ORDER BY
CASE Category
WHEN 'Active' THEN 1
WHEN 'Meeting' THEN 2
WHEN 'Idle' THEN 3
END;
END