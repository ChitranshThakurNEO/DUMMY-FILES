﻿CREATE PROCEDURE [dbo].[sp_EmployeeDashboard_Logged_30Day_Trend]
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
-------------------------------------------------------
-- DATE RANGE
-------------------------------------------------------
DECLARE @StartDate DATE = DATEADD(DAY, -29, @Date);
-------------------------------------------------------
-- RESULT 1 → DAILY TREND
-------------------------------------------------------
SELECT
CAST(LoggedDate AS DATE) AS WorkDate,
DAY(CAST(LoggedDate AS DATE)) AS DayNumber,
---------------------------------------------------
-- DECIMAL (FOR GRAPH)
---------------------------------------------------
ROUND(
SUM(TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2))),
1
) AS LoggedHours,
---------------------------------------------------
-- FORMATTED (hh:mm:ss)
---------------------------------------------------
CONVERT(VARCHAR(8),
DATEADD(SECOND,
CAST(SUM(TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2))) * 3600 AS INT),
0
),
108) AS LoggedHoursFormatted
FROM EmployeeActivityLogSummary
WHERE
EmployeeCode = @EmployeeCode
AND IsActive = 1
AND IsDelete = 0
AND TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0
AND LoggedDate BETWEEN @StartDate AND @Date
GROUP BY CAST(LoggedDate AS DATE)
ORDER BY WorkDate;
-------------------------------------------------------
-- RESULT 2 → MONTH RANGE
-------------------------------------------------------
DECLARE @StartMonth VARCHAR(20) =
DATENAME(MONTH, @StartDate);
DECLARE @EndMonth VARCHAR(20) =
DATENAME(MONTH, @Date);
DECLARE @YearText VARCHAR(10) =
CAST(YEAR(@Date) AS VARCHAR(10));
SELECT
CASE
WHEN @StartMonth = @EndMonth
THEN CONCAT(@StartMonth, ' ', @YearText)
ELSE CONCAT(@StartMonth, '–', @EndMonth, ' ', @YearText)
END AS MonthRange;
END