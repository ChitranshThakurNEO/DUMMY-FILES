CREATE PROCEDURE [dbo].[sp_EmployeeDashboard_Productivity_TimeClassification]
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
-------------------------------------------------------
-- TIME DATA
-------------------------------------------------------
;WITH TimeData AS
(
SELECT
ISNULL(SUM(TOT_PRODHOURS),0) AS ProductiveHours,
ISNULL(SUM(TOT_NONPRODHOURS),0) AS NonProductiveHours,
ISNULL(SUM(TOT_NOIMPACTHOURS),0) AS NoImpactHours
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE) = @Date
AND IsActive = 1
AND IsDelete = 0
AND TOT_LOGGEDHOURS > 0
),
-------------------------------------------------------
-- RECORD COUNTS
-------------------------------------------------------
RecordCounts AS
(
SELECT
MAL.Status,
COUNT(*) AS RecordCount
FROM MasterActivityLog MAL
WHERE MAL.EmployeeCode = @EmployeeCode
AND CAST(MAL.StartTime AS DATE) = @Date
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
AND MAL.Status IN
(
'Productive',
'Non-Productive',
'No-Impact'
)
GROUP BY MAL.Status
),
-------------------------------------------------------
-- EXPANDED DATA
-------------------------------------------------------
Expanded AS
(
SELECT
'Productive' AS Category,
ProductiveHours AS Hours,
ISNULL
(
(
SELECT RecordCount
FROM RecordCounts
WHERE Status = 'Productive'
),
0
) AS RecordCount
FROM TimeData
UNION ALL
SELECT
'Non-Productive',
NonProductiveHours,
ISNULL
(
(
SELECT RecordCount
FROM RecordCounts
WHERE Status = 'Non-Productive'
),
0
)
FROM TimeData
UNION ALL
SELECT
'No-Impact',
NoImpactHours,
ISNULL
(
(
SELECT RecordCount
FROM RecordCounts
WHERE Status = 'No-Impact'
),
0
)
FROM TimeData
)
-------------------------------------------------------
-- FINAL RESULT
-------------------------------------------------------
SELECT
Category,
dbo.fn_ConvertDecimalHoursToHHMMSS(Hours)
AS Duration,
ROUND
(
(
Hours * 100.0
)
/
NULLIF
(
SUM(Hours) OVER(),
0
),
1
) AS Percentage,
RecordCount
FROM Expanded
WHERE Hours > 0
ORDER BY Percentage DESC;
END