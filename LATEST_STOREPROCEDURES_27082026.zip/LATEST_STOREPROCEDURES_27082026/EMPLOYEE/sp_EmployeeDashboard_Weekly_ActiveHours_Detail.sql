CREATE PROCEDURE [dbo].[sp_EmployeeDashboard_Weekly_ActiveHours_Detail]
(
@EmployeeCode NVARCHAR(100),
@CurrentDate DATE,
@MinFocusMinutes INT
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
DECLARE @MinSeconds INT = @MinFocusMinutes * 60;
-------------------------------------------------------
-- WEEK RANGE
-------------------------------------------------------
DECLARE @WeekStart DATE =
DATEADD(DAY, -(DATEPART(WEEKDAY,@CurrentDate)-1), @CurrentDate);
DECLARE @WeekEnd DATE = DATEADD(DAY, 6, @WeekStart);
-------------------------------------------------------
-- MANAGER + TEAM
-------------------------------------------------------
DECLARE @ManagerCode NVARCHAR(100);
SELECT @ManagerCode = MANAGER_1
FROM vw_MasterEmployee
WHERE EmployeeCode = @EmployeeCode;
DECLARE @Team TABLE (EmployeeCode NVARCHAR(100) PRIMARY KEY);
INSERT INTO @Team
SELECT EmployeeCode
FROM vw_MasterEmployee
WHERE MANAGER_1 = @ManagerCode;
-------------------------------------------------------
-- WEEK DAYS
-------------------------------------------------------
CREATE TABLE #Days(
WorkDate DATE
);
;WITH Dates AS
(
SELECT @WeekStart AS WorkDate
UNION ALL
SELECT DATEADD(DAY,1,WorkDate)
FROM Dates
WHERE WorkDate < @WeekEnd
)
INSERT INTO #Days
SELECT WorkDate
FROM Dates
OPTION (MAXRECURSION 7);
-------------------------------------------------------
-- SUMMARY DATA
-------------------------------------------------------
WITH Summary AS
(
SELECT
EmployeeCode,
CAST(LoggedDate AS DATE) WorkDate,
TOT_ACTIVEHOURS,
TOT_LOGGEDHOURS,
TOT_LOGGEDHOURS_AC
FROM EmployeeActivityLogSummary
WHERE
LoggedDate BETWEEN @WeekStart AND @WeekEnd
AND TOT_LOGGEDHOURS > 0
AND IsActive = 1
AND IsDelete = 0
),
Me AS
(
SELECT * FROM Summary WHERE EmployeeCode = @EmployeeCode
),
TeamCalc AS
(
SELECT
WorkDate,
EmployeeCode,
TOT_ACTIVEHOURS,
AVG(TOT_ACTIVEHOURS) OVER(PARTITION BY WorkDate) AS TeamAvg,
RANK() OVER(PARTITION BY WorkDate ORDER BY TOT_ACTIVEHOURS DESC) AS RankPos,
COUNT(*) OVER(PARTITION BY WorkDate) AS TeamSize
FROM Summary
WHERE EmployeeCode IN (SELECT EmployeeCode FROM @Team)
),
-------------------------------------------------------
-- PEAK HOUR
-------------------------------------------------------
PeakHour AS
(
SELECT WorkDate, PeakHourStart
FROM
(
SELECT
CAST(StartTime AS DATE) WorkDate,
DATEPART(HOUR, DATEADD(SECOND, DurationSeconds/2, StartTime)) PeakHourStart,
SUM(DurationSeconds) TotalSec,
ROW_NUMBER() OVER (
PARTITION BY CAST(StartTime AS DATE)
ORDER BY SUM(DurationSeconds) DESC
) rn
FROM MasterActivityLog
WHERE
EmployeeCode = @EmployeeCode
AND Status <> 'Idle'
AND StartTime BETWEEN @WeekStart AND DATEADD(DAY,1,@WeekEnd)
GROUP BY
CAST(StartTime AS DATE),
DATEPART(HOUR, DATEADD(SECOND, DurationSeconds/2, StartTime))
) X
WHERE rn = 1
),
-------------------------------------------------------
-- FOCUS BLOCK LOGIC (FIXED NO NESTING)
-------------------------------------------------------
FocusBase AS
(
SELECT
StartTime,
EndTime,
DurationSeconds,
CAST(StartTime AS DATE) AS WorkDate
FROM MasterActivityLog
WHERE
EmployeeCode = @EmployeeCode
AND Status <> 'Idle'
AND StartTime BETWEEN @WeekStart AND DATEADD(DAY,1,@WeekEnd)
),
FocusBreaks AS
(
SELECT *,
CASE
WHEN LAG(EndTime) OVER (
PARTITION BY WorkDate ORDER BY StartTime
) = StartTime THEN 0
ELSE 1
END AS BreakFlag
FROM FocusBase
),
FocusGroups AS
(
SELECT *,
SUM(BreakFlag) OVER (
PARTITION BY WorkDate ORDER BY StartTime
ROWS UNBOUNDED PRECEDING
) AS GroupId
FROM FocusBreaks
),
FocusBlocks AS
(
SELECT
WorkDate,
GroupId,
SUM(DurationSeconds) AS BlockSeconds
FROM FocusGroups
GROUP BY WorkDate, GroupId
HAVING SUM(DurationSeconds) >= @MinSeconds
),
FocusCalc AS
(
SELECT
WorkDate,
SUM(BlockSeconds)/60.0 AS FocusMinutes
FROM FocusBlocks
GROUP BY WorkDate
)
-------------------------------------------------------
-- FINAL OUTPUT
-------------------------------------------------------
SELECT
DATENAME(WEEKDAY,D.WorkDate) + ' ' + FORMAT(D.WorkDate,'dd MMM') AS Day,
ISNULL(M.TOT_LOGGEDHOURS_AC,'0h 00m') AS Logged,
CONCAT(
FLOOR(ISNULL(M.TOT_ACTIVEHOURS,0)),'h ',
CAST((ISNULL(M.TOT_ACTIVEHOURS,0) - FLOOR(ISNULL(M.TOT_ACTIVEHOURS,0))) * 60 AS INT),'m'
) AS Active,
CASE
WHEN ISNULL(M.TOT_LOGGEDHOURS,0) = 0 THEN '0%'
ELSE CONCAT(
CAST((M.TOT_ACTIVEHOURS * 100.0 / M.TOT_LOGGEDHOURS) AS INT),'%'
)
END AS Utilisation,
CONCAT(
FLOOR(ISNULL(F.FocusMinutes,0)/60),'h ',
CAST(ISNULL(F.FocusMinutes,0)%60 AS INT),'m'
) AS FocusTime,
CONCAT(P.PeakHourStart,'-',P.PeakHourStart+1) AS PeakHour,
CONCAT(
CASE WHEN (ISNULL(M.TOT_ACTIVEHOURS,0) - ISNULL(TC.TeamAvg,0)) >= 0 THEN '+' ELSE '' END,
CAST((ISNULL(M.TOT_ACTIVEHOURS,0) - ISNULL(TC.TeamAvg,0)) * 60 AS INT),'m'
) AS VsTeam,
CONCAT(ISNULL(TC.RankPos,0),' / ',ISNULL(TC.TeamSize,0)) AS TeamRank
FROM #Days D
LEFT JOIN Me M ON M.WorkDate = D.WorkDate
LEFT JOIN TeamCalc TC
ON TC.WorkDate = D.WorkDate AND TC.EmployeeCode = @EmployeeCode
LEFT JOIN PeakHour P ON P.WorkDate = D.WorkDate
LEFT JOIN FocusCalc F ON F.WorkDate = D.WorkDate
WHERE DATENAME(WEEKDAY,D.WorkDate) NOT IN ('Saturday','Sunday')
ORDER BY D.WorkDate;
END