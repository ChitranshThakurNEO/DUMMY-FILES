CREATE PROCEDURE [dbo].[sp_EmployeeDashboard_Productivity_WTD_Trend]
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
-------------------------------------------------------
-- WEEK RANGE
-------------------------------------------------------
DECLARE @WeekStart DATE =
DATEADD(
DAY,
-(DATEPART(WEEKDAY, @Date) - 1),
@Date
);
DECLARE @WeekEnd DATE =
DATEADD(
DAY,
5,
@WeekStart
);
-------------------------------------------------------
-- RESULT
-------------------------------------------------------
SELECT
CAST(LoggedDate AS DATE) AS WorkDate,
DATENAME(WEEKDAY, CAST(LoggedDate AS DATE))
+ ' '
+ RIGHT(
CONVERT(
VARCHAR(10),
CAST(LoggedDate AS DATE),
105
),
2
) AS DayLabel,
ROUND
(
(
TOT_PRODHOURS * 100.0
)
/
NULLIF(
TOT_LOGGEDHOURS,
0
),
1
) AS ProductivityPercentage
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND IsActive = 1
AND IsDelete = 0
AND TOT_LOGGEDHOURS > 0
AND CAST(LoggedDate AS DATE)
BETWEEN @WeekStart AND @WeekEnd
ORDER BY WorkDate;
END
