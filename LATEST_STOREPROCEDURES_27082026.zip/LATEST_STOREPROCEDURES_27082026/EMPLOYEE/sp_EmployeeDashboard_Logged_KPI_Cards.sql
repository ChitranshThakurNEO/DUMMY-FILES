CREATE PROCEDURE [dbo].[sp_EmployeeDashboard_Logged_KPI_Cards]
(
@EmployeeCode NVARCHAR(100),
@Date DATE,
@WeeklyTargetHours DECIMAL(10,2),
@DailyTargetHours DECIMAL(10,2),
@OvertimeThreshold DECIMAL(10,2)
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
-------------------------------------------------------
-- PREP
-------------------------------------------------------
DECLARE @PrevDate DATE = DATEADD(DAY,-1,@Date);
DECLARE @WeekStart DATE =
DATEADD(DAY, -(DATEPART(WEEKDAY,@Date)-1), @Date);
DECLARE @WeekEnd DATE = DATEADD(DAY, 6, @WeekStart); -- FULL WEEK
-------------------------------------------------------
-- NUMERIC VARIABLES
-------------------------------------------------------
DECLARE @TodayLogged DECIMAL(10,2) = 0;
DECLARE @PrevLogged DECIMAL(10,2) = 0;
DECLARE @WTDLogged DECIMAL(10,2) = 0;
DECLARE @Overtime DECIMAL(10,2) = 0;
-------------------------------------------------------
-- STRING VARIABLES
-------------------------------------------------------
DECLARE @TodayLoggedStr VARCHAR(100);
DECLARE @WTDHoursStr VARCHAR(20);
DECLARE @OvertimeStr VARCHAR(20);
-------------------------------------------------------
-- TODAY / PREVIOUS
-------------------------------------------------------
SELECT
@TodayLogged = ISNULL(TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)),0),
@TodayLoggedStr = ISNULL(TOT_LOGGEDHOURS_AC,'0h 00m')
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE) = @Date;
SELECT
@PrevLogged = ISNULL(TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)),0)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE) = @PrevDate
AND TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0;
-------------------------------------------------------
-- VARIANCE (MINUTES)
-------------------------------------------------------
DECLARE @VarianceMinutes INT =
CAST((@TodayLogged - @PrevLogged) * 60 AS INT);
-------------------------------------------------------
-- WTD (FULL WEEK )
-------------------------------------------------------
SELECT
@WTDLogged = ISNULL(SUM(TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2))),0)
FROM EmployeeActivityLogSummary
WHERE
EmployeeCode = @EmployeeCode
AND LoggedDate BETWEEN @WeekStart AND @WeekEnd
AND IsActive = 1
AND IsDelete = 0
AND TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0;
-------------------------------------------------------
-- WTD %
-------------------------------------------------------
DECLARE @WTDPercent DECIMAL(10,2) =
CASE
WHEN @WeeklyTargetHours = 0 THEN 0
ELSE (@WTDLogged / @WeeklyTargetHours) * 100
END;
-------------------------------------------------------
-- FORMAT WTD
-------------------------------------------------------
SET @WTDHoursStr =
CONCAT(
FLOOR(@WTDLogged),'h ',
CAST((@WTDLogged - FLOOR(@WTDLogged)) * 60 AS INT),'m'
);
-------------------------------------------------------
-- LOGIN / LOGOUT
-------------------------------------------------------
DECLARE @LoginTime TIME;
DECLARE @LogoutTime TIME;
SELECT
@LoginTime = MIN(FIRSTLOGIN),
@LogoutTime = MAX(LASTLOGOUT)
FROM EmployeeActivityLogSummary
WHERE
EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE) = @Date;
-------------------------------------------------------
-- OVERTIME
-------------------------------------------------------
SET @Overtime =
CASE
WHEN @TodayLogged > @OvertimeThreshold
THEN @TodayLogged - @OvertimeThreshold
ELSE 0
END;
SET @OvertimeStr =
CONCAT(
FLOOR(@Overtime),'h ',
CAST((@Overtime - FLOOR(@Overtime)) * 60 AS INT),'m'
);
-------------------------------------------------------
-- STREAK
-------------------------------------------------------
DECLARE @Streak INT = 0;
;WITH StreakData AS
(
SELECT
CAST(LoggedDate AS DATE) WorkDate,
TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) AS LoggedHours,
ROW_NUMBER() OVER (ORDER BY LoggedDate DESC) AS RN
FROM EmployeeActivityLogSummary
WHERE
EmployeeCode = @EmployeeCode
AND IsActive = 1
AND IsDelete = 0
AND LoggedDate <= @Date
AND TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0
),
Qualified AS
(
SELECT *
FROM StreakData
WHERE LoggedHours >= @DailyTargetHours
),
G AS
(
SELECT
WorkDate,
RN,
DATEADD(DAY,-RN,WorkDate) grp
FROM Qualified
)
SELECT TOP 1
@Streak = COUNT(*)
FROM G
GROUP BY grp
ORDER BY MAX(WorkDate) DESC;
-------------------------------------------------------
-- FINAL OUTPUT
-------------------------------------------------------
SELECT
@TodayLoggedStr AS LoggedToday,
@VarianceMinutes AS LoggedVarianceMinutes,
@WTDHoursStr AS WTDHours,
@WTDPercent AS WTDPercentage,
@LoginTime AS LoginTime,
@LogoutTime AS LogoutTime,
@OvertimeStr AS OvertimeHours,
ISNULL(@Streak,0) AS Streak;
END