CREATE OR ALTER PROCEDURE sp_EmployeeDashboard_Productivity_HourlyTrend
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
-------------------------------------------------------
-- OffSetMinutes for Time Zone Conversion
-------------------------------------------------------
DECLARE @OffsetMinutes INT = 330;

-------------------------------------------------------
-- HOURS
-------------------------------------------------------
;WITH Hours AS
(
SELECT 0 AS Hr
UNION ALL SELECT 1
UNION ALL SELECT 2
UNION ALL SELECT 3
UNION ALL SELECT 4
UNION ALL SELECT 5
UNION ALL SELECT 6
UNION ALL SELECT 7
UNION ALL SELECT 8
UNION ALL SELECT 9
UNION ALL SELECT 10
UNION ALL SELECT 11
UNION ALL SELECT 12
UNION ALL SELECT 13
UNION ALL SELECT 14
UNION ALL SELECT 15
UNION ALL SELECT 16
UNION ALL SELECT 17
UNION ALL SELECT 18
UNION ALL SELECT 19
UNION ALL SELECT 20
UNION ALL SELECT 21
UNION ALL SELECT 22
UNION ALL SELECT 23
),
-------------------------------------------------------
-- ACTIVITIES
-------------------------------------------------------
Activities AS
(
SELECT
dbo.fn_ConvertUtcToLocal(StartTime, @OffsetMinutes) AS StartTime,
dbo.fn_ConvertUtcToLocal(EndTime, @OffsetMinutes) AS EndTime,
Status
FROM MasterActivityLog
WHERE EmployeeCode = @EmployeeCode
AND CAST
(
dbo.fn_ConvertUtcToLocal(StartTime, @OffsetMinutes)
AS DATE
) = @Date
AND IsActive = 1
AND IsDelete = 0
AND Status IN
(
'Productive',
'Non-Productive',
'No-Impact',
'Idle'
)
),
-------------------------------------------------------
-- SPLIT ACTIVITIES ACROSS HOURS
-------------------------------------------------------
Expanded AS
(
SELECT
H.Hr,
A.Status,
DATEDIFF
(
SECOND,
CASE
WHEN A.StartTime >
DATEADD(HOUR, H.Hr, CAST(@Date AS DATETIME))
THEN A.StartTime
ELSE DATEADD(HOUR, H.Hr, CAST(@Date AS DATETIME))
END,
CASE
WHEN A.EndTime <
DATEADD(HOUR, H.Hr + 1, CAST(@Date AS DATETIME))
THEN A.EndTime
ELSE DATEADD(HOUR, H.Hr + 1, CAST(@Date AS DATETIME))
END
) AS OverlapSeconds
FROM Hours H
INNER JOIN Activities A
ON A.StartTime <
DATEADD(HOUR, H.Hr + 1, CAST(@Date AS DATETIME))
AND A.EndTime >
DATEADD(HOUR, H.Hr, CAST(@Date AS DATETIME))
),
-------------------------------------------------------
-- HOUR SUMMARY
-------------------------------------------------------
HourSummary AS
(
SELECT
H.Hr,
SUM
(
CASE
WHEN E.Status = 'Productive'
THEN E.OverlapSeconds
ELSE 0
END
) AS ProductiveSeconds,
SUM
(
CASE
WHEN E.Status = 'Non-Productive'
THEN E.OverlapSeconds
ELSE 0
END
) AS NonProductiveSeconds,
SUM
(
CASE
WHEN E.Status = 'No-Impact'
THEN E.OverlapSeconds
ELSE 0
END
) AS NoImpactSeconds,
SUM
(
CASE
WHEN E.Status = 'Idle'
THEN E.OverlapSeconds
ELSE 0
END
) AS IdleSeconds
FROM Hours H
LEFT JOIN Expanded E
ON E.Hr = H.Hr
GROUP BY
H.Hr
)
-------------------------------------------------------
-- FINAL OUTPUT
-------------------------------------------------------
SELECT
Hr AS [Hour],
ROUND
(
ISNULL(ProductiveSeconds, 0)
* 100.0
/ NULLIF
(
ISNULL(ProductiveSeconds, 0)
+ ISNULL(NonProductiveSeconds, 0)
+ ISNULL(NoImpactSeconds, 0)
+ ISNULL(IdleSeconds, 0),
0
),
1
) AS ProductivePercentage,
ROUND
(
ISNULL(NonProductiveSeconds, 0)
* 100.0
/ NULLIF
(
ISNULL(ProductiveSeconds, 0)
+ ISNULL(NonProductiveSeconds, 0)
+ ISNULL(NoImpactSeconds, 0)
+ ISNULL(IdleSeconds, 0),
0
),
1
) AS NonProductivePercentage,
ROUND
(
ISNULL(NoImpactSeconds, 0)
* 100.0
/ NULLIF
(
ISNULL(ProductiveSeconds, 0)
+ ISNULL(NonProductiveSeconds, 0)
+ ISNULL(NoImpactSeconds, 0)
+ ISNULL(IdleSeconds, 0),
0
),
1
) AS NoImpactPercentage,
ROUND
(
ISNULL(IdleSeconds, 0)
* 100.0
/ NULLIF
(
ISNULL(ProductiveSeconds, 0)
+ ISNULL(NonProductiveSeconds, 0)
+ ISNULL(NoImpactSeconds, 0)
+ ISNULL(IdleSeconds, 0),
0
),
1
) AS IdlePercentage
FROM HourSummary
ORDER BY Hr;
END