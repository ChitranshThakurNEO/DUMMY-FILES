CREATE PROCEDURE [dbo].[sp_EmployeeDashboardMonthlyAvgProductivity]
(
@EmployeeCode VARCHAR(50),
@FromDate DATE,
@ToDate DATE,
@TargetProductivityPercentage DECIMAL(10,2)
)
AS
BEGIN
SET NOCOUNT ON;
DECLARE @IsMonthMode BIT =
CASE WHEN @FromDate = @ToDate THEN 1 ELSE 0 END;
DECLARE @ActualFromDate DATE;
DECLARE @ActualToDate DATE;
DECLARE @PreviousFromDate DATE;
DECLARE @PreviousToDate DATE;
DECLARE @CurrentMonthName VARCHAR(50) = NULL;
DECLARE @PreviousMonthName VARCHAR(50) = NULL;
IF @IsMonthMode = 1
BEGIN
SET @ActualFromDate = DATEFROMPARTS(YEAR(@FromDate), MONTH(@FromDate), 1);
SET @ActualToDate = EOMONTH(@FromDate);
SET @PreviousFromDate =
DATEFROMPARTS
(
YEAR(DATEADD(MONTH,-1,@FromDate)),
MONTH(DATEADD(MONTH,-1,@FromDate)),
1
);
SET @PreviousToDate = EOMONTH(DATEADD(MONTH,-1,@FromDate));
SET @CurrentMonthName = DATENAME(MONTH,@ActualFromDate);
SET @PreviousMonthName = DATENAME(MONTH,@PreviousFromDate);
END
ELSE
BEGIN
SET @ActualFromDate = @FromDate;
SET @ActualToDate = @ToDate;
END
IF OBJECT_ID('tempdb..#CurrentDays') IS NOT NULL DROP TABLE #CurrentDays;
IF OBJECT_ID('tempdb..#PreviousDays') IS NOT NULL DROP TABLE #PreviousDays;
IF OBJECT_ID('tempdb..#DailyProductivity') IS NOT NULL DROP TABLE #DailyProductivity;
CREATE TABLE #CurrentDays
(
LoggedDate DATE PRIMARY KEY
);
CREATE TABLE #PreviousDays
(
LoggedDate DATE PRIMARY KEY
);
CREATE TABLE #DailyProductivity
(
PeriodType VARCHAR(20),
LogDate DATE,
TotalLoggedHours DECIMAL(18,2),
ProductiveHours DECIMAL(18,2),
ProductivityPercentage DECIMAL(10,2)
);
------------------------------------------------------------
-- CURRENT PERIOD WORKING DAYS
------------------------------------------------------------
INSERT INTO #CurrentDays
(
LoggedDate
)
SELECT LoggedDate
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate BETWEEN @ActualFromDate AND @ActualToDate
AND IsActive = 1
AND IsDelete = 0
AND TOT_LOGGEDHOURS > 0
AND AttendanceStatus = 'Present'
AND DayType NOT IN ('Weekend','Holiday');
DECLARE @CurrentWorkingDays INT =
(
SELECT COUNT(*)
FROM #CurrentDays
);
------------------------------------------------------------
-- PREVIOUS PERIOD WORKING DAYS
------------------------------------------------------------
IF @IsMonthMode = 1
BEGIN
INSERT INTO #PreviousDays
(
LoggedDate
)
SELECT LoggedDate
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate BETWEEN @PreviousFromDate AND @PreviousToDate
AND IsActive = 1
AND IsDelete = 0
AND TOT_LOGGEDHOURS > 0
AND AttendanceStatus = 'Present'
AND DayType NOT IN ('Weekend','Holiday');
END
ELSE
BEGIN
INSERT INTO #PreviousDays
(
LoggedDate
)
SELECT TOP (@CurrentWorkingDays)
LoggedDate
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate < @FromDate
AND IsActive = 1
AND IsDelete = 0
AND TOT_LOGGEDHOURS > 0
AND AttendanceStatus = 'Present'
AND DayType NOT IN ('Weekend','Holiday')
ORDER BY LoggedDate DESC;
END
------------------------------------------------------------
-- CURRENT PERIOD PRODUCTIVITY
------------------------------------------------------------
INSERT INTO #DailyProductivity
SELECT
'Current',
EALS.LoggedDate,
EALS.TOT_LOGGEDHOURS,
ISNULL(EALS.TOT_PRODHOURS,0),
CAST
(
CASE
WHEN EALS.TOT_LOGGEDHOURS = 0
THEN 0
ELSE
(ISNULL(EALS.TOT_PRODHOURS,0) * 100.0)
/ EALS.TOT_LOGGEDHOURS
END
AS DECIMAL(10,2))
FROM EmployeeActivityLogSummary EALS
INNER JOIN #CurrentDays CD
ON CD.LoggedDate = EALS.LoggedDate
WHERE EALS.EmployeeCode = @EmployeeCode
UNION ALL
------------------------------------------------------------
-- PREVIOUS PERIOD PRODUCTIVITY
------------------------------------------------------------
SELECT
'Previous',
EALS.LoggedDate,
EALS.TOT_LOGGEDHOURS,
ISNULL(EALS.TOT_PRODHOURS,0),
CAST
(
CASE
WHEN EALS.TOT_LOGGEDHOURS = 0
THEN 0
ELSE
(ISNULL(EALS.TOT_PRODHOURS,0) * 100.0)
/ EALS.TOT_LOGGEDHOURS
END
AS DECIMAL(10,2))
FROM EmployeeActivityLogSummary EALS
INNER JOIN #PreviousDays PD
ON PD.LoggedDate = EALS.LoggedDate
WHERE EALS.EmployeeCode = @EmployeeCode;
------------------------------------------------------------
-- AVERAGES
------------------------------------------------------------
DECLARE @CurrentProductivityPercentage DECIMAL(10,2);
DECLARE @PreviousProductivityPercentage DECIMAL(10,2);
SELECT
@CurrentProductivityPercentage =
ISNULL(AVG(ProductivityPercentage),0)
FROM #DailyProductivity
WHERE PeriodType = 'Current';
SELECT
@PreviousProductivityPercentage =
ISNULL(AVG(ProductivityPercentage),0)
FROM #DailyProductivity
WHERE PeriodType = 'Previous';
------------------------------------------------------------
-- BEST / LOWEST DAY
------------------------------------------------------------
DECLARE @BestProductivityDay DATE;
DECLARE @BestProductivityPercentage DECIMAL(10,2);
DECLARE @LowestProductivityDay DATE;
DECLARE @LowestProductivityPercentage DECIMAL(10,2);
SELECT TOP 1
@BestProductivityDay = LogDate,
@BestProductivityPercentage = ProductivityPercentage
FROM #DailyProductivity
WHERE PeriodType = 'Current'
AND ProductivityPercentage > 0
ORDER BY ProductivityPercentage DESC, LogDate;
SELECT TOP 1
@LowestProductivityDay = LogDate,
@LowestProductivityPercentage = ProductivityPercentage
FROM #DailyProductivity
WHERE PeriodType = 'Current'
AND ProductivityPercentage > 0
ORDER BY ProductivityPercentage ASC, LogDate;
------------------------------------------------------------
-- TREND
------------------------------------------------------------
DECLARE @RaiseDipPercentage DECIMAL(10,2) =
CASE
WHEN @PreviousProductivityPercentage = 0
THEN 0
ELSE
(
(@CurrentProductivityPercentage
- @PreviousProductivityPercentage)
* 100.0
)
/ @PreviousProductivityPercentage
END;
DECLARE @TrendDirection VARCHAR(20) =
CASE
WHEN @CurrentProductivityPercentage > @PreviousProductivityPercentage
THEN 'up'
WHEN @CurrentProductivityPercentage < @PreviousProductivityPercentage
THEN 'down'
ELSE 'same'
END;
------------------------------------------------------------
-- STATUS
------------------------------------------------------------
DECLARE @Status VARCHAR(50) =
CASE
WHEN @CurrentProductivityPercentage
>= @TargetProductivityPercentage
THEN 'Target Achieved'
ELSE 'Below Target'
END;
------------------------------------------------------------
-- FINAL RESULT
------------------------------------------------------------
SELECT
CAST(@CurrentProductivityPercentage AS DECIMAL(10,2))
AS ProductivityPercentage,
@TargetProductivityPercentage
AS TargetProductivityPercentage,
CAST
(
@CurrentProductivityPercentage
- @TargetProductivityPercentage
AS DECIMAL(10,2))
AS TargetDifferencePercentage,
CAST(@PreviousProductivityPercentage AS DECIMAL(10,2))
AS PreviousProductivityPercentage,
CAST(@RaiseDipPercentage AS DECIMAL(10,2))
AS RaiseDipPercentage,
@TrendDirection
AS TrendDirection,
@Status
AS Status,
@CurrentMonthName
AS CurrentMonthName,
@PreviousMonthName
AS PreviousMonthName,
@BestProductivityDay
AS BestProductivityDay,
@BestProductivityPercentage
AS BestProductivityPercentage,
@LowestProductivityDay
AS LowestProductivityDay,
@LowestProductivityPercentage
AS LowestProductivityPercentage,
@CurrentWorkingDays
AS WorkingDaysConsidered;
END