CREATE OR ALTER PROCEDURE sp_EmployeeDashboard_Logged_Hourly_LoggedMinutes
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
-------------------------------------------------------
-- OffSetMinutes for Time Zone Conversion
-------------------------------------------------------
DECLARE @OffsetMinutes INT = 330;

-------------------------------------------------------
-- HOURS
-------------------------------------------------------
CREATE TABLE #Hours
(
Hr INT
);
INSERT INTO #Hours(Hr)
VALUES
(0),(1),(2),(3),(4),(5),(6),(7),
(8),(9),(10),(11),(12),(13),(14),(15),
(16),(17),(18),(19),(20),(21),(22),(23);
-------------------------------------------------------
-- MEETING / ACTIVITY DATA
-------------------------------------------------------
;WITH ActivityData AS
(
SELECT
    dbo.fn_ConvertUtcToLocal(MAL.StartTime,330) AS StartTime,
    dbo.fn_ConvertUtcToLocal(MAL.EndTime,330) AS EndTime,
    MAL.DurationSeconds,
CASE
WHEN MAL.Status = 'Idle'
THEN 'Idle'
WHEN MAC.CategoryName = 'Communication'
THEN 'Meeting'
WHEN MAL.Status IN
(
'Productive',
'Non-Productive',
'No-Impact'
)
THEN 'Active'
END AS Category
FROM MasterActivityLog MAL
LEFT JOIN MasterActivityCategory MAC
ON MAC.MasterActivityCategoryId = MAL.CategoryId
WHERE MAL.EmployeeCode = @EmployeeCode
AND CAST(
        dbo.fn_ConvertUtcToLocal(MAL.StartTime,330)
    AS DATE) = @Date
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
AND MAL.EndTime IS NOT NULL
),
-------------------------------------------------------
-- SPLIT INTO HOURS
-------------------------------------------------------
Expanded AS
(
SELECT
H.Hr,
A.Category,
DATEDIFF
(
SECOND,
CASE
WHEN A.StartTime >
DATEADD(HOUR, H.Hr, CAST(@Date AS DATETIME))
THEN A.StartTime
ELSE DATEADD(HOUR, H.Hr, CAST(@Date AS DATETIME))
END,
CASE
WHEN A.EndTime <
DATEADD(HOUR, H.Hr + 1, CAST(@Date AS DATETIME))
THEN A.EndTime
ELSE DATEADD(HOUR, H.Hr + 1, CAST(@Date AS DATETIME))
END
) AS Seconds
FROM #Hours H
INNER JOIN ActivityData A
ON A.StartTime <
DATEADD(HOUR, H.Hr + 1, CAST(@Date AS DATETIME))
AND A.EndTime >
DATEADD(HOUR, H.Hr, CAST(@Date AS DATETIME))
)
SELECT
Hr,
Category,
CASE
WHEN Seconds > 0
THEN Seconds
ELSE 0
END AS Seconds
INTO #Clean
FROM Expanded;
-------------------------------------------------------
-- RESULT 1 : HOURLY
-------------------------------------------------------
SELECT
H.Hr AS Hour,
CASE
WHEN ISNULL
(
SUM(CASE WHEN C.Category = 'Active'
THEN C.Seconds END),
0
) / 60.0 > 60
THEN 60
ELSE ISNULL
(
SUM(CASE WHEN C.Category = 'Active'
THEN C.Seconds END),
0
) / 60.0
END AS ActiveMinutes,
CASE
WHEN ISNULL
(
SUM(CASE WHEN C.Category = 'Meeting'
THEN C.Seconds END),
0
) / 60.0 > 60
THEN 60
ELSE ISNULL
(
SUM(CASE WHEN C.Category = 'Meeting'
THEN C.Seconds END),
0
) / 60.0
END AS MeetingMinutes,
CASE
WHEN ISNULL
(
SUM(CASE WHEN C.Category = 'Idle'
THEN C.Seconds END),
0
) / 60.0 > 60
THEN 60
ELSE ISNULL
(
SUM(CASE WHEN C.Category = 'Idle'
THEN C.Seconds END),
0
) / 60.0
END AS IdleMinutes
FROM #Hours H
LEFT JOIN #Clean C
ON C.Hr = H.Hr
GROUP BY H.Hr
ORDER BY H.Hr;
-------------------------------------------------------
-- RESULT 2 : SUMMARY
-------------------------------------------------------
SELECT
CONCAT
(
FLOOR(ISNULL(TRY_CAST(EALS.TOT_ACTIVEHOURS AS DECIMAL(18,2)),0)),
'h ',
CAST
(
(
ISNULL(TRY_CAST(EALS.TOT_ACTIVEHOURS AS DECIMAL(18,2)),0)
-
FLOOR(ISNULL(TRY_CAST(EALS.TOT_ACTIVEHOURS AS DECIMAL(18,2)),0))
) * 60
AS INT
),
'm'
) AS ActiveTotal,
CONCAT
(
FLOOR(ISNULL(M.MeetingSeconds,0) / 3600.0),
'h ',
CAST((ISNULL(M.MeetingSeconds,0) % 3600) / 60 AS INT),
'm'
) AS MeetingTotal,
CONCAT
(
FLOOR(ISNULL(TRY_CAST(EALS.TOT_IDLETIME AS DECIMAL(18,2)),0)),
'h ',
CAST
(
(
ISNULL(TRY_CAST(EALS.TOT_IDLETIME AS DECIMAL(18,2)),0)
-
FLOOR(ISNULL(TRY_CAST(EALS.TOT_IDLETIME AS DECIMAL(18,2)),0))
) * 60
AS INT
),
'm'
) AS IdleTotal
FROM EmployeeActivityLogSummary EALS
OUTER APPLY
(
SELECT
SUM(MAL.DurationSeconds) AS MeetingSeconds
FROM MasterActivityLog MAL
LEFT JOIN MasterActivityCategory MAC
ON MAC.MasterActivityCategoryId = MAL.CategoryId
WHERE MAL.EmployeeCode = @EmployeeCode
AND CAST(MAL.StartTime AS DATE) = @Date
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
AND MAC.CategoryName = 'Communication'
) M
WHERE EALS.EmployeeCode = @EmployeeCode
AND CAST(EALS.LoggedDate AS DATE) = @Date
AND EALS.IsActive = 1
AND EALS.IsDelete = 0;
DROP TABLE #Clean;
DROP TABLE #Hours;
END