CREATE PROCEDURE [dbo].[sp_EmployeeDashboardKPICards]
(
@EmployeeCode VARCHAR(20),
@FromDate DATE,
@ToDate DATE,
@HoursThreshold DECIMAL(10,2)
)
AS
BEGIN
SET NOCOUNT ON;
------------------------------------------------------------
-- VARIABLES
------------------------------------------------------------
DECLARE @RangeDays INT;
DECLARE @PreviousFromDate DATE;
DECLARE @PreviousToDate DATE;
------------------------------------------------------------
-- CURRENT PERIOD
------------------------------------------------------------
DECLARE @AvgLoggedHours DECIMAL(18,2) = 0;
DECLARE @AvgActiveHours DECIMAL(18,2) = 0;
DECLARE @AvgIdleHours DECIMAL(18,2) = 0;
DECLARE @AvgProductivity DECIMAL(18,2) = 0;
------------------------------------------------------------
-- PREVIOUS PERIOD
------------------------------------------------------------
DECLARE @PrevAvgLoggedHours DECIMAL(18,2) = 0;
DECLARE @PrevAvgActiveHours DECIMAL(18,2) = 0;
DECLARE @PrevAvgIdleHours DECIMAL(18,2) = 0;
DECLARE @PrevAvgProductivity DECIMAL(18,2) = 0;
------------------------------------------------------------
-- TREND VARIABLES
------------------------------------------------------------
DECLARE @LoggedTrendPercentage DECIMAL(18,2) = 0;
DECLARE @ActiveTrendPercentage DECIMAL(18,2) = 0;
DECLARE @IdleTrendPercentage DECIMAL(18,2) = 0;
DECLARE @ProductivityTrendPercentage DECIMAL(18,2) = 0;
------------------------------------------------------------
-- COMPLIANCE
------------------------------------------------------------
DECLARE @ComplianceStatus VARCHAR(20) = 'Failed';
------------------------------------------------------------
-- PREVIOUS DATE RANGE
------------------------------------------------------------
SET @RangeDays =
DATEDIFF(DAY, @FromDate, @ToDate) + 1;
SET @PreviousFromDate =
DATEADD(DAY, -@RangeDays, @FromDate);
SET @PreviousToDate =
DATEADD(DAY, -1, @FromDate);
------------------------------------------------------------
-- CURRENT SUMMARY
------------------------------------------------------------
;WITH CurrentSummary AS
(
SELECT
EALS.LoggedDate,
LoggedHours =
ISNULL(EALS.TOT_LOGGEDHOURS, 0),
ActiveHours =
ISNULL(EALS.TOT_ACTIVEHOURS, 0),
IdleHours =
ISNULL(EALS.TOT_IDLETIME, 0),
ProductivityPercentage =
CASE
WHEN ISNULL(EALS.TOT_LOGGEDHOURS, 0) = 0
THEN 0
ELSE
(
ISNULL(EALS.TOT_PRODHOURS, 0) * 100.0
)
/ EALS.TOT_LOGGEDHOURS
END
FROM EmployeeActivityLogSummary EALS
WHERE EALS.EmployeeCode = @EmployeeCode
AND EALS.LoggedDate BETWEEN @FromDate AND @ToDate
AND EALS.IsActive = 1
AND EALS.IsDelete = 0
)
SELECT
@AvgLoggedHours =
AVG(LoggedHours),
@AvgActiveHours =
AVG(ActiveHours),
@AvgIdleHours =
AVG(IdleHours),
@AvgProductivity =
AVG(ProductivityPercentage)
FROM CurrentSummary;
------------------------------------------------------------
-- PREVIOUS SUMMARY
------------------------------------------------------------
;WITH PreviousSummary AS
(
SELECT
EALS.LoggedDate,
LoggedHours =
ISNULL(EALS.TOT_LOGGEDHOURS, 0),
ActiveHours =
ISNULL(EALS.TOT_ACTIVEHOURS, 0),
IdleHours =
ISNULL(EALS.TOT_IDLETIME, 0),
ProductivityPercentage =
CASE
WHEN ISNULL(EALS.TOT_LOGGEDHOURS, 0) = 0
THEN 0
ELSE
(
ISNULL(EALS.TOT_PRODHOURS, 0) * 100.0
)
/ EALS.TOT_LOGGEDHOURS
END
FROM EmployeeActivityLogSummary EALS
WHERE EALS.EmployeeCode = @EmployeeCode
AND EALS.LoggedDate BETWEEN @PreviousFromDate
AND @PreviousToDate
AND EALS.IsActive = 1
AND EALS.IsDelete = 0
)
SELECT
@PrevAvgLoggedHours =
AVG(LoggedHours),
@PrevAvgActiveHours =
AVG(ActiveHours),
@PrevAvgIdleHours =
AVG(IdleHours),
@PrevAvgProductivity =
AVG(ProductivityPercentage)
FROM PreviousSummary;
------------------------------------------------------------
-- TREND CALCULATIONS
------------------------------------------------------------
SET @LoggedTrendPercentage =
CASE
WHEN ISNULL(@PrevAvgLoggedHours, 0) = 0
THEN 0
ELSE
((@AvgLoggedHours - @PrevAvgLoggedHours) * 100.0)
/ @PrevAvgLoggedHours
END;
SET @ActiveTrendPercentage =
CASE
WHEN ISNULL(@PrevAvgActiveHours, 0) = 0
THEN 0
ELSE
((@AvgActiveHours - @PrevAvgActiveHours) * 100.0)
/ @PrevAvgActiveHours
END;
SET @IdleTrendPercentage =
CASE
WHEN ISNULL(@PrevAvgIdleHours, 0) = 0
THEN 0
ELSE
((@AvgIdleHours - @PrevAvgIdleHours) * 100.0)
/ @PrevAvgIdleHours
END;
SET @ProductivityTrendPercentage =
CASE
WHEN ISNULL(@PrevAvgProductivity, 0) = 0
THEN 0
ELSE
((@AvgProductivity - @PrevAvgProductivity) * 100.0)
/ @PrevAvgProductivity
END;
------------------------------------------------------------
-- COMPLIANCE
------------------------------------------------------------
IF EXISTS
(
SELECT 1
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate BETWEEN @FromDate AND @ToDate
AND FIRSTLOGIN IS NOT NULL
AND IsActive = 1
AND IsDelete = 0
)
AND @AvgActiveHours >= @HoursThreshold
BEGIN
SET @ComplianceStatus = 'Passed';
END
------------------------------------------------------------
-- FINAL RESULT
------------------------------------------------------------
SELECT
--------------------------------------------------------
-- DATE RANGE
--------------------------------------------------------
@FromDate AS FromDate,
@ToDate AS ToDate,
@PreviousFromDate AS PreviousFromDate,
@PreviousToDate AS PreviousToDate,
--------------------------------------------------------
-- CURRENT AVERAGES
--------------------------------------------------------
dbo.fn_ConvertDecimalHoursToHHMMSS(@AvgLoggedHours)
AS AvgLoggedHours,
dbo.fn_ConvertDecimalHoursToHHMMSS(@AvgActiveHours)
AS AvgActiveHours,
dbo.fn_ConvertDecimalHoursToHHMMSS(@AvgIdleHours)
AS AvgIdleHours,
CAST(@AvgProductivity AS DECIMAL(18,2))
AS AvgProductivity,
--------------------------------------------------------
-- PREVIOUS AVERAGES
--------------------------------------------------------
dbo.fn_ConvertDecimalHoursToHHMMSS(@PrevAvgLoggedHours)
AS PreviousAvgLoggedHours,
dbo.fn_ConvertDecimalHoursToHHMMSS(@PrevAvgActiveHours)
AS PreviousAvgActiveHours,
dbo.fn_ConvertDecimalHoursToHHMMSS(@PrevAvgIdleHours)
AS PreviousAvgIdleHours,
CAST(@PrevAvgProductivity AS DECIMAL(18,2))
AS PreviousAvgProductivity,
--------------------------------------------------------
-- TREND %
--------------------------------------------------------
CAST(@LoggedTrendPercentage AS DECIMAL(18,2))
AS LoggedTrendPercentage,
CAST(@ActiveTrendPercentage AS DECIMAL(18,2))
AS ActiveTrendPercentage,
CAST(@IdleTrendPercentage AS DECIMAL(18,2))
AS IdleTrendPercentage,
CAST(@ProductivityTrendPercentage AS DECIMAL(18,2))
AS ProductivityTrendPercentage,
--------------------------------------------------------
-- TREND DIRECTION
--------------------------------------------------------
CASE
WHEN @LoggedTrendPercentage > 0 THEN 'raise'
WHEN @LoggedTrendPercentage < 0 THEN 'dip'
ELSE 'same'
END AS LoggedTrendDirection,
CASE
WHEN @ActiveTrendPercentage > 0 THEN 'raise'
WHEN @ActiveTrendPercentage < 0 THEN 'dip'
ELSE 'same'
END AS ActiveTrendDirection,
CASE
WHEN @IdleTrendPercentage < 0 THEN 'raise'
WHEN @IdleTrendPercentage > 0 THEN 'dip'
ELSE 'same'
END AS IdleTrendDirection,
CASE
WHEN @ProductivityTrendPercentage > 0 THEN 'raise'
WHEN @ProductivityTrendPercentage < 0 THEN 'dip'
ELSE 'same'
END AS ProductivityTrendDirection,
--------------------------------------------------------
-- COMPLIANCE
--------------------------------------------------------
@ComplianceStatus AS ComplianceStatus;
END