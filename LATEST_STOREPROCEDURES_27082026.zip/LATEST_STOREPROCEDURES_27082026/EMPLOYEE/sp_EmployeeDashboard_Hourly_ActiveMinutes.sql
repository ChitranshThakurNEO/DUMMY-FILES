CREATE OR ALTER PROCEDURE sp_EmployeeDashboard_Hourly_ActiveMinutes
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
-------------------------------------------------------
-- OffSetMinutes for Time Zone Conversion
-------------------------------------------------------
DECLARE @OffsetMinutes INT = 330;

-------------------------------------------------------
-- GENERATE 24 HOURS
-------------------------------------------------------
;WITH Hours AS
(
SELECT 0 AS Hr UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL
SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL
SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL
SELECT 9 UNION ALL SELECT 10 UNION ALL SELECT 11 UNION ALL
SELECT 12 UNION ALL SELECT 13 UNION ALL SELECT 14 UNION ALL
SELECT 15 UNION ALL SELECT 16 UNION ALL SELECT 17 UNION ALL
SELECT 18 UNION ALL SELECT 19 UNION ALL SELECT 20 UNION ALL
SELECT 21 UNION ALL SELECT 22 UNION ALL SELECT 23
),
-------------------------------------------------------
-- ACTIVE RECORDS (EXCLUDE IDLE)
-------------------------------------------------------
ActivityData AS
(
SELECT
dbo.fn_ConvertUtcToLocal(StartTime, @OffsetMinutes) AS StartTime,
dbo.fn_ConvertUtcToLocal(EndTime, @OffsetMinutes) AS EndTime,
DurationSeconds
FROM MasterActivityLog
WHERE EmployeeCode = @EmployeeCode
AND CAST
(
dbo.fn_ConvertUtcToLocal(StartTime, @OffsetMinutes)
AS DATE
) = @Date
AND Status <> 'Idle'
AND IsActive = 1
AND IsDelete = 0
AND EndTime IS NOT NULL
),
-------------------------------------------------------
-- SPLIT DURATION ACROSS HOURS
-------------------------------------------------------
Expanded AS
(
SELECT
H.Hr,
DATEDIFF
(
SECOND,
CASE
WHEN A.StartTime >
DATEADD(HOUR, H.Hr, CAST(@Date AS DATETIME))
THEN A.StartTime
ELSE DATEADD(HOUR, H.Hr, CAST(@Date AS DATETIME))
END,
CASE
WHEN A.EndTime <
DATEADD(HOUR, H.Hr + 1, CAST(@Date AS DATETIME))
THEN A.EndTime
ELSE DATEADD(HOUR, H.Hr + 1, CAST(@Date AS DATETIME))
END
) AS ActiveSeconds
FROM Hours H
INNER JOIN ActivityData A
ON A.StartTime <
DATEADD(HOUR, H.Hr + 1, CAST(@Date AS DATETIME))
AND A.EndTime >
DATEADD(HOUR, H.Hr, CAST(@Date AS DATETIME))
),
-------------------------------------------------------
-- REMOVE NEGATIVE VALUES
-------------------------------------------------------
CleanData AS
(
SELECT
Hr,
CASE
WHEN ActiveSeconds > 0
THEN ActiveSeconds
ELSE 0
END AS ActiveSeconds
FROM Expanded
),
-------------------------------------------------------
-- FINAL AGGREGATION
-- NO HOUR CAN EXCEED 60 MINUTES
-------------------------------------------------------
FinalAgg AS
(
SELECT
Hr,
CAST
(
CASE
WHEN SUM(ActiveSeconds) > 3600
THEN 60.00
ELSE SUM(ActiveSeconds) / 60.0
END
AS DECIMAL(10,2)
) AS ActiveMinutes
FROM CleanData
GROUP BY Hr
)
-------------------------------------------------------
-- FINAL OUTPUT
-------------------------------------------------------
SELECT
H.Hr AS Hour,
ISNULL(F.ActiveMinutes, 0) AS ActiveMinutes
FROM Hours H
LEFT JOIN FinalAgg F
ON F.Hr = H.Hr
ORDER BY H.Hr;
END