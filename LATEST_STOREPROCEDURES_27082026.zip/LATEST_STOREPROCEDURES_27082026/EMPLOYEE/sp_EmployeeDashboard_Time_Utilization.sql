CREATE PROCEDURE sp_EmployeeDashboard_Time_Utilization
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
-------------------------------------------------------
-- ACTIVITY DATA
-------------------------------------------------------
;WITH ActivityData AS
(
SELECT
MAL.DurationSeconds,
MAL.Status,
MAC.CategoryName
FROM MasterActivityLog MAL
LEFT JOIN MasterActivityCategory MAC
ON MAC.MasterActivityCategoryId = MAL.CategoryId
WHERE MAL.EmployeeCode = @EmployeeCode
AND CAST(MAL.StartTime AS DATE) = @Date
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
),
-------------------------------------------------------
-- CLASSIFICATION
-------------------------------------------------------
ClassifiedData AS
(
SELECT
CASE
WHEN Status = 'Idle'
THEN 'Idle'
WHEN CategoryName = 'Communication'
THEN 'Meeting'
ELSE 'Active'
END AS Category,
DurationSeconds
FROM ActivityData
),
-------------------------------------------------------
-- AGGREGATION
-------------------------------------------------------
Aggregated AS
(
SELECT
Category,
COUNT(*) AS RecordCount,
SUM(DurationSeconds) AS TotalSeconds
FROM ClassifiedData
GROUP BY Category
),
-------------------------------------------------------
-- TOTAL SECONDS
-------------------------------------------------------
TotalCalc AS
(
SELECT
SUM(TotalSeconds) AS GrandTotalSeconds
FROM Aggregated
),
-------------------------------------------------------
-- SUMMARY TABLE DATA
-------------------------------------------------------
SummaryData AS
(
SELECT TOP 1
TOT_LOGGEDHOURS,
TOT_ACTIVEHOURS,
TOT_LOGGEDHOURS_AC
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE) = @Date
AND IsActive = 1
AND IsDelete = 0
)
-------------------------------------------------------
-- FINAL OUTPUT
-------------------------------------------------------
SELECT
--------------------------------------------------
-- ACTIVE
--------------------------------------------------
ISNULL(
MAX(
CASE
WHEN Category = 'Active'
THEN (TotalSeconds * 100.0 / NULLIF(T.GrandTotalSeconds,0))
END
),
0
) AS ActivePercent,
ISNULL(
MAX(
CASE
WHEN Category = 'Active'
THEN RecordCount
END
),
0
) AS ActiveCount,
--------------------------------------------------
-- IDLE
--------------------------------------------------
ISNULL(
MAX(
CASE
WHEN Category = 'Idle'
THEN (TotalSeconds * 100.0 / NULLIF(T.GrandTotalSeconds,0))
END
),
0
) AS IdlePercent,
ISNULL(
MAX(
CASE
WHEN Category = 'Idle'
THEN RecordCount
END
),
0
) AS IdleCount,
--------------------------------------------------
-- MEETING
--------------------------------------------------
ISNULL(
MAX(
CASE
WHEN Category = 'Meeting'
THEN (TotalSeconds * 100.0 / NULLIF(T.GrandTotalSeconds,0))
END
),
0
) AS MeetingPercent,
ISNULL(
MAX(
CASE
WHEN Category = 'Meeting'
THEN RecordCount
END
),
0
) AS MeetingCount,
--------------------------------------------------
-- DISPLAY VALUE
--------------------------------------------------
SD.TOT_LOGGEDHOURS_AC AS TotalLoggedHours,
--------------------------------------------------
-- UTILIZATION
-- Active Hours / Logged Hours * 100
--------------------------------------------------
ROUND(
SD.TOT_ACTIVEHOURS * 100.0
/ NULLIF(SD.TOT_LOGGEDHOURS, 0),
1
) AS Utilization
FROM Aggregated A
CROSS JOIN TotalCalc T
CROSS JOIN SummaryData SD
GROUP BY
SD.TOT_LOGGEDHOURS_AC,
SD.TOT_LOGGEDHOURS,
SD.TOT_ACTIVEHOURS;
END