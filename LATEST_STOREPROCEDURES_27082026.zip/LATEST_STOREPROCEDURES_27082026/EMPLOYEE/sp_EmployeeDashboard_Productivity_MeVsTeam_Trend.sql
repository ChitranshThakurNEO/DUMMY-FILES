CREATE PROCEDURE sp_EmployeeDashboard_Productivity_MeVsTeam_Trend
(
@EmployeeCode NVARCHAR(100),
@CurrentDate DATE
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
-------------------------------------------------------
-- EMPLOYEE / MANAGER INFO
-------------------------------------------------------
DECLARE @ManagerCode NVARCHAR(100);
DECLARE @ManagerName NVARCHAR(200);
DECLARE @EmployeeName NVARCHAR(200);
SELECT
@ManagerCode = MANAGER_1,
@ManagerName = MANAGER_1_NAME,
@EmployeeName = FullName
FROM vw_MasterEmployee
WHERE EmployeeCode = @EmployeeCode;
-------------------------------------------------------
-- RESULT SET 1
-------------------------------------------------------
SELECT
@ManagerCode AS ManagerCode,
@ManagerName AS ManagerName,
@EmployeeName AS EmployeeName;
-------------------------------------------------------
-- TEAM
-------------------------------------------------------
DECLARE @Team TABLE
(
EmployeeCode NVARCHAR(100) PRIMARY KEY
);
INSERT INTO @Team
(
EmployeeCode
)
SELECT EmployeeCode
FROM vw_MasterEmployee
WHERE MANAGER_1 = @ManagerCode;
-------------------------------------------------------
-- WEEK RANGE
-------------------------------------------------------
DECLARE @WeekStart DATE =
DATEADD(
DAY,
-(DATEPART(WEEKDAY,@CurrentDate) - 1),
@CurrentDate
);
DECLARE @WeekEnd DATE =
DATEADD(
DAY,
5,
@WeekStart
);
-------------------------------------------------------
-- DAYS
-------------------------------------------------------
;WITH Days AS
(
SELECT DATEADD(DAY,1,@WeekStart) AS WorkDate
UNION ALL SELECT DATEADD(DAY,2,@WeekStart)
UNION ALL SELECT DATEADD(DAY,3,@WeekStart)
UNION ALL SELECT DATEADD(DAY,4,@WeekStart)
UNION ALL SELECT DATEADD(DAY,5,@WeekStart)
),
-------------------------------------------------------
-- PRODUCTIVITY DATA
-------------------------------------------------------
ActivityData AS
(
SELECT
EmployeeCode,
CAST(LoggedDate AS DATE) AS WorkDate,
ROUND
(
(
TOT_PRODHOURS * 100.0
)
/
NULLIF(TOT_LOGGEDHOURS,0),
1
) AS ProductivityPercentage
FROM EmployeeActivityLogSummary
WHERE IsActive = 1
AND IsDelete = 0
AND TOT_LOGGEDHOURS > 0
AND CAST(LoggedDate AS DATE)
BETWEEN @WeekStart AND @WeekEnd
),
-------------------------------------------------------
-- MY DATA
-------------------------------------------------------
MyData AS
(
SELECT
WorkDate,
AVG(ProductivityPercentage)
AS MyProductivityPercentage
FROM ActivityData
WHERE EmployeeCode = @EmployeeCode
GROUP BY WorkDate
),
-------------------------------------------------------
-- TEAM DATA
-------------------------------------------------------
TeamData AS
(
SELECT
A.WorkDate,
ROUND(
AVG(A.ProductivityPercentage),
1
) AS TeamAvgProductivityPercentage
FROM ActivityData A
INNER JOIN @Team T
ON T.EmployeeCode = A.EmployeeCode
WHERE A.EmployeeCode <> @EmployeeCode
GROUP BY A.WorkDate
)
-------------------------------------------------------
-- RESULT SET 2
-------------------------------------------------------
SELECT
D.WorkDate,
DATENAME(WEEKDAY, D.WorkDate)
AS DayName,
ISNULL(
M.MyProductivityPercentage,
0
) AS MyProductivityPercentage,
ISNULL(
T.TeamAvgProductivityPercentage,
0
) AS TeamAvgProductivityPercentage
FROM Days D
LEFT JOIN MyData M
ON M.WorkDate = D.WorkDate
LEFT JOIN TeamData T
ON T.WorkDate = D.WorkDate
ORDER BY D.WorkDate;
END
