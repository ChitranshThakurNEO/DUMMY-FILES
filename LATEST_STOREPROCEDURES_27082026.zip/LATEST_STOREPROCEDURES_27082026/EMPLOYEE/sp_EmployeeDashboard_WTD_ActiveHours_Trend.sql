CREATE PROCEDURE [dbo].[sp_EmployeeDashboard_WTD_ActiveHours_Trend]
(
@EmployeeCode NVARCHAR(100),
@CurrentDate DATE
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
-------------------------------------------------------
-- CURRENT WEEK START (SUNDAY BASED)
-------------------------------------------------------
DECLARE @WeekStart DATE =
DATEADD(DAY, -(DATEPART(WEEKDAY,@CurrentDate)-1), @CurrentDate);
-------------------------------------------------------
-- GENERATE ONLY WEEKDAYS (MON�FRI )
-------------------------------------------------------
;WITH Days AS
(
SELECT DATEADD(DAY, 1, @WeekStart) AS WorkDate
UNION ALL SELECT DATEADD(DAY, 2, @WeekStart)
UNION ALL SELECT DATEADD(DAY, 3, @WeekStart)
UNION ALL SELECT DATEADD(DAY, 4, @WeekStart)
UNION ALL SELECT DATEADD(DAY, 5, @WeekStart)
),
-------------------------------------------------------
-- SUMMARY DATA (FILTERED )
-------------------------------------------------------
ActivityData AS
(
SELECT
CAST(LoggedDate AS DATE) AS WorkDate,
TOT_ACTIVEHOURS_AC
FROM EmployeeActivityLogSummary
WHERE
EmployeeCode = @EmployeeCode
AND IsActive = 1
AND IsDelete = 0
AND TOT_LOGGEDHOURS > 0
AND LoggedDate BETWEEN @WeekStart AND @CurrentDate
),
-------------------------------------------------------
-- DAILY AGG
-------------------------------------------------------
DailyAgg AS
(
SELECT
WorkDate,
TOT_ACTIVEHOURS_AC AS ActiveHours
FROM ActivityData
GROUP BY WorkDate, TOT_ACTIVEHOURS_AC
)
-------------------------------------------------------
-- FINAL OUTPUT
-------------------------------------------------------
SELECT
D.WorkDate,
DATENAME(WEEKDAY, D.WorkDate) AS DayName,
ISNULL(A.ActiveHours, 0) AS ActiveHours
FROM Days D
LEFT JOIN DailyAgg A
ON A.WorkDate = D.WorkDate
WHERE D.WorkDate <= @CurrentDate
ORDER BY D.WorkDate;
END