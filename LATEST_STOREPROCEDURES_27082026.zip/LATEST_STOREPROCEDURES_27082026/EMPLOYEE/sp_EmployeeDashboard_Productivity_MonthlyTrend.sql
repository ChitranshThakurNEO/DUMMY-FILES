CREATE PROCEDURE [dbo].[sp_EmployeeDashboard_Productivity_MonthlyTrend]
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
-------------------------------------------------------
-- MONTH RANGE
-------------------------------------------------------
DECLARE @MonthStart DATE =
DATEFROMPARTS(
YEAR(@Date),
MONTH(@Date),
1
);
DECLARE @MonthEnd DATE = EOMONTH(@Date);
-------------------------------------------------------
-- RESULT SET 1 : TREND
-------------------------------------------------------
SELECT
CAST(LoggedDate AS DATE) AS WorkDate,
DAY(CAST(LoggedDate AS DATE))
AS DayNumber,
ROUND
(
(
TOT_PRODHOURS * 100.0
)
/
NULLIF(
TOT_LOGGEDHOURS,
0
),
1
) AS ProductivityPercentage
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND IsActive = 1
AND IsDelete = 0
AND TOT_LOGGEDHOURS > 0
AND CAST(LoggedDate AS DATE)
BETWEEN @MonthStart AND @MonthEnd
ORDER BY WorkDate;
-------------------------------------------------------
-- RESULT SET 2 : PERIOD INFO
-------------------------------------------------------
SELECT
FORMAT(@MonthStart,'dd MMM yyyy')
+ ' - '
+ FORMAT(@MonthEnd,'dd MMM yyyy')
AS MonthRange;
END
