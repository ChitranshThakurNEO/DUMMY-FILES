CREATE PROCEDURE [dbo].[sp_EmployeeDashboardSummary]
(
@EmployeeCode VARCHAR(20),
@FromDate DATE,
@ToDate DATE,
@DailyHoursTarget DECIMAL(10,2),
@DailyProductivityPercentageTarget DECIMAL(10,2),
@WeeklyHoursTarget DECIMAL(10,2)
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7; -- Sunday to Saturday
------------------------------------------------------------
-- VARIABLES
------------------------------------------------------------
DECLARE @WorkingDaysCount INT = 0;
DECLARE @SelectedWeekStart DATE;
DECLARE @SelectedWeekEnd DATE;
DECLARE @CurrentWeekStart DATE;
DECLARE @EffectiveWeekEnd DATE;
DECLARE @HoursTodayHours DECIMAL(18,2) = 0;
DECLARE @WeekToDateHours DECIMAL(18,2) = 0;
DECLARE @ProductiveHours DECIMAL(18,2) = 0;
DECLARE @LoggedHoursForProductivity DECIMAL(18,2) = 0;
DECLARE @ProductivityActual DECIMAL(10,2) = 0;
DECLARE @IsSameWeek BIT = 0;
------------------------------------------------------------
-- SUNDAY TO SATURDAY WEEK CALCULATION
------------------------------------------------------------
SET @SelectedWeekStart =
DATEADD
(
DAY,
-(DATEPART(WEEKDAY, @ToDate) - 1),
@ToDate
);
SET @SelectedWeekEnd =
DATEADD
(
DAY,
6,
@SelectedWeekStart
);
SET @CurrentWeekStart =
DATEADD
(
DAY,
-(DATEPART(WEEKDAY, CAST(GETDATE() AS DATE)) - 1),
CAST(GETDATE() AS DATE)
);
IF DATEADD
(
DAY,
-(DATEPART(WEEKDAY, @FromDate) - 1),
@FromDate
)
=
DATEADD
(
DAY,
-(DATEPART(WEEKDAY, @ToDate) - 1),
@ToDate
)
BEGIN
SET @IsSameWeek = 1;
END
------------------------------------------------------------
-- DAYS WITH LOGGED HOURS
------------------------------------------------------------
SELECT
@WorkingDaysCount = COUNT(*)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate BETWEEN @FromDate AND @ToDate
AND ISNULL(TOT_LOGGEDHOURS,0) > 0
AND IsActive = 1
AND IsDelete = 0;
------------------------------------------------------------
-- HOURS TODAY / AVG HOURS
------------------------------------------------------------
IF @FromDate = @ToDate
BEGIN
SELECT
@HoursTodayHours =
ISNULL(SUM(TOT_LOGGEDHOURS),0)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate = @ToDate
AND ISNULL(TOT_LOGGEDHOURS,0) > 0
AND IsActive = 1
AND IsDelete = 0;
END
ELSE
BEGIN
SELECT
@HoursTodayHours =
ISNULL(SUM(TOT_LOGGEDHOURS),0)
/ NULLIF(@WorkingDaysCount,0)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate BETWEEN @FromDate AND @ToDate
AND ISNULL(TOT_LOGGEDHOURS,0) > 0
AND IsActive = 1
AND IsDelete = 0;
END
------------------------------------------------------------
-- PRODUCTIVITY LOGGED HOURS
------------------------------------------------------------
SELECT
@LoggedHoursForProductivity =
ISNULL(SUM(TOT_LOGGEDHOURS),0)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate BETWEEN @FromDate AND @ToDate
AND ISNULL(TOT_LOGGEDHOURS,0) > 0
AND IsActive = 1
AND IsDelete = 0;
------------------------------------------------------------
-- PRODUCTIVE HOURS
------------------------------------------------------------
SELECT
@ProductiveHours =
ISNULL(SUM(TOT_PRODHOURS),0)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate BETWEEN @FromDate AND @ToDate
AND ISNULL(TOT_LOGGEDHOURS,0) > 0
AND IsActive = 1
AND IsDelete = 0;
------------------------------------------------------------
-- PRODUCTIVITY %
------------------------------------------------------------
SET @ProductivityActual =
CASE
WHEN @LoggedHoursForProductivity = 0
THEN 0
ELSE
(@ProductiveHours * 100.0)
/ @LoggedHoursForProductivity
END;
------------------------------------------------------------
-- WEEK TO DATE HOURS
------------------------------------------------------------
IF @IsSameWeek = 1
BEGIN
IF @SelectedWeekStart < @CurrentWeekStart
BEGIN
SELECT
@EffectiveWeekEnd =
MAX(LoggedDate)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate BETWEEN
@SelectedWeekStart
AND @SelectedWeekEnd
AND ISNULL(TOT_LOGGEDHOURS,0) > 0
AND IsActive = 1
AND IsDelete = 0;
END
ELSE
BEGIN
SET @EffectiveWeekEnd =
CASE
WHEN @ToDate > CAST(GETDATE() AS DATE)
THEN CAST(GETDATE() AS DATE)
ELSE @ToDate
END;
END;
SELECT
@WeekToDateHours =
ISNULL(SUM(TOT_LOGGEDHOURS),0)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate BETWEEN
@SelectedWeekStart
AND @EffectiveWeekEnd
AND ISNULL(TOT_LOGGEDHOURS,0) > 0
AND IsActive = 1
AND IsDelete = 0;
END
ELSE
BEGIN
SELECT
@WeekToDateHours =
ISNULL(SUM(TOT_LOGGEDHOURS),0)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate BETWEEN
@FromDate
AND @ToDate
AND ISNULL(TOT_LOGGEDHOURS,0) > 0
AND IsActive = 1
AND IsDelete = 0;
END
------------------------------------------------------------
-- RESULT
------------------------------------------------------------
SELECT
HoursTodayActual =
CONCAT
(
FLOOR(@HoursTodayHours),
'h ',
FLOOR
(
(@HoursTodayHours - FLOOR(@HoursTodayHours))
* 60
),
'm'
),
HoursTodayTarget =
CONCAT
(
FLOOR(@DailyHoursTarget),
'h'
),
HoursTodayPercentage =
CAST
(
CASE
WHEN @DailyHoursTarget = 0
THEN 0
ELSE
(@HoursTodayHours * 100.0)
/ @DailyHoursTarget
END
AS DECIMAL(10,2)
),
ProductivityActual =
CAST
(
@ProductivityActual
AS DECIMAL(10,2)
),
ProductivityPercentage =
CAST
(
@DailyProductivityPercentageTarget
AS DECIMAL(10,2)
),
WeekToDateActual =
CONCAT
(
FLOOR(@WeekToDateHours),
'h ',
FLOOR
(
(@WeekToDateHours - FLOOR(@WeekToDateHours))
* 60
),
'm'
),
WeekToDateTarget =
CONCAT
(
FLOOR(@WeeklyHoursTarget),
'h'
),
WeekToDatePercentage =
CAST
(
CASE
WHEN @WeeklyHoursTarget = 0
THEN 0
ELSE
(@WeekToDateHours * 100.0)
/ @WeeklyHoursTarget
END
AS DECIMAL(10,2)
);
END