CREATE PROCEDURE [dbo].[sp_EmployeeDashboard_Idle_WTD_Trend]
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
-------------------------------------------------------
-- WEEK RANGE
-------------------------------------------------------
DECLARE @WeekStart DATE =
DATEADD(DAY, -(DATEPART(WEEKDAY, @Date) - 1), @Date);
DECLARE @WeekEnd DATE =
DATEADD(DAY, 5, @WeekStart);
-------------------------------------------------------
-- RESULT
-------------------------------------------------------
SELECT
CAST(LoggedDate AS DATE) AS WorkDate,
DATENAME(WEEKDAY, CAST(LoggedDate AS DATE))
+ ' '
+ RIGHT(CONVERT(VARCHAR(10), CAST(LoggedDate AS DATE), 105), 2)
AS DayLabel,
ROUND(
TRY_CAST(TOT_IDLETIME AS DECIMAL(10,2)) * 60,
0
) AS IdleMinutes,
TOT_IDLETIME_AC AS IdleTime
FROM EmployeeActivityLogSummary
WHERE
EmployeeCode = @EmployeeCode
AND IsActive = 1
AND IsDelete = 0
AND TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0
AND CAST(LoggedDate AS DATE)
BETWEEN @WeekStart AND @WeekEnd
ORDER BY WorkDate;
END