﻿CREATE PROCEDURE [dbo].[sp_EmployeeDashboard_30Day_ActiveHours_History]
(
@EmployeeCode NVARCHAR(100),
@CurrentDate DATE
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
-------------------------------------------------------
-- DATE RANGE
-------------------------------------------------------
DECLARE @StartDate DATE = DATEADD(DAY, -29, @CurrentDate);
-------------------------------------------------------
-- GET MANAGER
-------------------------------------------------------
DECLARE @ManagerCode NVARCHAR(100);
SELECT @ManagerCode = MANAGER_1
FROM vw_MasterEmployee
WHERE EmployeeCode = @EmployeeCode;
-------------------------------------------------------
-- TEAM
-------------------------------------------------------
DECLARE @Team TABLE (EmployeeCode NVARCHAR(100) PRIMARY KEY);
INSERT INTO @Team
SELECT EmployeeCode
FROM vw_MasterEmployee
WHERE MANAGER_1 = @ManagerCode;
-------------------------------------------------------
-- GENERATE DAYS → TEMP TABLE
-------------------------------------------------------
CREATE TABLE #Days (WorkDate DATE PRIMARY KEY);
WITH DayCTE AS
(
SELECT @StartDate AS WorkDate
UNION ALL
SELECT DATEADD(DAY, 1, WorkDate)
FROM DayCTE
WHERE WorkDate < @CurrentDate
)
INSERT INTO #Days
SELECT WorkDate
FROM DayCTE
OPTION (MAXRECURSION 100);
-------------------------------------------------------
-- ACTIVITY DATA
-------------------------------------------------------
WITH ActivityData AS
(
SELECT
EmployeeCode,
CAST(LoggedDate AS DATE) AS WorkDate,
TOT_ACTIVEHOURS
FROM EmployeeActivityLogSummary
WHERE
IsActive = 1
AND IsDelete = 0
AND TOT_LOGGEDHOURS > 0
AND LoggedDate BETWEEN @StartDate AND @CurrentDate
),
-------------------------------------------------------
-- ME DATA
-------------------------------------------------------
MeData AS
(
SELECT
WorkDate,
SUM(TOT_ACTIVEHOURS) AS ActiveHours
FROM ActivityData
WHERE EmployeeCode = @EmployeeCode
GROUP BY WorkDate
),
-------------------------------------------------------
-- TEAM DATA
-------------------------------------------------------
TeamData AS
(
SELECT
A.WorkDate,
AVG(A.TOT_ACTIVEHOURS) AS TeamAvgHours
FROM ActivityData A
INNER JOIN @Team T
ON T.EmployeeCode = A.EmployeeCode
GROUP BY A.WorkDate
)
-------------------------------------------------------
-- RESULT 1 → DAY-WISE TREND
-------------------------------------------------------
SELECT
D.WorkDate,
DATENAME(WEEKDAY, D.WorkDate) AS DayName,
ISNULL(M.ActiveHours, 0) AS ActiveHours,
ISNULL(T.TeamAvgHours, 0) AS TeamAvgActiveHours
FROM #Days D
LEFT JOIN MeData M ON M.WorkDate = D.WorkDate
LEFT JOIN TeamData T ON T.WorkDate = D.WorkDate
ORDER BY D.WorkDate;
-------------------------------------------------------
-- RESULT 2 → MONTHS
-------------------------------------------------------
SELECT
DATENAME(MONTH, WorkDate) AS MonthName
FROM #Days
GROUP BY
YEAR(WorkDate),
MONTH(WorkDate),
DATENAME(MONTH, WorkDate)
ORDER BY
YEAR(WorkDate),
MONTH(WorkDate);
END