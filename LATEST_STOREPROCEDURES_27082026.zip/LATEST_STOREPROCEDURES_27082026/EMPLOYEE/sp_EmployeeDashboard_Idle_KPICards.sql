CREATE PROCEDURE [dbo].[sp_EmployeeDashboard_Idle_KPICards]
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
-------------------------------------------------------
-- DATE VARIABLES
-------------------------------------------------------
DECLARE @PreviousDate DATE = DATEADD(DAY, -1, @Date);
DECLARE @WeekStart DATE =
DATEADD(DAY, -(DATEPART(WEEKDAY,@Date)-1), @Date);
DECLARE @WeekEnd DATE =
DATEADD(DAY, 5, @WeekStart);
-------------------------------------------------------
-- KPI 1 : IDLE TODAY
-------------------------------------------------------
DECLARE @IdleTodayMinutes DECIMAL(18,2) = 0;
DECLARE @PreviousIdleMinutes DECIMAL(18,2) = 0;
DECLARE @IdleTodayFormatted VARCHAR(20) = '0h 0m';
SELECT
@IdleTodayFormatted = MAX(TOT_IDLETIME_AC),
@IdleTodayMinutes =
SUM(TRY_CAST(TOT_IDLETIME AS DECIMAL(10,2)) * 60)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE) = @Date
AND IsActive = 1
AND IsDelete = 0
AND TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0;
SELECT
@PreviousIdleMinutes =
SUM(TRY_CAST(TOT_IDLETIME AS DECIMAL(10,2)) * 60)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE) = @PreviousDate
AND IsActive = 1
AND IsDelete = 0
AND TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0;
-------------------------------------------------------
-- KPI 2 : IDLE %
-------------------------------------------------------
DECLARE @IdlePercent DECIMAL(10,2) = 0;
DECLARE @LoggedHours VARCHAR(20) = '00:00:00';
SELECT
@IdlePercent =
CASE
WHEN SUM(TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2))) > 0
THEN
(
SUM(TRY_CAST(TOT_IDLETIME AS DECIMAL(10,2)))
* 100.0
)
/
SUM(TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)))
ELSE 0
END,
@LoggedHours = MAX(TOT_LOGGEDHOURS_AC)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE) = @Date
AND IsActive = 1
AND IsDelete = 0
AND TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0;
-------------------------------------------------------
-- KPI 3 : WTD AVG IDLE
-------------------------------------------------------
DECLARE @WTDAvgIdleMinutes DECIMAL(18,2) = 0;
SELECT
@WTDAvgIdleMinutes =
AVG(TRY_CAST(TOT_IDLETIME AS DECIMAL(10,2)) * 60)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate BETWEEN @WeekStart AND @WeekEnd
AND IsActive = 1
AND IsDelete = 0
AND TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0;
-------------------------------------------------------
-- KPI 4 : LARGEST SPIKE
-------------------------------------------------------
DECLARE @LargestSpikeMinutes INT = 0;
SELECT TOP 1
@LargestSpikeMinutes = DurationSeconds / 60
FROM MasterActivityLog
WHERE EmployeeCode = @EmployeeCode
AND CAST(StartTime AS DATE) = @Date
AND Status = 'Idle'
AND IsActive = 1
AND IsDelete = 0
ORDER BY DurationSeconds DESC;
-------------------------------------------------------
-- KPI 5 : TEAM AVG COMPARISON
-------------------------------------------------------
DECLARE @ManagerCode NVARCHAR(100);
SELECT
@ManagerCode = MANAGER_1
FROM vw_MasterEmployee
WHERE EmployeeCode = @EmployeeCode;
DECLARE @EmployeeIdlePct DECIMAL(10,2) = 0;
DECLARE @TeamIdlePct DECIMAL(10,2) = 0;
SELECT
@EmployeeIdlePct =
CASE
WHEN SUM(TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2))) > 0
THEN
SUM(TRY_CAST(TOT_IDLETIME AS DECIMAL(10,2))) * 100.0
/
SUM(TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)))
ELSE 0
END
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE) = @Date
AND IsActive = 1
AND IsDelete = 0;
SELECT
@TeamIdlePct =
AVG(
CASE
WHEN TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0
THEN
TRY_CAST(TOT_IDLETIME AS DECIMAL(10,2)) * 100.0
/
TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2))
END
)
FROM EmployeeActivityLogSummary EALS
INNER JOIN vw_MasterEmployee VME
ON VME.EmployeeCode = EALS.EmployeeCode
WHERE VME.MANAGER_1 = @ManagerCode
AND EALS.EmployeeCode <> @EmployeeCode
AND CAST(EALS.LoggedDate AS DATE) = @Date
AND EALS.IsActive = 1
AND EALS.IsDelete = 0
AND TRY_CAST(EALS.TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0;
-------------------------------------------------------
-- FINAL RESULT
-------------------------------------------------------
SELECT
@IdleTodayFormatted AS IdleToday,
CASE
WHEN ISNULL(@PreviousIdleMinutes,0) = 0
THEN 0
ELSE ROUND(
((@IdleTodayMinutes - @PreviousIdleMinutes) * 100.0)
/ @PreviousIdleMinutes,
1
)
END AS IdleTodayPercentageChange,
ROUND(@IdlePercent,1) AS IdlePercentage,
@LoggedHours AS LoggedHours,
CONCAT(
FLOOR(ISNULL(@WTDAvgIdleMinutes,0) / 60),
'h ',
CAST(ISNULL(@WTDAvgIdleMinutes,0) % 60 AS INT),
'm'
) AS WTDAverageIdle,
@LargestSpikeMinutes AS LargestSpikeMinutes,
ROUND(@EmployeeIdlePct - ISNULL(@TeamIdlePct,0),1)
AS TeamAverageVariance;
END