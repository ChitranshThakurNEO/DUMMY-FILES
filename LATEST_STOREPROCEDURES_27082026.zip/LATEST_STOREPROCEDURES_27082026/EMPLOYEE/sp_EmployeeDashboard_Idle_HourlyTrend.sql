CREATE OR ALTER PROCEDURE sp_EmployeeDashboard_Idle_HourlyTrend
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
-------------------------------------------------------
-- OffSetMinutes for Time Zone Conversion
-------------------------------------------------------
DECLARE @OffsetMinutes INT = 330;

-------------------------------------------------------
-- HOURS
-------------------------------------------------------
;WITH Hours AS
(
SELECT 0 AS Hr UNION ALL
SELECT 1 UNION ALL
SELECT 2 UNION ALL
SELECT 3 UNION ALL
SELECT 4 UNION ALL
SELECT 5 UNION ALL
SELECT 6 UNION ALL
SELECT 7 UNION ALL
SELECT 8 UNION ALL
SELECT 9 UNION ALL
SELECT 10 UNION ALL
SELECT 11 UNION ALL
SELECT 12 UNION ALL
SELECT 13 UNION ALL
SELECT 14 UNION ALL
SELECT 15 UNION ALL
SELECT 16 UNION ALL
SELECT 17 UNION ALL
SELECT 18 UNION ALL
SELECT 19 UNION ALL
SELECT 20 UNION ALL
SELECT 21 UNION ALL
SELECT 22 UNION ALL
SELECT 23
),
-------------------------------------------------------
-- IDLE RECORDS
-------------------------------------------------------
IdleData AS
(
SELECT
dbo.fn_ConvertUtcToLocal(StartTime, @OffsetMinutes) AS StartTime,
dbo.fn_ConvertUtcToLocal(EndTime, @OffsetMinutes) AS EndTime
FROM MasterActivityLog
WHERE EmployeeCode = @EmployeeCode
AND CAST
(
dbo.fn_ConvertUtcToLocal(StartTime, @OffsetMinutes)
AS DATE
) = @Date
AND Status = 'Idle'
AND IsActive = 1
AND IsDelete = 0
AND EndTime IS NOT NULL
AND DurationSeconds > 0
),
-------------------------------------------------------
-- SPLIT IDLE DURATION ACROSS HOURS
-------------------------------------------------------
Expanded AS
(
SELECT
H.Hr,
DATEDIFF
(
SECOND,
CASE
WHEN I.StartTime >
DATEADD(HOUR, H.Hr, CAST(@Date AS DATETIME))
THEN I.StartTime
ELSE DATEADD(HOUR, H.Hr, CAST(@Date AS DATETIME))
END,
CASE
WHEN I.EndTime <
DATEADD(HOUR, H.Hr + 1, CAST(@Date AS DATETIME))
THEN I.EndTime
ELSE DATEADD(HOUR, H.Hr + 1, CAST(@Date AS DATETIME))
END
) AS Seconds
FROM Hours H
INNER JOIN IdleData I
ON I.StartTime <
DATEADD(HOUR, H.Hr + 1, CAST(@Date AS DATETIME))
AND I.EndTime >
DATEADD(HOUR, H.Hr, CAST(@Date AS DATETIME))
)
-------------------------------------------------------
-- FINAL RESULT
-------------------------------------------------------
SELECT
H.Hr AS Hour,
CASE
WHEN ISNULL
(
SUM
(
CASE
WHEN E.Seconds > 0
THEN E.Seconds
ELSE 0
END
) / 60.0,
0
) > 60
THEN 60
ELSE ISNULL
(
SUM
(
CASE
WHEN E.Seconds > 0
THEN E.Seconds
ELSE 0
END
) / 60.0,
0
)
END AS IdleMinutes
FROM Hours H
LEFT JOIN Expanded E
ON E.Hr = H.Hr
GROUP BY H.Hr
ORDER BY H.Hr;
END
