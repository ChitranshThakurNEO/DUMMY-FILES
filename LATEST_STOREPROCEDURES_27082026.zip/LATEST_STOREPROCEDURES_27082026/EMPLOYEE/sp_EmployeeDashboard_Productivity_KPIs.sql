CREATE PROCEDURE [dbo].[sp_EmployeeDashboard_Productivity_KPIs]
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
-------------------------------------------------------
-- MONTH START
-------------------------------------------------------
DECLARE @MonthStart DATE =
DATEFROMPARTS(
YEAR(@Date),
MONTH(@Date),
1
);
-------------------------------------------------------
-- TODAY VALUES
-------------------------------------------------------
DECLARE @TodayProdHours DECIMAL(18,2) = 0;
DECLARE @TodayNonProdHours DECIMAL(18,2) = 0;
DECLARE @TodayNoImpactHours DECIMAL(18,2) = 0;
DECLARE @TodayLoggedHours DECIMAL(18,2) = 0;
DECLARE @TodayProductivity DECIMAL(18,2) = 0;
DECLARE @YesterdayProductivity DECIMAL(18,2) = 0;
DECLARE @MonthlyAverage DECIMAL(18,2) = 0;
-------------------------------------------------------
-- MANAGER INFO
-------------------------------------------------------
DECLARE @ManagerCode NVARCHAR(100);
DECLARE @ManagerName NVARCHAR(200);
SELECT
@ManagerCode = MANAGER_1,
@ManagerName = MANAGER_1_NAME
FROM vw_MasterEmployee
WHERE EmployeeCode = @EmployeeCode;
-------------------------------------------------------
-- TOP NON PRODUCTIVE APP
-------------------------------------------------------
DECLARE @NonProductiveSubCategories NVARCHAR(MAX) = '';
SELECT
@NonProductiveSubCategories =
STRING_AGG(SubCategoryName, ', ')
FROM
(
SELECT DISTINCT
MAC.SubCategoryName
FROM MasterActivityLog MAL
INNER JOIN MasterActivityCategory MAC
ON MAC.MasterActivityCategoryId = MAL.CategoryId
WHERE MAL.EmployeeCode = @EmployeeCode
AND CAST(MAL.StartTime AS DATE) = @Date
AND MAL.Status = 'Non-Productive'
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
) A;
-------------------------------------------------------
-- TODAY DATA
-------------------------------------------------------
SELECT
@TodayProdHours =
ISNULL(SUM(TOT_PRODHOURS),0),
@TodayNonProdHours =
ISNULL(SUM(TOT_NONPRODHOURS),0),
@TodayNoImpactHours =
ISNULL(SUM(TOT_NOIMPACTHOURS),0),
@TodayLoggedHours =
ISNULL(SUM(TOT_LOGGEDHOURS),0)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE) = @Date
AND IsActive = 1
AND IsDelete = 0
AND TOT_LOGGEDHOURS > 0;
-------------------------------------------------------
-- TODAY PRODUCTIVITY %
-------------------------------------------------------
SET @TodayProductivity =
CASE
WHEN @TodayLoggedHours > 0
THEN
(@TodayProdHours * 100.0)
/
@TodayLoggedHours
ELSE 0
END;
-------------------------------------------------------
-- YESTERDAY PRODUCTIVITY %
-------------------------------------------------------
SELECT
@YesterdayProductivity =
CASE
WHEN SUM(TOT_LOGGEDHOURS) > 0
THEN
(
SUM(TOT_PRODHOURS) * 100.0
)
/
SUM(TOT_LOGGEDHOURS)
ELSE 0
END
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE) = DATEADD(DAY,-1,@Date)
AND IsActive = 1
AND IsDelete = 0
AND TOT_LOGGEDHOURS > 0;
-------------------------------------------------------
-- MONTHLY PRODUCTIVITY AVG
-------------------------------------------------------
;WITH DailyProductivity AS
(
SELECT
CAST(LoggedDate AS DATE) AS WorkDate,
(
SUM(TOT_PRODHOURS) * 100.0
)
/
NULLIF(
SUM(TOT_LOGGEDHOURS),
0
) AS ProductivityPct
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate >= @MonthStart
AND LoggedDate <= @Date
AND IsActive = 1
AND IsDelete = 0
AND TOT_LOGGEDHOURS > 0
GROUP BY CAST(LoggedDate AS DATE)
)
SELECT
@MonthlyAverage =
ROUND(
AVG(ProductivityPct),
1
)
FROM DailyProductivity;
-------------------------------------------------------
-- TEAM RANK
-------------------------------------------------------
;WITH TeamScores AS
(
SELECT
EALS.EmployeeCode,
(
SUM(EALS.TOT_PRODHOURS) * 100.0
)
/
NULLIF(
SUM(EALS.TOT_LOGGEDHOURS),
0
) AS ProductivityPct
FROM EmployeeActivityLogSummary EALS
INNER JOIN vw_MasterEmployee VME
ON VME.EmployeeCode = EALS.EmployeeCode
WHERE
VME.MANAGER_1 = @ManagerCode
AND CAST(EALS.LoggedDate AS DATE) = @Date
AND EALS.IsActive = 1
AND EALS.IsDelete = 0
AND EALS.TOT_LOGGEDHOURS > 0
GROUP BY EALS.EmployeeCode
),
Ranked AS
(
SELECT
EmployeeCode,
ProductivityPct,
ROW_NUMBER() OVER
(
ORDER BY ProductivityPct DESC
) AS RankNo
FROM TeamScores
)
-------------------------------------------------------
-- FINAL RESULT
-------------------------------------------------------
SELECT
ROUND(@TodayProductivity,1)
AS TodayProductivity,
ROUND(
@TodayProductivity
- ISNULL(@YesterdayProductivity,0),
1
) AS ProductivityVariance,
ROUND(
ISNULL(@MonthlyAverage,0),
1
) AS MonthlyAverage,
dbo.fn_ConvertDecimalHoursToHHMMSS(
@TodayProdHours
) AS ProductiveTime,
dbo.fn_ConvertDecimalHoursToHHMMSS(
@TodayNonProdHours
) AS NonProductiveTime,
dbo.fn_ConvertDecimalHoursToHHMMSS(
@TodayNoImpactHours
) AS NoImpactTime,
dbo.fn_ConvertDecimalHoursToHHMMSS(
@TodayProdHours +
@TodayNonProdHours +
@TodayNoImpactHours
) AS ActiveTime,
@NonProductiveSubCategories
AS NonProductiveSubCategories,
ISNULL(
(
SELECT RankNo
FROM Ranked
WHERE EmployeeCode = @EmployeeCode
),
0
) AS TeamRank,
ISNULL(
(
SELECT COUNT(*)
FROM Ranked
),
0
) AS TeamSize,
@ManagerName
AS ManagerName;
END
