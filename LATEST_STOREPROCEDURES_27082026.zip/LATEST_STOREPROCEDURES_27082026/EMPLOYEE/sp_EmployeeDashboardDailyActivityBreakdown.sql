CREATE PROCEDURE [dbo].[sp_EmployeeDashboardDailyActivityBreakdown]
(
@EmployeeCode VARCHAR(20),
@FromDate DATE,
@ToDate DATE
)
AS
BEGIN
SET NOCOUNT ON;
------------------------------------------------------------
-- VARIABLES
------------------------------------------------------------
DECLARE @IsTodayView BIT = 0;
DECLARE @IsSingleDay BIT = 0;
DECLARE @LoginTime TIME;
DECLARE @LogoutTime TIME;
DECLARE @ExpectedLogoutTime TIME;
DECLARE @ElapsedHours DECIMAL(10,2) = 0;
DECLARE @AvgActiveHours DECIMAL(10,2) = 0;
DECLARE @AvgIdleHours DECIMAL(10,2) = 0;
DECLARE @AvgMeetingHours DECIMAL(10,2) = 0;
DECLARE @MeetingCount DECIMAL(10,2) = 0;
------------------------------------------------------------
-- FLAGS
------------------------------------------------------------
IF
(
@FromDate = @ToDate
AND @FromDate = CAST(GETDATE() AS DATE)
)
BEGIN
SET @IsTodayView = 1;
END
IF @FromDate = @ToDate
BEGIN
SET @IsSingleDay = 1;
END
------------------------------------------------------------
-- TODAY VIEW
------------------------------------------------------------
IF @IsTodayView = 1
BEGIN
--------------------------------------------------------
-- LOGIN + ELAPSED
--------------------------------------------------------
SELECT TOP 1
@LoginTime =
CAST(FIRSTLOGIN AS TIME),
@ElapsedHours =
ISNULL(TOT_LOGGEDHOURS, 0)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE) = @FromDate
AND IsActive = 1
AND IsDelete = 0
ORDER BY LoggedDate DESC;
--------------------------------------------------------
-- EXPECTED LOGOUT
--------------------------------------------------------
SELECT
@ExpectedLogoutTime =
CAST
(
DATEADD
(
SECOND,
AVG
(
DATEDIFF
(
SECOND,
0,
CAST(LASTLOGOUT AS TIME)
)
),
0
)
AS TIME
)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE)
BETWEEN DATEADD(DAY, -7, @FromDate)
AND DATEADD(DAY, -1, @FromDate)
AND LASTLOGOUT IS NOT NULL
AND IsActive = 1
AND IsDelete = 0;
END
------------------------------------------------------------
-- SINGLE HISTORICAL DAY
------------------------------------------------------------
ELSE IF @IsSingleDay = 1
BEGIN
SELECT TOP 1
@LoginTime =
CAST(FIRSTLOGIN AS TIME),
@LogoutTime =
CAST(LASTLOGOUT AS TIME),
@ElapsedHours =
DATEDIFF(
SECOND,
FIRSTLOGIN,
LASTLOGOUT
) / 3600.0
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE) = @FromDate
AND IsActive = 1
AND IsDelete = 0
ORDER BY LoggedDate DESC;
END
------------------------------------------------------------
-- MULTI DAY RANGE
------------------------------------------------------------
ELSE
BEGIN
SELECT
@LoginTime =
CAST
(
DATEADD
(
SECOND,
AVG
(
DATEDIFF
(
SECOND,
0,
CAST(FIRSTLOGIN AS TIME)
)
),
0
)
AS TIME
),
@LogoutTime =
CAST
(
DATEADD
(
SECOND,
AVG
(
DATEDIFF
(
SECOND,
0,
CAST(LASTLOGOUT AS TIME)
)
),
0
)
AS TIME
),
@ElapsedHours =
AVG(DATEDIFF(
SECOND,
FIRSTLOGIN,
LASTLOGOUT
) / 3600.0)
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE)
BETWEEN @FromDate AND @ToDate
AND FIRSTLOGIN IS NOT NULL
AND LASTLOGOUT IS NOT NULL
AND IsActive = 1
AND IsDelete = 0;
END
------------------------------------------------------------
-- ACTIVE / IDLE
------------------------------------------------------------
SELECT
@AvgActiveHours =
AVG(ISNULL(TOT_ACTIVEHOURS, 0)),
@AvgIdleHours =
AVG(ISNULL(TOT_IDLETIME, 0))
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND CAST(LoggedDate AS DATE)
BETWEEN @FromDate AND @ToDate
AND IsActive = 1
AND IsDelete = 0;
------------------------------------------------------------
-- MEETING HOURS + COUNT
------------------------------------------------------------
IF @IsSingleDay = 1
BEGIN
SELECT
@AvgMeetingHours =
SUM(MeetingHours),
@MeetingCount =
SUM(MeetingCount)
FROM
(
SELECT
CAST(MAL.LogDate AS DATE)
AS ActivityDate,
SUM(MAL.DurationSeconds) / 3600.0
AS MeetingHours,
COUNT(*)
AS MeetingCount
FROM MasterActivityLog MAL
INNER JOIN MasterActivityCategory MAC
ON MAL.CategoryId =
MAC.MasterActivityCategoryId
WHERE MAL.EmployeeCode = @EmployeeCode
AND CAST(MAL.LogDate AS DATE)
BETWEEN @FromDate AND @ToDate
AND MAC.CategoryName = 'Communication'
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
GROUP BY CAST(MAL.LogDate AS DATE)
) X;
END
ELSE
BEGIN
SELECT
@AvgMeetingHours =
AVG(MeetingHours),
@MeetingCount =
AVG(MeetingCount)
FROM
(
SELECT
CAST(MAL.LogDate AS DATE)
AS ActivityDate,
SUM(MAL.DurationSeconds) / 3600.0
AS MeetingHours,
COUNT(*)
AS MeetingCount
FROM MasterActivityLog MAL
INNER JOIN MasterActivityCategory MAC
ON MAL.CategoryId =
MAC.MasterActivityCategoryId
WHERE MAL.EmployeeCode = @EmployeeCode
AND CAST(MAL.LogDate AS DATE)
BETWEEN @FromDate AND @ToDate
AND MAC.CategoryName = 'Communication'
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
GROUP BY CAST(MAL.LogDate AS DATE)
) X;
END
------------------------------------------------------------
-- FINAL RESULT
------------------------------------------------------------
SELECT
CONVERT(VARCHAR(5), @LoginTime, 108)
AS LoginTime,
CASE
WHEN @IsTodayView = 1
THEN CONVERT(VARCHAR(5), GETDATE(), 108)
ELSE CONVERT(VARCHAR(5), @LogoutTime, 108)
END
AS CurrentOrLogoutTime,
CASE
WHEN @IsTodayView = 1
THEN CONVERT(VARCHAR(5), @ExpectedLogoutTime, 108)
ELSE NULL
END
AS ExpectedLogoutTime,
--------------------------------------------------------
-- ELAPSED
--------------------------------------------------------
CAST(FLOOR(@ElapsedHours) AS VARCHAR)
+ 'h '
+
CAST
(
ROUND
(
(@ElapsedHours - FLOOR(@ElapsedHours)) * 60,
0
)
AS VARCHAR
)
+ 'm'
AS ElapsedTime,
--------------------------------------------------------
-- ACTIVE
--------------------------------------------------------
CAST(FLOOR(@AvgActiveHours) AS VARCHAR)
+ 'h '
+
CAST
(
FLOOR
(
(@AvgActiveHours - FLOOR(@AvgActiveHours)) * 60
)
AS VARCHAR
)
+ 'm'
AS ActiveHours,
--------------------------------------------------------
-- MEETING
--------------------------------------------------------
CAST(FLOOR(ISNULL(@AvgMeetingHours, 0)) AS VARCHAR)
+ 'h '
+
CAST
(
FLOOR
(
(
ISNULL(@AvgMeetingHours, 0)
- FLOOR(ISNULL(@AvgMeetingHours, 0))
) * 60
)
AS VARCHAR
)
+ 'm'
AS MeetingHours,
--------------------------------------------------------
-- IDLE
--------------------------------------------------------
CAST(FLOOR(@AvgIdleHours) AS VARCHAR)
+ 'h '
+
CAST
(
FLOOR
(
(@AvgIdleHours - FLOOR(@AvgIdleHours)) * 60
)
AS VARCHAR
)
+ 'm'
AS IdleHours,
--------------------------------------------------------
-- MEETING COUNT
--------------------------------------------------------
CAST(@MeetingCount AS INT)
AS NumberOfMeetings;
------------------------------------------------------------
-- SECOND SET OF RESULT (Detailed Timeline)
------------------------------------------------------------
;WITH ActivityTimeline AS
(
SELECT
MAL.StartTime,
MAL.EndTime,
MAC.CategoryName,
LEAD(MAL.StartTime) OVER
(
ORDER BY MAL.StartTime
) AS NextStartTime
FROM MasterActivityLog MAL
INNER JOIN MasterActivityCategory MAC
ON MAL.CategoryId = MAC.MasterActivityCategoryId
WHERE MAL.EmployeeCode = @EmployeeCode
AND CAST(MAL.LogDate AS DATE)
BETWEEN @FromDate AND @ToDate
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
),
TimelineData AS
(
----------------------------------------------------
-- Activity Blocks
----------------------------------------------------
SELECT
CASE
WHEN CategoryName = 'Communication'
THEN 'Meeting Hours'
ELSE 'Active Hours'
END AS ActivityType,
StartTime,
EndTime,
DATEDIFF
(
SECOND,
StartTime,
EndTime
) AS DurationSeconds
FROM ActivityTimeline
UNION ALL
----------------------------------------------------
-- Idle Blocks
----------------------------------------------------
SELECT
'Idle Hours',
EndTime,
NextStartTime,
DATEDIFF
(
SECOND,
EndTime,
NextStartTime
) AS DurationSeconds
FROM ActivityTimeline
WHERE NextStartTime IS NOT NULL
AND NextStartTime > EndTime
)
SELECT
ActivityType,
CONVERT(VARCHAR(5), StartTime, 108)
AS StartTime,
CONVERT(VARCHAR(5), EndTime, 108)
AS EndTime,
CAST(DurationSeconds / 3600 AS VARCHAR)
+ 'h '
+ CAST((DurationSeconds % 3600) / 60 AS VARCHAR)
+ 'm'
AS Duration,
CAST(DurationSeconds / 3600.0 AS DECIMAL(10,4))
AS DurationHours
FROM TimelineData
ORDER BY StartTime;
END