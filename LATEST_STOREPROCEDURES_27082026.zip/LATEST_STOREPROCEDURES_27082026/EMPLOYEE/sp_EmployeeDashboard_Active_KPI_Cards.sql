CREATE PROCEDURE [dbo].[sp_EmployeeDashboard_Active_KPI_Cards]
(
@EmployeeCode NVARCHAR(100),
@FromDate DATE,
@ToDate DATE
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
-------------------------------------------------------
-- FLAG: SINGLE DAY OR RANGE
-------------------------------------------------------
DECLARE @IsSingleDay BIT =
CASE WHEN @FromDate = @ToDate THEN 1 ELSE 0 END;
DECLARE @CurrDate DATE = @ToDate;
-------------------------------------------------------
-- LOOKBACK WINDOW FOR LAST 7 WORKING DAYS
-------------------------------------------------------
DECLARE @WorkingDayLookback DATE =
DATEADD(DAY, -30, @CurrDate);
-------------------------------------------------------
-- TEAM
-------------------------------------------------------
;WITH Team AS
(
SELECT EmployeeCode
FROM vw_MasterEmployee
WHERE EmployeeCode = @EmployeeCode
OR MANAGER_1 =
(
SELECT MANAGER_1
FROM vw_MasterEmployee
WHERE EmployeeCode = @EmployeeCode
)
),
-------------------------------------------------------
-- BASE DATA
-------------------------------------------------------
BaseData AS
(
SELECT
S.EmployeeCode,
CAST(S.LoggedDate AS DATE) AS WorkDate,
S.TOT_ACTIVEHOURS,
S.TOT_LOGGEDHOURS
FROM EmployeeActivityLogSummary S
WHERE S.IsActive = 1
AND S.IsDelete = 0
AND S.TOT_LOGGEDHOURS > 0
AND S.LoggedDate BETWEEN
CASE
WHEN @FromDate < @WorkingDayLookback
THEN @FromDate
ELSE @WorkingDayLookback
END
AND @CurrDate
),
-------------------------------------------------------
-- FILTERED DATA
-------------------------------------------------------
FilteredData AS
(
SELECT *
FROM BaseData
),
-------------------------------------------------------
-- SELF DATA
-------------------------------------------------------
SelfData AS
(
SELECT
CASE
WHEN @IsSingleDay = 1
THEN SUM(TOT_ACTIVEHOURS)
ELSE AVG(TOT_ACTIVEHOURS)
END AS ActiveHours,
CASE
WHEN @IsSingleDay = 1
THEN SUM(TOT_LOGGEDHOURS)
ELSE AVG(TOT_LOGGEDHOURS)
END AS LoggedHours
FROM FilteredData
WHERE EmployeeCode = @EmployeeCode
AND WorkDate BETWEEN @FromDate AND @ToDate
),
-------------------------------------------------------
-- LAST 7 WORKING DAYS AVG
-------------------------------------------------------
SevenDayAvg AS
(
SELECT
AVG(TOT_ACTIVEHOURS) AS AvgActiveHours
FROM
(
SELECT TOP 7
WorkDate,
TOT_ACTIVEHOURS
FROM FilteredData
WHERE EmployeeCode = @EmployeeCode
AND WorkDate <= @CurrDate
AND DATENAME(WEEKDAY, WorkDate)
NOT IN ('Saturday','Sunday')
ORDER BY WorkDate DESC
) X
),
-------------------------------------------------------
-- TEAM AVG
-------------------------------------------------------
TeamAvg AS
(
SELECT
AVG(TOT_ACTIVEHOURS) AS TeamAvgHours
FROM FilteredData
WHERE EmployeeCode IN
(
SELECT EmployeeCode
FROM Team
)
AND WorkDate BETWEEN @FromDate AND @ToDate
),
-------------------------------------------------------
-- PEAK ACTIVE HOUR
-------------------------------------------------------
PeakHour AS
(
SELECT TOP 1
DATEPART
(
HOUR,
DATEADD
(
SECOND,
DurationSeconds / 2,
StartTime
)
) AS PeakHourStart
FROM MasterActivityLog
WHERE EmployeeCode = @EmployeeCode
AND CAST(StartTime AS DATE) = @CurrDate
AND Status <> 'Idle'
GROUP BY
DATEPART
(
HOUR,
DATEADD
(
SECOND,
DurationSeconds / 2,
StartTime
)
)
ORDER BY SUM(DurationSeconds) DESC
)
-------------------------------------------------------
-- FINAL OUTPUT
-------------------------------------------------------
SELECT
dbo.fn_ConvertDecimalHoursToHHMMSS
(
SD.ActiveHours
) AS ActiveToday,
CASE
WHEN SD.LoggedHours = 0
THEN 0
ELSE
(SD.ActiveHours * 100.0 / SD.LoggedHours)
END AS Utilization,
dbo.fn_ConvertDecimalHoursToHHMMSS
(
SDA.AvgActiveHours
) AS SevenDayAvg,
CASE
WHEN @IsSingleDay = 1
THEN CONCAT
(
PH.PeakHourStart,
'-',
PH.PeakHourStart + 1
)
ELSE NULL
END AS PeakHour,
CASE
WHEN SD.ActiveHours >= TA.TeamAvgHours
THEN '+' +
dbo.fn_ConvertDecimalHoursToHHMMSS
(
SD.ActiveHours - TA.TeamAvgHours
)
ELSE '-' +
dbo.fn_ConvertDecimalHoursToHHMMSS
(
TA.TeamAvgHours - SD.ActiveHours
)
END AS VsTeamAvg
FROM SelfData SD
CROSS JOIN SevenDayAvg SDA
CROSS JOIN TeamAvg TA
LEFT JOIN PeakHour PH
ON 1 = 1;
END