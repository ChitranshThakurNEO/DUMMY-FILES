CREATE PROCEDURE [dbo].[sp_EmployeeDashboardWeeklyHoursVsTarget]
(
@EmployeeCode VARCHAR(50),
@FromDate DATE,
@ToDate DATE,
@WeeklyTarget DECIMAL(10,2)
)
AS
BEGIN
SET NOCOUNT ON;
DECLARE @ActualFromDate DATE;
DECLARE @ActualToDate DATE;
DECLARE @RangeDays INT;
DECLARE @WorkedHours DECIMAL(10,2) = 0;
DECLARE @CompliancePercentage DECIMAL(10,2) = 0;
DECLARE @DifferenceHours DECIMAL(10,2) = 0;
DECLARE @BreakdownFromDate DATE;
DECLARE @BreakdownToDate DATE;
------------------------------------------------------------
-- WEEK LOGIC (only when single day selected)
------------------------------------------------------------
IF @FromDate = @ToDate
BEGIN
SET DATEFIRST 7; -- Sunday
SET @ActualFromDate =
DATEADD(
DAY,
-(DATEPART(WEEKDAY, @FromDate) - 1),
@FromDate
);
SET @ActualToDate =
DATEADD(
DAY,
6,
@ActualFromDate
);
SET @BreakdownFromDate = @ActualFromDate;
SET @BreakdownToDate = @ActualToDate;
END
------------------------------------------------------------
-- RANGE DAYS
------------------------------------------------------------
SET @RangeDays =
DATEDIFF(DAY, @ActualFromDate, @ActualToDate) + 1;
------------------------------------------------------------
-- WORKED HOURS (EmployeeCode based)
------------------------------------------------------------
SELECT
@WorkedHours = ISNULL(SUM(S.TOT_LOGGEDHOURS), 0)
FROM EmployeeActivityLogSummary S
INNER JOIN vw_MasterEmployee E
ON E.EmployeeCode = S.EmployeeCode
WHERE E.EmployeeCode = @EmployeeCode
AND CAST(S.LoggedDate AS DATE)
BETWEEN @ActualFromDate AND @ActualToDate
AND S.IsActive = 1
AND S.IsDelete = 0;
------------------------------------------------------------
-- COMPLIANCE %
------------------------------------------------------------
SET @CompliancePercentage =
CASE
WHEN @WeeklyTarget = 0 THEN 0
ELSE (@WorkedHours * 100.0) / @WeeklyTarget
END;
------------------------------------------------------------
-- DIFFERENCE
------------------------------------------------------------
SET @DifferenceHours = @WorkedHours - @WeeklyTarget;
------------------------------------------------------------
-- RESULT 1
------------------------------------------------------------
SELECT
CAST(FLOOR(@WorkedHours) AS VARCHAR) + 'h ' +
CAST(FLOOR((@WorkedHours - FLOOR(@WorkedHours)) * 60) AS VARCHAR) + 'm'
AS WorkedHours,
CAST(FLOOR(@WeeklyTarget) AS VARCHAR) + 'h ' +
CAST(FLOOR((@WeeklyTarget - FLOOR(@WeeklyTarget)) * 60) AS VARCHAR) + 'm'
AS TargetHours,
CASE
WHEN @DifferenceHours >= 0 THEN '+'
ELSE '-'
END +
CAST(FLOOR(ABS(@DifferenceHours)) AS VARCHAR) + 'h ' +
CAST(FLOOR((ABS(@DifferenceHours) - FLOOR(ABS(@DifferenceHours))) * 60) AS VARCHAR) + 'm'
AS DifferenceHours,
CAST(@CompliancePercentage AS DECIMAL(10,2)) AS CompliancePercentage;
------------------------------------------------------------
-- RESULT 2
------------------------------------------------------------
SELECT
S.LoggedDate,
DATENAME(WEEKDAY, S.LoggedDate) AS DayName,
CAST(S.TOT_LOGGEDHOURS AS DECIMAL(10,2)) AS LoggedHours,
CAST(FLOOR(S.TOT_LOGGEDHOURS) AS VARCHAR) + 'h ' +
CAST(FLOOR((S.TOT_LOGGEDHOURS - FLOOR(S.TOT_LOGGEDHOURS)) * 60) AS VARCHAR) + 'm'
AS LoggedHoursFormatted
FROM EmployeeActivityLogSummary S
INNER JOIN vw_MasterEmployee E
ON E.EmployeeCode = S.EmployeeCode
WHERE E.EmployeeCode = @EmployeeCode
AND CAST(S.LoggedDate AS DATE)
BETWEEN @BreakdownFromDate AND @BreakdownToDate
AND TRY_CAST(S.TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0
AND S.IsActive = 1
AND S.IsDelete = 0
ORDER BY S.LoggedDate;
END