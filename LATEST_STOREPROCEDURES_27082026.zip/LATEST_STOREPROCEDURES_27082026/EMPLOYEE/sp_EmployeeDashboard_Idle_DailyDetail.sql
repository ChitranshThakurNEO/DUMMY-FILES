CREATE PROCEDURE sp_EmployeeDashboard_Idle_DailyDetail
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
-------------------------------------------------------
-- WEEK RANGE (SUNDAY TO SATURDAY)
-------------------------------------------------------
DECLARE @WeekStart DATE =
DATEADD(DAY, -(DATEPART(WEEKDAY, @Date) - 1), @Date);
DECLARE @WeekEnd DATE =
DATEADD(DAY, 6, @WeekStart);
-------------------------------------------------------
-- MANAGER
-------------------------------------------------------
DECLARE @ManagerCode NVARCHAR(100);
SELECT
@ManagerCode = MANAGER_1
FROM vw_MasterEmployee
WHERE EmployeeCode = @EmployeeCode;
-------------------------------------------------------
-- TEAM
-------------------------------------------------------
DECLARE @Team TABLE
(
EmployeeCode NVARCHAR(100) PRIMARY KEY
);
INSERT INTO @Team(EmployeeCode)
SELECT EmployeeCode
FROM vw_MasterEmployee
WHERE MANAGER_1 = @ManagerCode;
-------------------------------------------------------
-- BASE DATA
-------------------------------------------------------
;WITH BaseData AS
(
SELECT
EmployeeCode,
CAST(LoggedDate AS DATE) AS WorkDate,
TOT_IDLETIME_AC,
TRY_CAST(TOT_IDLETIME AS DECIMAL(10,2)) AS IdleHours,
TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) AS LoggedHours
FROM EmployeeActivityLogSummary
WHERE IsActive = 1
AND IsDelete = 0
AND TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0
AND CAST(LoggedDate AS DATE)
BETWEEN @WeekStart AND @WeekEnd
),
-------------------------------------------------------
-- EMPLOYEE DATA
-------------------------------------------------------
EmployeeData AS
(
SELECT
WorkDate,
MAX(TOT_IDLETIME_AC) AS IdleTime,
ROUND
(
SUM(IdleHours) * 100.0
/
NULLIF(SUM(LoggedHours),0),
1
) AS IdlePercentage
FROM BaseData
WHERE EmployeeCode = @EmployeeCode
GROUP BY WorkDate
),
-------------------------------------------------------
-- TEAM AVG
-------------------------------------------------------
TeamData AS
(
SELECT
B.WorkDate,
ROUND
(
AVG
(
CASE
WHEN B.LoggedHours > 0
THEN
(B.IdleHours * 100.0)
/ B.LoggedHours
END
),
1
) AS TeamAvgPercentage
FROM BaseData B
INNER JOIN @Team T
ON T.EmployeeCode = B.EmployeeCode
WHERE B.EmployeeCode <> @EmployeeCode
AND B.LoggedHours > 0
GROUP BY B.WorkDate
),
-------------------------------------------------------
-- LARGEST SPIKE BY DAY
-------------------------------------------------------
LargestSpike AS
(
SELECT
CAST(StartTime AS DATE) AS WorkDate,
MAX(DurationSeconds) / 60
AS LargestSpikeMinutes
FROM MasterActivityLog
WHERE EmployeeCode = @EmployeeCode
AND Status = 'Idle'
AND IsActive = 1
AND IsDelete = 0
AND CAST(StartTime AS DATE)
BETWEEN @WeekStart AND @WeekEnd
GROUP BY CAST(StartTime AS DATE)
)
-------------------------------------------------------
-- RESULT 1 : DAILY DETAIL
-------------------------------------------------------
SELECT
DATENAME(WEEKDAY, E.WorkDate) + ' '
+ RIGHT(CONVERT(VARCHAR(10), E.WorkDate, 105), 2)
AS DayLabel,
E.IdleTime,
E.IdlePercentage,
ISNULL(L.LargestSpikeMinutes, 0)
AS LargestSpikeMinutes,
ROUND
(
E.IdlePercentage
- ISNULL(T.TeamAvgPercentage, 0),
1
) AS VsTeamAverage
FROM EmployeeData E
LEFT JOIN TeamData T
ON T.WorkDate = E.WorkDate
LEFT JOIN LargestSpike L
ON L.WorkDate = E.WorkDate
ORDER BY E.WorkDate;
-------------------------------------------------------
-- RESULT 2 : WTD SUMMARY
-------------------------------------------------------
SELECT
---------------------------------------------------
-- WEEKLY AVG IDLE TIME
-- (Keep response name same)
---------------------------------------------------
CONCAT
(
CAST
(
ROUND
(
AVG(TRY_CAST(TOT_IDLETIME AS DECIMAL(10,2))) * 60,
0
) AS INT
) / 60,
'h ',
CAST
(
ROUND
(
AVG(TRY_CAST(TOT_IDLETIME AS DECIMAL(10,2))) * 60,
0
) AS INT
) % 60,
'm'
) AS TotalIdleTime,
---------------------------------------------------
-- AVERAGE IDLE %
---------------------------------------------------
ROUND
(
AVG
(
CASE
WHEN TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0
THEN
(
TRY_CAST(TOT_IDLETIME AS DECIMAL(10,2))
* 100.0
)
/
TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2))
END
),
1
) AS AverageIdlePercentage,
---------------------------------------------------
-- LARGEST WEEK SPIKE
---------------------------------------------------
(
SELECT
CAST(ROUND(AVG(DailyPeakMinutes),0) AS INT)
FROM
(
SELECT
MAX(DurationSeconds) / 60.0 AS DailyPeakMinutes
FROM MasterActivityLog
WHERE EmployeeCode = @EmployeeCode
AND Status = 'Idle'
AND IsActive = 1
AND IsDelete = 0
AND CAST(StartTime AS DATE)
BETWEEN @WeekStart AND @WeekEnd
GROUP BY CAST(StartTime AS DATE)
) X
) AS LargestWeekSpikeMinutes,
---------------------------------------------------
-- TEAM AVERAGE VARIANCE
---------------------------------------------------
ROUND
(
AVG
(
CASE
WHEN TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0
THEN
(
TRY_CAST(TOT_IDLETIME AS DECIMAL(10,2))
* 100.0
)
/
TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2))
END
),
1
)
-
ISNULL
(
(
SELECT
ROUND
(
AVG
(
CASE
WHEN TRY_CAST(EALS.TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0
THEN
(
TRY_CAST(EALS.TOT_IDLETIME AS DECIMAL(10,2))
* 100.0
)
/
TRY_CAST(EALS.TOT_LOGGEDHOURS AS DECIMAL(10,2))
END
),
1
)
FROM EmployeeActivityLogSummary EALS
INNER JOIN vw_MasterEmployee VME
ON VME.EmployeeCode = EALS.EmployeeCode
WHERE VME.MANAGER_1 = @ManagerCode
AND EALS.EmployeeCode <> @EmployeeCode
AND EALS.IsActive = 1
AND EALS.IsDelete = 0
AND TRY_CAST(EALS.TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0
AND CAST(EALS.LoggedDate AS DATE)
BETWEEN @WeekStart AND @WeekEnd
),
0
) AS TeamAverageVariance
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND IsActive = 1
AND IsDelete = 0
AND TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0
AND CAST(LoggedDate AS DATE)
BETWEEN @WeekStart AND @WeekEnd;
END
