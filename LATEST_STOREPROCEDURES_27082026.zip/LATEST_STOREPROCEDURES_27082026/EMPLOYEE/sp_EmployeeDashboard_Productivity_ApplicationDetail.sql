CREATE PROCEDURE sp_EmployeeDashboard_Productivity_ApplicationDetail
(
@EmployeeCode NVARCHAR(100),
@Date DATE
)
AS
BEGIN
SET NOCOUNT ON;
-------------------------------------------------------
-- APPLICATION DATA
-------------------------------------------------------
SELECT
MAL.Status,
MAC.CategoryName,
MAC.SubCategoryName,
SUM(MAL.DurationSeconds) AS TotalSeconds
INTO #ApplicationData
FROM MasterActivityLog MAL
LEFT JOIN MasterActivityCategory MAC
ON MAC.MasterActivityCategoryId = MAL.CategoryId
WHERE MAL.EmployeeCode = @EmployeeCode
AND CAST(MAL.StartTime AS DATE) = @Date
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
AND MAL.Status IN
(
'Productive',
'Non-Productive',
'No-Impact'
)
GROUP BY
MAL.Status,
MAC.CategoryName,
MAC.SubCategoryName;
DECLARE @GrandTotalSeconds BIGINT =
(
SELECT ISNULL(SUM(TotalSeconds),0)
FROM #ApplicationData
);
DECLARE @ProductiveSeconds BIGINT =
(
SELECT ISNULL(SUM(TotalSeconds),0)
FROM #ApplicationData
WHERE Status = 'Productive'
);
-------------------------------------------------------
-- RESULT 1 : APPLICATION DETAILS
-------------------------------------------------------
SELECT
dbo.fn_ConvertDecimalHoursToHHMMSS
(
TotalSeconds / 3600.0
) AS Duration,
ROUND
(
TotalSeconds * 100.0
/ NULLIF(@GrandTotalSeconds,0),
1
) AS PercentageOfTotal,
Status AS Classification,
CategoryName,
SubCategoryName
FROM #ApplicationData
ORDER BY TotalSeconds DESC;
-------------------------------------------------------
-- RESULT 2 : SUMMARY
-------------------------------------------------------
SELECT
dbo.fn_ConvertDecimalHoursToHHMMSS
(
@GrandTotalSeconds / 3600.0
) AS TotalDuration,
CAST
(
ISNULL
(
@ProductiveSeconds * 100.0
/ NULLIF(@GrandTotalSeconds,0),
0
)
AS DECIMAL(10,1)
) AS ProductivePercentage;
DROP TABLE #ApplicationData;
END
