CREATE PROCEDURE sp_EmployeeDashboard_Logged_DailyLog
(
@EmployeeCode NVARCHAR(100),
@Date DATE,
@DailyTargetHours DECIMAL(10,2),
@WeeklyTargetHours DECIMAL(10,2)
)
AS
BEGIN
SET NOCOUNT ON;
-------------------------------------------------------
-- WEEK RANGE (SUN-SAT)
-------------------------------------------------------
SET DATEFIRST 7;
DECLARE @WeekStart DATE =
DATEADD(
DAY,
-(DATEPART(WEEKDAY,@Date)-1),
@Date
);
DECLARE @WeekEnd DATE =
DATEADD(
DAY,
6,
@WeekStart
);
-------------------------------------------------------
-- BASE DATA
-------------------------------------------------------
SELECT
CAST(LoggedDate AS DATE) AS WorkDate,
MIN(FIRSTLOGIN) AS LoginTime,
MAX(LASTLOGOUT) AS LogoutTime,
SUM(TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2))) AS LoggedHours,
SUM(TRY_CAST(TOT_ACTIVEHOURS AS DECIMAL(10,2))) AS ActiveHours,
SUM(TRY_CAST(TOT_IDLETIME AS DECIMAL(10,2))) AS IdleHours
INTO #Base
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND IsActive = 1
AND IsDelete = 0
AND TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0
AND CAST(LoggedDate AS DATE)
BETWEEN @WeekStart AND @WeekEnd
GROUP BY
CAST(LoggedDate AS DATE);
-------------------------------------------------------
-- RESULT 1 : DAILY LOG
-------------------------------------------------------
SELECT
DATENAME(WEEKDAY, WorkDate)
+ ' '
+ RIGHT(CONVERT(VARCHAR(10), WorkDate, 105), 2)
AS DayLabel,
WorkDate,
FORMAT(LoginTime,'HH:mm') AS Login,
FORMAT(LogoutTime,'HH:mm') AS Logout,
---------------------------------------------------
-- LOGGED
---------------------------------------------------
CONCAT
(
CAST(ROUND(LoggedHours * 60,0) AS INT) / 60,
'h ',
CAST(ROUND(LoggedHours * 60,0) AS INT) % 60,
'm'
) AS Logged,
---------------------------------------------------
-- ACTIVE
---------------------------------------------------
CONCAT
(
CAST(ROUND(ActiveHours * 60,0) AS INT) / 60,
'h ',
CAST(ROUND(ActiveHours * 60,0) AS INT) % 60,
'm'
) AS Active,
---------------------------------------------------
-- IDLE
---------------------------------------------------
CONCAT
(
CAST(ROUND(IdleHours * 60,0) AS INT) / 60,
'h ',
CAST(ROUND(IdleHours * 60,0) AS INT) % 60,
'm'
) AS Idle,
---------------------------------------------------
-- OT
---------------------------------------------------
CONCAT
(
CAST
(
ROUND
(
CASE
WHEN LoggedHours > @DailyTargetHours
THEN (LoggedHours - @DailyTargetHours) * 60
ELSE 0
END,
0
) AS INT
) / 60,
'h ',
CAST
(
ROUND
(
CASE
WHEN LoggedHours > @DailyTargetHours
THEN (LoggedHours - @DailyTargetHours) * 60
ELSE 0
END,
0
) AS INT
) % 60,
'm'
) AS OT,
---------------------------------------------------
-- VS TARGET
---------------------------------------------------
CONCAT
(
CASE
WHEN LoggedHours >= @DailyTargetHours
THEN '+'
ELSE '-'
END,
ABS
(
CAST
(
ROUND
(
(LoggedHours - @DailyTargetHours) * 60,
0
) AS INT
)
),
'm'
) AS VsTarget
FROM #Base
ORDER BY WorkDate;
-------------------------------------------------------
-- RESULT 2 : WTD TOTAL
-------------------------------------------------------
SELECT
CONCAT
(
CAST(ROUND(SUM(LoggedHours) * 60,0) AS INT) / 60,
'h ',
CAST(ROUND(SUM(LoggedHours) * 60,0) AS INT) % 60,
'm'
) AS TotalLogged,
CONCAT
(
CAST(ROUND(SUM(ActiveHours) * 60,0) AS INT) / 60,
'h ',
CAST(ROUND(SUM(ActiveHours) * 60,0) AS INT) % 60,
'm'
) AS TotalActive,
CONCAT
(
CAST(ROUND(SUM(IdleHours) * 60,0) AS INT) / 60,
'h ',
CAST(ROUND(SUM(IdleHours) * 60,0) AS INT) % 60,
'm'
) AS TotalIdle,
CONCAT
(
CAST(SUM(LoggedHours) AS DECIMAL(10,2)),
' of ',
@WeeklyTargetHours,
' target'
) AS TargetInfo,
ROUND
(
(SUM(LoggedHours) * 100.0)
/ NULLIF(@WeeklyTargetHours,0),
1
) AS PercentageAchieved
FROM #Base;
DROP TABLE #Base;
END