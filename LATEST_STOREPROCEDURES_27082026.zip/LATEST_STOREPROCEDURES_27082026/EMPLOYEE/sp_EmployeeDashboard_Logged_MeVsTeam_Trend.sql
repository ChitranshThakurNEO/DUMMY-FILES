﻿CREATE PROCEDURE sp_EmployeeDashboard_Logged_MeVsTeam_Trend
(
@EmployeeCode NVARCHAR(100),
@CurrentDate DATE
)
AS
BEGIN
SET NOCOUNT ON;
SET DATEFIRST 7;
-------------------------------------------------------
-- GET MANAGER INFO
-------------------------------------------------------
DECLARE @ManagerCode NVARCHAR(100);
DECLARE @ManagerName NVARCHAR(200);
DECLARE @EmployeeName NVARCHAR(200);
SELECT
@ManagerCode = MANAGER_1,
@ManagerName = MANAGER_1_NAME,
@EmployeeName = FullName
FROM vw_MasterEmployee
WHERE EmployeeCode = @EmployeeCode;
-------------------------------------------------------
-- RESULT SET 1 → MANAGER INFO
-------------------------------------------------------
SELECT
@ManagerCode AS ManagerCode,
@ManagerName AS ManagerName,
@EmployeeName AS EmployeeName;
-------------------------------------------------------
-- MATERIALIZE TEAM
-------------------------------------------------------
DECLARE @Team TABLE (EmployeeCode NVARCHAR(100) PRIMARY KEY);
INSERT INTO @Team (EmployeeCode)
SELECT EmployeeCode
FROM vw_MasterEmployee
WHERE MANAGER_1 = @ManagerCode;
-------------------------------------------------------
-- WEEK START (SUNDAY BASED)
-------------------------------------------------------
DECLARE @WeekStart DATE =
DATEADD(DAY, -(DATEPART(WEEKDAY,@CurrentDate)-1), @CurrentDate);
-------------------------------------------------------
-- WEEK END (MON–FRI)
-------------------------------------------------------
DECLARE @WeekEnd DATE = DATEADD(DAY, 5, @WeekStart);
-------------------------------------------------------
-- DAYS (MON–FRI )
-------------------------------------------------------
;WITH Days AS
(
SELECT DATEADD(DAY,1,@WeekStart) AS WorkDate -- Monday
UNION ALL SELECT DATEADD(DAY,2,@WeekStart)
UNION ALL SELECT DATEADD(DAY,3,@WeekStart)
UNION ALL SELECT DATEADD(DAY,4,@WeekStart)
UNION ALL SELECT DATEADD(DAY,5,@WeekStart)
),
-------------------------------------------------------
-- BASE DATA (LOGGED HOURS )
-------------------------------------------------------
ActivityData AS
(
SELECT
EmployeeCode,
CAST(LoggedDate AS DATE) AS WorkDate,
TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) AS LoggedHours
FROM EmployeeActivityLogSummary
WHERE
IsActive = 1
AND IsDelete = 0
AND TRY_CAST(TOT_LOGGEDHOURS AS DECIMAL(10,2)) > 0
AND LoggedDate BETWEEN @WeekStart AND @WeekEnd
),
-------------------------------------------------------
-- MY DATA
-------------------------------------------------------
MeData AS
(
SELECT
WorkDate,
ROUND(SUM(LoggedHours),1) AS MyLoggedHours
FROM ActivityData
WHERE EmployeeCode = @EmployeeCode
GROUP BY WorkDate
),
-------------------------------------------------------
-- TEAM DATA
-------------------------------------------------------
TeamData AS
(
SELECT
A.WorkDate,
ROUND(AVG(A.LoggedHours),1) AS TeamAvgHours,
ROUND(MAX(A.LoggedHours),1) AS TeamBestHours
FROM ActivityData A
INNER JOIN @Team T
ON T.EmployeeCode = A.EmployeeCode
WHERE A.EmployeeCode <> @EmployeeCode
GROUP BY A.WorkDate
)
-------------------------------------------------------
-- RESULT SET 2 → TREND
-------------------------------------------------------
SELECT
D.WorkDate,
DATENAME(WEEKDAY, D.WorkDate) AS DayName,
ISNULL(M.MyLoggedHours, 0) AS MyLoggedHours,
ISNULL(T.TeamAvgHours, 0) AS TeamAvgLoggedHours,
ISNULL(T.TeamBestHours, 0) AS TeamBestLoggedHours
FROM Days D
LEFT JOIN MeData M ON M.WorkDate = D.WorkDate
LEFT JOIN TeamData T ON T.WorkDate = D.WorkDate
ORDER BY D.WorkDate;
END