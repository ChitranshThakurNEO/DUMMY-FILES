CREATE PROCEDURE [dbo].[sp_EmployeeDashboardTopApplications]
(
@EmployeeCode VARCHAR(50),
@FromDate DATE,
@ToDate DATE
)
AS
BEGIN
SET NOCOUNT ON;
DECLARE @Days INT = DATEDIFF(DAY, @FromDate, @ToDate) + 1;
;WITH ApplicationData AS
(
SELECT
MAC.SubCategoryName,
SUM(DATEDIFF(SECOND, MAL.StartTime, MAL.EndTime)) AS TotalSeconds,
SUM(CASE WHEN MAL.Status = 'Productive'
THEN DATEDIFF(SECOND, MAL.StartTime, MAL.EndTime)
ELSE 0 END) AS ProductiveSeconds,
SUM(CASE WHEN MAL.Status = 'Non-Productive'
THEN DATEDIFF(SECOND, MAL.StartTime, MAL.EndTime)
ELSE 0 END) AS NonProductiveSeconds,
SUM(CASE WHEN MAL.Status = 'No-Impact'
THEN DATEDIFF(SECOND, MAL.StartTime, MAL.EndTime)
ELSE 0 END) AS NoImpactSeconds
FROM MasterActivityLog MAL
INNER JOIN MasterActivityCategory MAC
ON MAL.CategoryId = MAC.MasterActivityCategoryId
WHERE MAL.EmployeeCode = @EmployeeCode
AND CAST(MAL.LogDate AS DATE) BETWEEN @FromDate AND @ToDate
AND MAL.StartTime IS NOT NULL
AND MAL.EndTime IS NOT NULL
AND MAL.IsActive = 1
AND MAL.IsDelete = 0
AND MAL.Status <> 'Idle'
GROUP BY MAC.SubCategoryName
),
IdleData AS
(
SELECT
SUM(ISNULL(TOT_IDLETIME,0)) * 3600 AS IdleSeconds
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate BETWEEN @FromDate AND @ToDate
AND IsActive = 1
AND IsDelete = 0
),
AvgProd AS
(
SELECT
SUM(TOT_PRODHOURS) * 3600 AS ProdSeconds,
SUM(TOT_NONPRODHOURS) * 3600 AS NonProdSeconds,
SUM(TOT_NOIMPACTHOURS) * 3600 AS NoImpactSeconds
FROM EmployeeActivityLogSummary
WHERE EmployeeCode = @EmployeeCode
AND LoggedDate BETWEEN @FromDate AND @ToDate
AND IsActive = 1
AND IsDelete = 0
),
CombinedData AS
(
SELECT
SubCategoryName AS ApplicationName,
TotalSeconds,
CASE
WHEN ProductiveSeconds > 0 THEN 'Productive'
WHEN NonProductiveSeconds > 0 THEN 'Non-Productive'
WHEN NoImpactSeconds > 0 THEN 'No-Impact'
ELSE 'No-Impact'
END AS CategoryType
FROM ApplicationData
UNION ALL
SELECT
'Idle Hours',
IdleSeconds,
'Idle'
FROM IdleData
WHERE IdleSeconds > 0
),
TotalUsage AS
(
SELECT SUM(TotalSeconds) AS OverallSeconds
FROM CombinedData
)
SELECT
CD.ApplicationName,
CAST(
CASE
WHEN @FromDate = @ToDate
THEN CD.TotalSeconds / 3600.0
ELSE
(CD.TotalSeconds * 1.0 / @Days) / 3600.0
END
AS DECIMAL(10,4)) AS DurationHours,
CAST(
CASE
WHEN TU.OverallSeconds = 0 THEN 0
ELSE CD.TotalSeconds * 100.0 / TU.OverallSeconds
END
AS DECIMAL(10,4)) AS UsagePercentage,
CD.CategoryType,
CAST(
CASE
WHEN @FromDate = @ToDate
THEN AP.ProdSeconds / 3600.0
ELSE
(AP.ProdSeconds * 1.0 / @Days) / 3600.0
END
AS DECIMAL(10,4)) AS AvgProductiveHours,
CAST(
CASE
WHEN @FromDate = @ToDate
THEN AP.NonProdSeconds / 3600.0
ELSE
(AP.NonProdSeconds * 1.0 / @Days) / 3600.0
END
AS DECIMAL(10,4)) AS AvgNonProductiveHours,
CAST(
CASE
WHEN @FromDate = @ToDate
THEN AP.NoImpactSeconds / 3600.0
ELSE
(AP.NoImpactSeconds * 1.0 / @Days) / 3600.0
END
AS DECIMAL(10,4)) AS AvgNoImpactHours
FROM CombinedData CD
CROSS JOIN TotalUsage TU
CROSS JOIN AvgProd AP
ORDER BY CD.TotalSeconds DESC;
END