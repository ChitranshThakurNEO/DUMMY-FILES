﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WorkVista.Server.MigrationService.Migrations
{
    /// <inheritdoc />
    public partial class AddedShiftIdToSummaryTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "MasterShiftId",
                table: "EmployeeActivityLogSummary",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeActivityLogSummary_MasterShiftId",
                table: "EmployeeActivityLogSummary",
                column: "MasterShiftId");

            migrationBuilder.AddForeignKey(
                name: "FK_EmployeeActivityLogSummary_MasterShift_MasterShiftId",
                table: "EmployeeActivityLogSummary",
                column: "MasterShiftId",
                principalTable: "MasterShift",
                principalColumn: "MasterShiftId",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_EmployeeActivityLogSummary_MasterShift_MasterShiftId",
                table: "EmployeeActivityLogSummary");

            migrationBuilder.DropIndex(
                name: "IX_EmployeeActivityLogSummary_MasterShiftId",
                table: "EmployeeActivityLogSummary");

            migrationBuilder.DropColumn(
                name: "MasterShiftId",
                table: "EmployeeActivityLogSummary");
        }
    }
}
