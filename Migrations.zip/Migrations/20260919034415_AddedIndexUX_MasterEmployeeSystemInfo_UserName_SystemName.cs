﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WorkVista.Server.MigrationService.Migrations
{
    /// <inheritdoc />
    public partial class AddedIndexUX_MasterEmployeeSystemInfo_UserName_SystemName : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "UX_MasterEmployeeSystemInfo_UserName_SystemName",
                table: "MasterEmployeeSystemInfo",
                columns: new[] { "UserName", "SystemName" },
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "UX_MasterEmployeeSystemInfo_UserName_SystemName",
                table: "MasterEmployeeSystemInfo");
        }
    }
}
