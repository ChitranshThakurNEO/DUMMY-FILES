﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WorkVista.Server.MigrationService.Migrations
{
    /// <inheritdoc />
    public partial class AddedIndexes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_ActivityLog_StartTime",
                table: "MasterActivityLog");

            migrationBuilder.AlterColumn<string>(
                name: "EmployeeCode",
                table: "EmployeeActivityLogSummary",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 100);

            migrationBuilder.CreateIndex(
                name: "IX_ActivityLog_LogDate",
                table: "MasterActivityLog",
                column: "LogDate");

            migrationBuilder.CreateIndex(
                name: "IX_ActivityLog_StartTime",
                table: "MasterActivityLog",
                column: "StartTime")
                .Annotation("SqlServer:Include", new[] { "EmployeeCode", "EndTime", "DurationSeconds" });

            migrationBuilder.CreateIndex(
                name: "UX_EmployeeActivityLogSummary_EmployeeCode_LoggedDate",
                table: "EmployeeActivityLogSummary",
                columns: new[] { "EmployeeCode", "LoggedDate" },
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_ActivityLog_LogDate",
                table: "MasterActivityLog");

            migrationBuilder.DropIndex(
                name: "IX_ActivityLog_StartTime",
                table: "MasterActivityLog");

            migrationBuilder.DropIndex(
                name: "UX_EmployeeActivityLogSummary_EmployeeCode_LoggedDate",
                table: "EmployeeActivityLogSummary");

            migrationBuilder.AlterColumn<string>(
                name: "EmployeeCode",
                table: "EmployeeActivityLogSummary",
                type: "nvarchar(50)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100);

            migrationBuilder.CreateIndex(
                name: "IX_ActivityLog_StartTime",
                table: "MasterActivityLog",
                column: "StartTime");
        }
    }
}
