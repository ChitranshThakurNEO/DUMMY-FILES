﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WorkVista.Server.MigrationService.Migrations
{
    /// <inheritdoc />
    public partial class AddedFilter : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_MSIInstallationInventory_EMPID_NTID_HostName_BuildNumber",
                table: "MSIInstallationInventory");

            migrationBuilder.CreateIndex(
                name: "IX_MSIInstallationInventory_EMPID_NTID_HostName_BuildNumber",
                table: "MSIInstallationInventory",
                columns: new[] { "EMPID", "NTID", "HostName", "BuildNumber" },
                unique: true,
                filter: "[NTID] IS NOT NULL AND [EMPID] IS NOT NULL");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_MSIInstallationInventory_EMPID_NTID_HostName_BuildNumber",
                table: "MSIInstallationInventory");

            migrationBuilder.CreateIndex(
                name: "IX_MSIInstallationInventory_EMPID_NTID_HostName_BuildNumber",
                table: "MSIInstallationInventory",
                columns: new[] { "EMPID", "NTID", "HostName", "BuildNumber" },
                unique: true,
                filter: "[EMPID] IS NOT NULL AND [NTID] IS NOT NULL");
        }
    }
}
