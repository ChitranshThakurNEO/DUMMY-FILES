﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WorkVista.Server.MigrationService.Migrations
{
    /// <inheritdoc />
    public partial class FinalDatabaseChanges : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "MasterActivityType",
                columns: table => new
                {
                    MasterActivityTypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterActivityType", x => x.MasterActivityTypeId);
                });

            migrationBuilder.CreateTable(
                name: "MasterDictionary",
                columns: table => new
                {
                    MasterDictionaryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Value = table.Column<string>(type: "nvarchar(100)", maxLength: 500, nullable: false),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterDictionary", x => x.MasterDictionaryId);
                });

            migrationBuilder.CreateTable(
                name: "MasterEmployee",
                columns: table => new
                {
                    MasterEmployeeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NetworkId = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    EmployeeCode = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    FullName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DailyCapacity = table.Column<decimal>(type: "decimal(5,2)", nullable: false),
                    SESSION_DATE = table.Column<DateTime>(type: "datetime2", nullable: true),
                    MANAGER1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    MANAGER1_EMPLOYEE_ID = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    MANAGER2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    MANAGER2_EMPLOYEE_ID = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    MANAGER1_CONSOLE_LOGIN_ID = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    MANAGER2_CONSOLE_LOGIN_ID = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    CONSOLE_LOGIN_ID = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ROLE_NAME = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    EMPLOYEE_ID = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    DESIGNATION = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    EMAIL_ID = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    USER_GROUPS = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    CLIENT = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    PORTFOLIO = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    GEO = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    DATE_OF_JOINING = table.Column<DateTime>(type: "datetime2", nullable: true),
                    TENURE = table.Column<int>(type: "int", nullable: true),
                    Department = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WorkMode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterEmployee", x => x.MasterEmployeeId);
                });

            migrationBuilder.CreateTable(
                name: "MasterEmployeeSystemInfo",
                columns: table => new
                {
                    MasterEmployeeSystemInfoId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeCode = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    EmpName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    SystemName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Manufacturer = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Model = table.Column<string>(type: "nvarchar(50)", maxLength: 100, nullable: false),
                    OS = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    SerialNumber = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    MachineName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    LogDate = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterEmployeeSystemInfo", x => x.MasterEmployeeSystemInfoId);
                });

            migrationBuilder.CreateTable(
                name: "MasterPermission",
                columns: table => new
                {
                    MasterPermissionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterPermission", x => x.MasterPermissionId);
                });

            migrationBuilder.CreateTable(
                name: "MasterRole",
                columns: table => new
                {
                    MasterRoleId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterRole", x => x.MasterRoleId);
                });

            migrationBuilder.CreateTable(
                name: "MasterShift",
                columns: table => new
                {
                    MasterShiftId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    StartTime = table.Column<TimeOnly>(type: "time", nullable: false),
                    EndTime = table.Column<TimeOnly>(type: "time", nullable: false),
                    IsFlexi = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterShift", x => x.MasterShiftId);
                });

            migrationBuilder.CreateTable(
                name: "ServiceHistoryVersion",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Version = table.Column<string>(type: "nvarchar(100)", maxLength: 50, nullable: false),
                    ReleaseDate = table.Column<string>(type: "nvarchar(100)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ServiceHistoryVersion", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "MasterActivityCategory",
                columns: table => new
                {
                    MasterActivityCategoryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActivityTypeId = table.Column<int>(type: "int", nullable: false),
                    Geo = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Company = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Department = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    CategoryName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    SubCategoryName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    ProductivityScore = table.Column<int>(type: "int", nullable: false),
                    ColorHex = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    SortOrder = table.Column<int>(type: "int", nullable: false),
                    IsProductive = table.Column<bool>(type: "bit", nullable: false),
                    IsNonProductive = table.Column<bool>(type: "bit", nullable: false),
                    IsNoImpact = table.Column<bool>(type: "bit", nullable: false),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterActivityCategory", x => x.MasterActivityCategoryId);
                    table.ForeignKey(
                        name: "FK_MasterActivityCategory_MasterActivityType_ActivityTypeId",
                        column: x => x.ActivityTypeId,
                        principalTable: "MasterActivityType",
                        principalColumn: "MasterActivityTypeId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "EmployeeActivityLogSummary",
                columns: table => new
                {
                    EmployeeActivityLogSummaryId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeCode = table.Column<string>(type: "nvarchar(50)", maxLength: 100, nullable: false),
                    LoggedDate = table.Column<DateOnly>(type: "date", nullable: false),
                    TOT_LOGGEDHOURS = table.Column<decimal>(type: "decimal(8,4)", nullable: false),
                    TOT_ACTIVEHOURS = table.Column<decimal>(type: "decimal(8,4)", nullable: false),
                    TOT_TIMEONSYSTEM = table.Column<decimal>(type: "decimal(8,4)", nullable: false),
                    TOT_TIMEAWAYFROMSYSTEM = table.Column<decimal>(type: "decimal(8,4)", nullable: false),
                    TOT_IDLETIME = table.Column<decimal>(type: "decimal(8,4)", nullable: false),
                    TOT_PRODHOURS = table.Column<decimal>(type: "decimal(8,4)", nullable: false),
                    TOT_NONPRODHOURS = table.Column<decimal>(type: "decimal(8,4)", nullable: false),
                    TOT_NOIMPACTHOURS = table.Column<decimal>(type: "decimal(8,4)", nullable: false),
                    TOT_UNKNOWNAPPLICATION = table.Column<decimal>(type: "decimal(8,4)", nullable: false),
                    TOT_LOGGEDHOURS_AC = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    TOT_ACTIVEHOURS_AC = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    TOT_TIMEONSYSTEM_AC = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    TOT_TIMEAWAYFROMSYSTEM_AC = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    TOT_IDLETIME_AC = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    TOT_UNKNOWNAPPLICATION_AC = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    FIRSTLOGIN = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LASTLOGOUT = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SHIFTNAME = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    NOOFDAYS = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    DAYTYPE = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    AttendanceStatus = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    IsValidated = table.Column<bool>(type: "bit", nullable: false),
                    MasterEmployeeId = table.Column<int>(type: "int", nullable: true),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeActivityLogSummary", x => x.EmployeeActivityLogSummaryId);
                    table.ForeignKey(
                        name: "FK_EmployeeActivityLogSummary_MasterEmployee_MasterEmployeeId",
                        column: x => x.MasterEmployeeId,
                        principalTable: "MasterEmployee",
                        principalColumn: "MasterEmployeeId");
                });

            migrationBuilder.CreateTable(
                name: "MasterAlert",
                columns: table => new
                {
                    MasterAlertId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AlertType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    AlertDate = table.Column<DateOnly>(type: "date", nullable: false),
                    Message = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    AlertRecipients = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    IsResolved = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    IsRead = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    ReadAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    MasterEmployeeId = table.Column<int>(type: "int", nullable: true),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterAlert", x => x.MasterAlertId);
                    table.ForeignKey(
                        name: "FK_MasterAlert_MasterEmployee_MasterEmployeeId",
                        column: x => x.MasterEmployeeId,
                        principalTable: "MasterEmployee",
                        principalColumn: "MasterEmployeeId");
                });

            migrationBuilder.CreateTable(
                name: "MasterAuditLog",
                columns: table => new
                {
                    MasterAuditLogId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeCode = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Action = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    EntityName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    EntityId = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    EntityJsonData = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MasterEmployeeId = table.Column<int>(type: "int", nullable: true),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterAuditLog", x => x.MasterAuditLogId);
                    table.ForeignKey(
                        name: "FK_MasterAuditLog_MasterEmployee_MasterEmployeeId",
                        column: x => x.MasterEmployeeId,
                        principalTable: "MasterEmployee",
                        principalColumn: "MasterEmployeeId");
                });

            migrationBuilder.CreateTable(
                name: "MasterEmployeeRole",
                columns: table => new
                {
                    MasterUserRoleId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeCode = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    RoleId = table.Column<int>(type: "int", nullable: false),
                    MasterEmployeeId = table.Column<int>(type: "int", nullable: true),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterEmployeeRole", x => x.MasterUserRoleId);
                    table.ForeignKey(
                        name: "FK_MasterEmployeeRole_MasterEmployee_MasterEmployeeId",
                        column: x => x.MasterEmployeeId,
                        principalTable: "MasterEmployee",
                        principalColumn: "MasterEmployeeId");
                    table.ForeignKey(
                        name: "FK_MasterEmployeeRole_MasterRole_RoleId",
                        column: x => x.RoleId,
                        principalTable: "MasterRole",
                        principalColumn: "MasterRoleId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "MasterRolePermission",
                columns: table => new
                {
                    MasterRolePermissionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleId = table.Column<int>(type: "int", nullable: false),
                    PermissionId = table.Column<int>(type: "int", nullable: false),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterRolePermission", x => x.MasterRolePermissionId);
                    table.ForeignKey(
                        name: "FK_MasterRolePermission_MasterPermission_PermissionId",
                        column: x => x.PermissionId,
                        principalTable: "MasterPermission",
                        principalColumn: "MasterPermissionId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_MasterRolePermission_MasterRole_RoleId",
                        column: x => x.RoleId,
                        principalTable: "MasterRole",
                        principalColumn: "MasterRoleId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "EmployeeShift",
                columns: table => new
                {
                    EmployeeShiftId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeCode = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ShiftId = table.Column<int>(type: "int", nullable: false),
                    EffectiveFrom = table.Column<DateOnly>(type: "date", nullable: false),
                    EffectiveTo = table.Column<DateOnly>(type: "date", nullable: false),
                    MasterEmployeeId = table.Column<int>(type: "int", nullable: true),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeShift", x => x.EmployeeShiftId);
                    table.ForeignKey(
                        name: "FK_EmployeeShift_MasterEmployee_MasterEmployeeId",
                        column: x => x.MasterEmployeeId,
                        principalTable: "MasterEmployee",
                        principalColumn: "MasterEmployeeId");
                    table.ForeignKey(
                        name: "FK_EmployeeShift_MasterShift_ShiftId",
                        column: x => x.ShiftId,
                        principalTable: "MasterShift",
                        principalColumn: "MasterShiftId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "MasterActivityCategoryRule",
                columns: table => new
                {
                    MasterActivityCategoryRuleId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActivityCategoryId = table.Column<int>(type: "int", nullable: false),
                    MatchType = table.Column<int>(type: "int", nullable: false),
                    MatchValue = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Priority = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    IsRegex = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    IsCaseSensitive = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    Column1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterActivityCategoryRule", x => x.MasterActivityCategoryRuleId);
                    table.ForeignKey(
                        name: "FK_MasterActivityCategoryRule_MasterActivityCategory_ActivityCategoryId",
                        column: x => x.ActivityCategoryId,
                        principalTable: "MasterActivityCategory",
                        principalColumn: "MasterActivityCategoryId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MasterActivityLog",
                columns: table => new
                {
                    MasterActivityLogId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CategoryId = table.Column<int>(type: "int", nullable: false),
                    StartTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EndTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DurationSeconds = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    LogDate = table.Column<DateOnly>(type: "date", nullable: false),
                    MasterActivityCategoryId = table.Column<int>(type: "int", nullable: true),
                    MasterEmployeeId = table.Column<int>(type: "int", nullable: true),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterActivityLog", x => x.MasterActivityLogId);
                    table.ForeignKey(
                        name: "FK_MasterActivityLog_MasterActivityCategory_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "MasterActivityCategory",
                        principalColumn: "MasterActivityCategoryId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_MasterActivityLog_MasterActivityCategory_MasterActivityCategoryId",
                        column: x => x.MasterActivityCategoryId,
                        principalTable: "MasterActivityCategory",
                        principalColumn: "MasterActivityCategoryId");
                    table.ForeignKey(
                        name: "FK_MasterActivityLog_MasterEmployee_MasterEmployeeId",
                        column: x => x.MasterEmployeeId,
                        principalTable: "MasterEmployee",
                        principalColumn: "MasterEmployeeId");
                });

            migrationBuilder.CreateTable(
                name: "MasterApplicationLicense",
                columns: table => new
                {
                    MasterApplicationLicenseId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActivityCategoryId = table.Column<int>(type: "int", nullable: false),
                    TotalLicenses = table.Column<int>(type: "int", nullable: false),
                    CostPerLicense = table.Column<decimal>(type: "decimal(10,2)", nullable: false),
                    BillingCycle = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterApplicationLicense", x => x.MasterApplicationLicenseId);
                    table.ForeignKey(
                        name: "FK_MasterApplicationLicense_MasterActivityCategory_ActivityCategoryId",
                        column: x => x.ActivityCategoryId,
                        principalTable: "MasterActivityCategory",
                        principalColumn: "MasterActivityCategoryId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "MasterRatingApplication",
                columns: table => new
                {
                    MasterRatingApplicationId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActivityCategoryId = table.Column<int>(type: "int", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Score = table.Column<int>(type: "int", nullable: false),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MasterRatingApplication", x => x.MasterRatingApplicationId);
                    table.ForeignKey(
                        name: "FK_MasterRatingApplication_MasterActivityCategory_ActivityCategoryId",
                        column: x => x.ActivityCategoryId,
                        principalTable: "MasterActivityCategory",
                        principalColumn: "MasterActivityCategoryId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "LicenseAssignment",
                columns: table => new
                {
                    LicenseAssignmentId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ApplicationLicenseId = table.Column<int>(type: "int", nullable: false),
                    EmployeeCode = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    AssignedDate = table.Column<DateOnly>(type: "date", nullable: false),
                    ReleasedDate = table.Column<DateOnly>(type: "date", nullable: false),
                    MasterEmployeeId = table.Column<int>(type: "int", nullable: true),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LicenseAssignment", x => x.LicenseAssignmentId);
                    table.ForeignKey(
                        name: "FK_LicenseAssignment_MasterApplicationLicense_ApplicationLicenseId",
                        column: x => x.ApplicationLicenseId,
                        principalTable: "MasterApplicationLicense",
                        principalColumn: "MasterApplicationLicenseId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_LicenseAssignment_MasterEmployee_MasterEmployeeId",
                        column: x => x.MasterEmployeeId,
                        principalTable: "MasterEmployee",
                        principalColumn: "MasterEmployeeId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeActivityLogSummary_MasterEmployeeId",
                table: "EmployeeActivityLogSummary",
                column: "MasterEmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeShift_MasterEmployeeId",
                table: "EmployeeShift",
                column: "MasterEmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeShift_ShiftId",
                table: "EmployeeShift",
                column: "ShiftId");

            migrationBuilder.CreateIndex(
                name: "IX_LicenseAssignment_ApplicationLicenseId",
                table: "LicenseAssignment",
                column: "ApplicationLicenseId");

            migrationBuilder.CreateIndex(
                name: "IX_LicenseAssignment_MasterEmployeeId",
                table: "LicenseAssignment",
                column: "MasterEmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_MasterActivityCategory_ActivityTypeId",
                table: "MasterActivityCategory",
                column: "ActivityTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_MasterActivityCategoryRule_ActivityCategoryId",
                table: "MasterActivityCategoryRule",
                column: "ActivityCategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_MasterActivityCategoryRule_MatchType_MatchValue",
                table: "MasterActivityCategoryRule",
                columns: new[] { "MatchType", "MatchValue" });

            migrationBuilder.CreateIndex(
                name: "IX_ActivityLog_Category",
                table: "MasterActivityLog",
                column: "CategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_ActivityLog_StartTime",
                table: "MasterActivityLog",
                column: "StartTime");

            migrationBuilder.CreateIndex(
                name: "IX_MasterActivityLog_MasterActivityCategoryId",
                table: "MasterActivityLog",
                column: "MasterActivityCategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_MasterActivityLog_MasterEmployeeId",
                table: "MasterActivityLog",
                column: "MasterEmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_MasterActivityType_Name",
                table: "MasterActivityType",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_MasterAlert_MasterEmployeeId",
                table: "MasterAlert",
                column: "MasterEmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_MasterApplicationLicense_ActivityCategoryId",
                table: "MasterApplicationLicense",
                column: "ActivityCategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_MasterAuditLog_MasterEmployeeId",
                table: "MasterAuditLog",
                column: "MasterEmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_MasterEmployee_Email",
                table: "MasterEmployee",
                column: "Email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_MasterEmployee_EmployeeCode",
                table: "MasterEmployee",
                column: "EmployeeCode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_MasterEmployee_IsActive",
                table: "MasterEmployee",
                column: "IsActive");

            migrationBuilder.CreateIndex(
                name: "IX_MasterEmployee_NetworkId",
                table: "MasterEmployee",
                column: "NetworkId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_MasterEmployeeRole_MasterEmployeeId",
                table: "MasterEmployeeRole",
                column: "MasterEmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_MasterEmployeeRole_RoleId",
                table: "MasterEmployeeRole",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "UX_Rating_Active",
                table: "MasterRatingApplication",
                columns: new[] { "ActivityCategoryId", "Name" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UX_Rating_Score_Active",
                table: "MasterRatingApplication",
                columns: new[] { "ActivityCategoryId", "Score" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_MasterRolePermission_PermissionId",
                table: "MasterRolePermission",
                column: "PermissionId");

            migrationBuilder.CreateIndex(
                name: "IX_MasterRolePermission_RoleId",
                table: "MasterRolePermission",
                column: "RoleId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EmployeeActivityLogSummary");

            migrationBuilder.DropTable(
                name: "EmployeeShift");

            migrationBuilder.DropTable(
                name: "LicenseAssignment");

            migrationBuilder.DropTable(
                name: "MasterActivityCategoryRule");

            migrationBuilder.DropTable(
                name: "MasterActivityLog");

            migrationBuilder.DropTable(
                name: "MasterAlert");

            migrationBuilder.DropTable(
                name: "MasterAuditLog");

            migrationBuilder.DropTable(
                name: "MasterDictionary");

            migrationBuilder.DropTable(
                name: "MasterEmployeeRole");

            migrationBuilder.DropTable(
                name: "MasterEmployeeSystemInfo");

            migrationBuilder.DropTable(
                name: "MasterRatingApplication");

            migrationBuilder.DropTable(
                name: "MasterRolePermission");

            migrationBuilder.DropTable(
                name: "ServiceHistoryVersion");

            migrationBuilder.DropTable(
                name: "MasterShift");

            migrationBuilder.DropTable(
                name: "MasterApplicationLicense");

            migrationBuilder.DropTable(
                name: "MasterEmployee");

            migrationBuilder.DropTable(
                name: "MasterPermission");

            migrationBuilder.DropTable(
                name: "MasterRole");

            migrationBuilder.DropTable(
                name: "MasterActivityCategory");

            migrationBuilder.DropTable(
                name: "MasterActivityType");
        }
    }
}
