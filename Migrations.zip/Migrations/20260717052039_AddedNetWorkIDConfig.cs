﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WorkVista.Server.MigrationService.Migrations
{
    /// <inheritdoc />
    public partial class AddedNetWorkIDConfig : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "EmployeeNetworkMapping",
                columns: table => new
                {
                    EmployeeNetworkMappingId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    NetworkId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Column1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column3 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column4 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column5 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column6 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column7 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column8 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column9 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Column10 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    DeletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedReason = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeNetworkMapping", x => x.EmployeeNetworkMappingId);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EmployeeNetworkMapping");
        }
    }
}
