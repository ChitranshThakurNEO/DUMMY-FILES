namespace WorkVista.Processor.ShiftDate
{
    /// <summary>
    /// Assigns Shift Dates to one employee's activities.
    ///
    ///  - Continuity is decided first, per shift: an activity on the same
    ///    calendar date as the current shift date stays in it; on a different
    ///    calendar date a gap below BreakThreshold continues it, a gap of
    ///    BreakThreshold or more starts a new shift. Idle rows do not extend
    ///    continuity.
    ///  - Night Shift Carry Forward is evaluated ONCE, only when a new shift
    ///    starts, from that first activity: if it starts in [00:00, 05:30) local
    ///    time and no shift is dated the previous day, the shift is dated the
    ///    previous day; otherwise it keeps its own date.
    ///  - Every activity of the shift inherits the shift's date.
    ///
    /// "A shift is dated the previous day" is read from the shift dates already
    /// known for the employee (stored rows + shifts assigned in this call), not
    /// from the summary table, so the result does not depend on when the
    /// summary job runs.
    /// Pure: no I/O, no clock.
    /// </summary>
    public sealed class ShiftDateResolver
    {
        private static readonly TimeSpan CarryForwardCutoff = new(5, 30, 0);

        private readonly TimeSpan _breakThreshold;
        private readonly TimeZoneInfo _timeZone;

        public ShiftDateResolver(
            TimeSpan breakThreshold,
            TimeZoneInfo timeZone)
        {
            _breakThreshold = breakThreshold;
            _timeZone = timeZone;
        }

        public TimeZoneInfo TimeZone => _timeZone;

        private DateTime ToLocal(DateTime utc) =>
            TimeZoneInfo.ConvertTimeFromUtc(
                DateTime.SpecifyKind(utc, DateTimeKind.Utc),
                _timeZone);

        public DateOnly LocalDate(DateTime utc) =>
            DateOnly.FromDateTime(ToLocal(utc));

        /// <param name="knownShiftDates">Shift dates already stored for the
        /// employee before these activities (used by the carry-forward check).</param>
        public ShiftResolution Resolve(
            ShiftState? seed,
            IReadOnlyList<ShiftActivity> activities,
            IReadOnlyCollection<DateOnly>? knownShiftDates = null)
        {
            var dates = new DateOnly[activities.Count];
            var state = seed;
            var assigned = new HashSet<DateOnly>(knownShiftDates ?? Array.Empty<DateOnly>());
            var newShifts = 0;
            var crossDate = 0;
            var anomalies = 0;

            var order = Enumerable.Range(0, activities.Count)
                .OrderBy(i => activities[i].StartUtc)
                .ThenBy(i => EffectiveEnd(activities[i]))
                .ThenBy(i => i);

            foreach (var i in order)
            {
                var activity = activities[i];
                var localStart = ToLocal(activity.StartUtc);
                var startDate = DateOnly.FromDateTime(localStart);
                var end = EffectiveEnd(activity);

                if (state is null ||
                    StartsNewShift(state, activity.StartUtc, startDate, ref anomalies))
                {
                    // Carry-forward: once, on the first activity of the new shift.
                    var shiftDate = startDate;

                    if (localStart.TimeOfDay < CarryForwardCutoff &&
                        !assigned.Contains(startDate.AddDays(-1)))
                    {
                        shiftDate = startDate.AddDays(-1);
                    }

                    state = new ShiftState(
                        shiftDate,
                        activity.IsIdle ? activity.StartUtc : end);

                    assigned.Add(shiftDate);
                    newShifts++;
                }
                else if (!activity.IsIdle && end > state.LastActiveEndUtc)
                {
                    state = state with { LastActiveEndUtc = end };
                }

                dates[i] = state.ShiftDate;

                if (state.ShiftDate != startDate)
                {
                    crossDate++;
                }
            }

            return new ShiftResolution(
                dates,
                state,
                newShifts,
                crossDate,
                anomalies);
        }

        private bool StartsNewShift(
            ShiftState state,
            DateTime startUtc,
            DateOnly startDate,
            ref int anomalies)
        {
            if (startDate == state.ShiftDate)
            {
                return false;
            }

            if (startDate < state.ShiftDate)
            {
                anomalies++;
                return true;
            }

            return startUtc - state.LastActiveEndUtc >= _breakThreshold;
        }

        private static DateTime EffectiveEnd(ShiftActivity activity) =>
            activity.EndUtc < activity.StartUtc
                ? activity.StartUtc
                : activity.EndUtc;
    }
}
