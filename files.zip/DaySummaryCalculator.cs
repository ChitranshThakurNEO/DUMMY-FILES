using WorkVista.Server.DataContext.Entities;
using static WorkVista.Server.Common.Constants.WorkVistaConstants;

namespace WorkVista.Processor.Summary
{
    public sealed record DaySummaryTotals(
        DateTime FirstLogin,
        DateTime LastLogout,
        long ActiveSeconds,
        long ProductiveSeconds,
        long NonProductiveSeconds,
        long IdleSeconds,
        long NoImpactSeconds,
        long UnknownSeconds);

    public static class DaySummaryCalculator
    {
        /// <summary>
        /// Totals for all activities of one employee that share a LogDate.
        /// FirstLogin / LastLogout are the earliest start and latest end of the
        /// Shift Date, in the given time zone. No night-shift adjustment: the
        /// Shift Date already decides which rows belong together.
        /// </summary>
        public static DaySummaryTotals? Calculate(
            IReadOnlyCollection<MasterActivityLog> activities,
            TimeZoneInfo timeZone)
        {
            if (activities.Count == 0)
            {
                return null;
            }

            long Sum(Func<MasterActivityLog, bool> predicate) =>
                activities
                    .Where(predicate)
                    .Sum(x => (long)x.DurationSeconds);

            return new DaySummaryTotals(
                FirstLogin: ToLocal(activities.Min(x => x.StartTime), timeZone),
                LastLogout: ToLocal(activities.Max(x => x.EndTime), timeZone),
                ActiveSeconds: Sum(x => x.Status != ActivityCategoryTypes.Idle),
                ProductiveSeconds: Sum(x => x.Status == ActivityCategoryTypes.Productive),
                NonProductiveSeconds: Sum(x => x.Status == ActivityCategoryTypes.NonProductive),
                IdleSeconds: Sum(x => x.Status == ActivityCategoryTypes.Idle),
                NoImpactSeconds: Sum(x => x.Status == ActivityCategoryTypes.NoImpact),
                UnknownSeconds: Sum(x =>
                    x.Status == ActivityCategoryTypes.NonProductive &&
                    x.MasterActivityCategory?.CategoryName == ActivityCategoryTypes.Unknown));
        }

        private static DateTime ToLocal(DateTime utc, TimeZoneInfo timeZone) =>
            TimeZoneInfo.ConvertTimeFromUtc(
                DateTime.SpecifyKind(utc, DateTimeKind.Utc),
                timeZone);
    }
}
